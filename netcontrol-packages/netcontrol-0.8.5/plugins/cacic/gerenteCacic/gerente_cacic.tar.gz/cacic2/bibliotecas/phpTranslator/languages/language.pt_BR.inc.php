pt_BR     #phptranslator_mnt_code_advise#                                                                     Tradutor  info                * - O campo n�o poder� ser alterado!
pt_BR     #phptranslator_alterar#                                                                             Tradutor  info                Alterar
pt_BR     #phptranslator_file#                                                                                Tradutor  info                Arquivo
pt_BR     #phptranslator_language file#                                                                       Tradutor                      Arquivo de idioma
pt_BR     #phptranslator_section array not defined#                                                           Tradutor  error               Array de sec��es n�o definido!
pt_BR     #phptranslator_cancelar#                                                                            Tradutor  info                Cancelar
pt_BR     #phptranslator_codificacao de idioma padrao#                                                        Tradutor  info                Codifica��o de Idioma Padr�o
pt_BR     #phptranslator_contexto da mensagem#                                                                Tradutor  info                Contexto da mensagem
pt_BR     #phptranslator_criar idioma#                                                                        Tradutor  info                Criar idioma
pt_BR     #phptranslator_codigo da mensagem#                                                                  Tradutor  info                C�digo da Mensagem
pt_BR     #phptranslator_inserir code exist use change#                                                       Tradutor  error               C�digo existente, use op��o para altera��o!
pt_BR     #phptranslator_directory#                                                                           Tradutor                      Diret�rio
pt_BR     #phptranslator_excluir#                                                                             Tradutor  info                Excluir
pt_BR     #phptranslator_excluir codigo#                                                                      Tradutor  info                Excluir c�digo da base?
pt_BR     #phptranslator_falta selecionar mensagem a ser alterada#                                            Tradutor  warn                Falta selecionar mensagem a ser alterada.
pt_BR     #phptranslator_falta selecionar mensagem a ser excluida#                                            Tradutor  warn                Falta selecionar mensagem a ser exclu�da
pt_BR     #phptranslator_geral#                                                                               Tradutor  info                Geral
pt_BR     #phptranslator_idioma#                                                                              Tradutor  info                Idioma
pt_BR     #phptranslator_inserir#                                                                             Tradutor  info                Inserir
pt_BR     #phptranslator_listagem de mensagens padrao codificadas#                                            Tradutor  info                Listagem de mensagens padr�o codificadas
pt_BR     #phptranslator_listar#                                                                              Tradutor  info                Listar
pt_BR     #phptranslator_mensagem#                                                                            Tradutor  info                Mensagem
pt_BR     #phptranslator_objtemplate#                                                                         Tradutor                      Object template
pt_BR     #phptranslator_array parameter required#                                                            Tradutor  error               Par�metro deve ser array!
pt_BR     #phptranslator_i18n_pt_BR#                                                                          Tradutor  info      pt_BR     Portugu�s Brasileiro
pt_BR     #phptranslator_restaurar#                                                                           Tradutor  info                Restaurar
pt_BR     #phptranslator_salvar#                                                                              Tradutor  info                Salvar
pt_BR     #phptranslator_without write permition#                                                             Tradutor                      Sem permiss�o de escrita
pt_BR     #phptranslator_sigla#                                                                               Tradutor  info                Sigla
pt_BR     #phptranslator_sigla para a mensagem#                                                               Tradutor  info                Sigla para a mensagem
pt_BR     #phptranslator_simbolo#                                                                             Tradutor  info                S�mbolo
pt_BR     #phptranslator_text#                                                                                Tradutor                      Texto
pt_BR     #phptranslator_texto padrao#                                                                        Tradutor  info                Texto padr�o
pt_BR     #phptranslator_texto traduzido#                                                                     Tradutor  info                Texto traduzido
pt_BR     #phptranslator_tipo da mensagem#                                                                    Tradutor  info                Tipo da mensagem
pt_BR     #phptranslator_traducao do idioma padrao#                                                           Tradutor  info                Traducao do idioma padrao
pt_BR     #phptranslator_traduzir#                                                                            Tradutor  info                Traduzir
pt_BR     #phptranslator_traduzir para#                                                                       Tradutor  info                Traduzir para
pt_BR     #phptranslator_page_title#                                                                          Tradutor  info                Tradu��o de textos de Aplica��es
pt_BR     #phptranslator_not found#                                                                           Tradutor  error               n�o encontrado
pt_BR     tradutor                                                                                            Tradutor  TagHeader           phpTranslator
