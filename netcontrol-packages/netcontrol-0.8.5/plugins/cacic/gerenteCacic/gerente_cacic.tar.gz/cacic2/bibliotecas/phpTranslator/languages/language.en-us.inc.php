en-us     #phptranslator_mnt_code_advise#                                                                     Tradutor  info                * - The field could not be changed!
en-us     #phptranslator_alterar#                                                                             Tradutor  info                Change
en-us     #phptranslator_file#                                                                                Tradutor  info                File
en-us     #phptranslator_language file#                                                                       Tradutor                      Language file
en-us     #phptranslator_section array not defined#                                                           Tradutor  error               Section array not defined!
en-us     #phptranslator_cancelar#                                                                            Tradutor  info                Cancel
en-us     #phptranslator_codificacao de idioma padrao#                                                        Tradutor  info                Standard Language setup
en-us     #phptranslator_contexto da mensagem#                                                                Tradutor  info                Message context
en-us     #phptranslator_criar idioma#                                                                        Tradutor  info                Create Language
en-us     #phptranslator_codigo da mensagem#                                                                  Tradutor  info                Message code
en-us     #phptranslator_inserir code exist use change#                                                       Tradutor  error               Message code exist, use change option!
en-us     #phptranslator_directory#                                                                           Tradutor                      Directory
en-us     #phptranslator_excluir#                                                                             Tradutor  info                Delete
en-us     #phptranslator_excluir codigo#                                                                      Tradutor  info                Delete code base
en-us     #phptranslator_falta selecionar mensagem a ser alterada#                                            Tradutor  warn                You need to choose a message to change
en-us     #phptranslator_falta selecionar mensagem a ser excluida#                                            Tradutor  warn                You need to choose a message to delete
en-us     #phptranslator_geral#                                                                               Tradutor  info                General
en-us     #phptranslator_idioma#                                                                              Tradutor  info                Language
en-us     #phptranslator_inserir#                                                                             Tradutor  info                Insert
en-us     #phptranslator_listagem de mensagens padrao codificadas#                                            Tradutor  info                Standard Messages - Setup report
en-us     #phptranslator_listar#                                                                              Tradutor  info                List
en-us     #phptranslator_mensagem#                                                                            Tradutor  info                Message
en-us     #phptranslator_objtemplate#                                                                         Tradutor                      Object template
en-us     #phptranslator_array parameter required#                                                            Tradutor  error               Array parameter required!
en-us     #phptranslator_i18n_pt-br#                                                                          Tradutor  info                Brasilian Portuguese
en-us     #phptranslator_restaurar#                                                                           Tradutor  info                Reset
en-us     #phptranslator_salvar#                                                                              Tradutor  info                Save
en-us     #phptranslator_without write permition#                                                             Tradutor                      Without write permition
en-us     #phptranslator_sigla#                                                                               Tradutor  info                Abbreviation
en-us     #phptranslator_sigla para a mensagem#                                                               Tradutor  info                Message Abbreviation
en-us     #phptranslator_simbolo#                                                                             Tradutor  info                Simbol
en-us     #phptranslator_text#                                                                                Tradutor                      Text
en-us     #phptranslator_texto padrao#                                                                        Tradutor  info                Standar text
en-us     #phptranslator_texto traduzido#                                                                     Tradutor  info                Translated text
en-us     #phptranslator_tipo da mensagem#                                                                    Tradutor  info                Message type
en-us     #phptranslator_traducao do idioma padrao#                                                           Tradutor  info                Standard Language translation
en-us     #phptranslator_traduzir#                                                                            Tradutor  info                Translate
en-us     #phptranslator_traduzir para#                                                                       Tradutor  info                Translate to
en-us     #phptranslator_page_title#                                                                          Tradutor  info                Application Translator
en-us     #phptranslator_not found#                                                                           Tradutor  error               Not found
en-us     tradutor                                                                                            Tradutor  TagHeader           phpTranslator
