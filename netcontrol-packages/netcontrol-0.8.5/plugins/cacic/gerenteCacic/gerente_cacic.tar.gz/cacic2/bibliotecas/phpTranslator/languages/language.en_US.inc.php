en_US     #phptranslator_mnt_code_advise#                                                                     Tradutor  info                * - The field could not be changed!
en_US     #phptranslator_alterar#                                                                             Tradutor  info                Change
en_US     #phptranslator_file#                                                                                Tradutor  info                File
en_US     #phptranslator_language file#                                                                       Tradutor                      Language file
en_US     #phptranslator_section array not defined#                                                           Tradutor  error               Section array not defined!
en_US     #phptranslator_cancelar#                                                                            Tradutor  info                Cancel
en_US     #phptranslator_codificacao de idioma padrao#                                                        Tradutor  info                Standard Language setup
en_US     #phptranslator_contexto da mensagem#                                                                Tradutor  info                Message context
en_US     #phptranslator_criar idioma#                                                                        Tradutor  info                Create Language
en_US     #phptranslator_codigo da mensagem#                                                                  Tradutor  info                Message code
en_US     #phptranslator_inserir code exist use change#                                                       Tradutor  error               Message code exist, use change option!
en_US     #phptranslator_directory#                                                                           Tradutor                      Directory
en_US     #phptranslator_excluir#                                                                             Tradutor  info                Delete
en_US     #phptranslator_excluir codigo#                                                                      Tradutor  info                Delete code base
en_US     #phptranslator_falta selecionar mensagem a ser alterada#                                            Tradutor  warn                You need to choose a message to change
en_US     #phptranslator_falta selecionar mensagem a ser excluida#                                            Tradutor  warn                You need to choose a message to delete
en_US     #phptranslator_geral#                                                                               Tradutor  info                General
en_US     #phptranslator_idioma#                                                                              Tradutor  info                Language
en_US     #phptranslator_inserir#                                                                             Tradutor  info                Insert
en_US     #phptranslator_listagem de mensagens padrao codificadas#                                            Tradutor  info                Standard Messages - Setup report
en_US     #phptranslator_listar#                                                                              Tradutor  info                List
en_US     #phptranslator_mensagem#                                                                            Tradutor  info                Message
en_US     #phptranslator_objtemplate#                                                                         Tradutor                      Object template
en_US     #phptranslator_array parameter required#                                                            Tradutor  error               Array parameter required!
en_US     #phptranslator_i18n_pt-br#                                                                          Tradutor  info                Brasilian Portuguese
en_US     #phptranslator_restaurar#                                                                           Tradutor  info                Reset
en_US     #phptranslator_salvar#                                                                              Tradutor  info                Save
en_US     #phptranslator_without write permition#                                                             Tradutor                      Without write permition
en_US     #phptranslator_sigla#                                                                               Tradutor  info                Abbreviation
en_US     #phptranslator_sigla para a mensagem#                                                               Tradutor  info                Message Abbreviation
en_US     #phptranslator_simbolo#                                                                             Tradutor  info                Simbol
en_US     #phptranslator_text#                                                                                Tradutor                      Text
en_US     #phptranslator_texto padrao#                                                                        Tradutor  info                Standar text
en_US     #phptranslator_texto traduzido#                                                                     Tradutor  info                Translated text
en_US     #phptranslator_tipo da mensagem#                                                                    Tradutor  info                Message type
en_US     #phptranslator_traducao do idioma padrao#                                                           Tradutor  info                Standard Language translation
en_US     #phptranslator_traduzir#                                                                            Tradutor  info                Translate
en_US     #phptranslator_traduzir para#                                                                       Tradutor  info                Translate to
en_US     #phptranslator_page_title#                                                                          Tradutor  info                Application Translator
en_US     #phptranslator_not found#                                                                           Tradutor  error               Not found
en_US     tradutor                                                                                            Tradutor  TagHeader           phpTranslator
