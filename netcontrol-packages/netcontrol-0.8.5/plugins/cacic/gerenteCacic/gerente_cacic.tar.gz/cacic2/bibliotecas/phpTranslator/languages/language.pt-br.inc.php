pt-br     #phptranslator_mnt_code_advise#                                                                     Tradutor  info                * - O campo n�o poder� ser alterado!
pt-br     #phptranslator_alterar#                                                                             Tradutor  info                Alterar
pt-br     #phptranslator_file#                                                                                Tradutor  info                Arquivo
pt-br     #phptranslator_language file#                                                                       Tradutor                      Arquivo de idioma
pt-br     #phptranslator_section array not defined#                                                           Tradutor  error               Array de sec��es n�o definido!
pt-br     #phptranslator_cancelar#                                                                            Tradutor  info                Cancelar
pt-br     #phptranslator_codificacao de idioma padrao#                                                        Tradutor  info                Codifica��o de Idioma Padr�o
pt-br     #phptranslator_contexto da mensagem#                                                                Tradutor  info                Contexto da mensagem
pt-br     #phptranslator_criar idioma#                                                                        Tradutor  info                Criar idioma
pt-br     #phptranslator_codigo da mensagem#                                                                  Tradutor  info                C�digo da Mensagem
pt-br     #phptranslator_inserir code exist use change#                                                       Tradutor  error               C�digo existente, use op��o para altera��o!
pt-br     #phptranslator_directory#                                                                           Tradutor                      Diret�rio
pt-br     #phptranslator_excluir#                                                                             Tradutor  info                Excluir
pt-br     #phptranslator_excluir codigo#                                                                      Tradutor  info                Excluir c�digo da base?
pt-br     #phptranslator_falta selecionar mensagem a ser alterada#                                            Tradutor  warn                Falta selecionar mensagem a ser alterada.
pt-br     #phptranslator_falta selecionar mensagem a ser excluida#                                            Tradutor  warn                Falta selecionar mensagem a ser exclu�da
pt-br     #phptranslator_geral#                                                                               Tradutor  info                Geral
pt-br     #phptranslator_idioma#                                                                              Tradutor  info                Idioma
pt-br     #phptranslator_inserir#                                                                             Tradutor  info                Inserir
pt-br     #phptranslator_listagem de mensagens padrao codificadas#                                            Tradutor  info                Listagem de mensagens padr�o codificadas
pt-br     #phptranslator_listar#                                                                              Tradutor  info                Listar
pt-br     #phptranslator_mensagem#                                                                            Tradutor  info                Mensagem
pt-br     #phptranslator_objtemplate#                                                                         Tradutor                      Object template
pt-br     #phptranslator_array parameter required#                                                            Tradutor  error               Par�metro deve ser array!
pt-br     #phptranslator_i18n_pt-br#                                                                          Tradutor  info      pt-br     Portugu�s Brasileiro
pt-br     #phptranslator_restaurar#                                                                           Tradutor  info                Restaurar
pt-br     #phptranslator_salvar#                                                                              Tradutor  info                Salvar
pt-br     #phptranslator_without write permition#                                                             Tradutor                      Sem permiss�o de escrita
pt-br     #phptranslator_sigla#                                                                               Tradutor  info                Sigla
pt-br     #phptranslator_sigla para a mensagem#                                                               Tradutor  info                Sigla para a mensagem
pt-br     #phptranslator_simbolo#                                                                             Tradutor  info                S�mbolo
pt-br     #phptranslator_text#                                                                                Tradutor                      Texto
pt-br     #phptranslator_texto padrao#                                                                        Tradutor  info                Texto padr�o
pt-br     #phptranslator_texto traduzido#                                                                     Tradutor  info                Texto traduzido
pt-br     #phptranslator_tipo da mensagem#                                                                    Tradutor  info                Tipo da mensagem
pt-br     #phptranslator_traducao do idioma padrao#                                                           Tradutor  info                Traducao do idioma padrao
pt-br     #phptranslator_traduzir#                                                                            Tradutor  info                Traduzir
pt-br     #phptranslator_traduzir para#                                                                       Tradutor  info                Traduzir para
pt-br     #phptranslator_page_title#                                                                          Tradutor  info                Tradu��o de textos de Aplica��es
pt-br     #phptranslator_not found#                                                                           Tradutor  error               n�o encontrado
pt-br     tradutor                                                                                            Tradutor  TagHeader           phpTranslator
