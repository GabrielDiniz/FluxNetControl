<?php
/**
* @version $Id: index.php 2007-02-08 22:20 harpiain $
* @package Cacic-Install
* @subpackage Instalador
* @copyright Copyright (C) 2007 Adriano dos Santos Vieira. All rights reserved.
* @license GNU/GPL, see LICENSE.php
* CACIC-Install is free software and parts of it may contain or be derived from the
* GNU General Public License or other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// direct access is denied
defined( 'CACIC' ) or die( ACCESS_DENIED );
?>
