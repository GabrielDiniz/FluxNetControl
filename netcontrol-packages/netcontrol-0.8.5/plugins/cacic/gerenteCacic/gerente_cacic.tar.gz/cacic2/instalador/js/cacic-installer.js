/**
 * M�todos diversos para uso pelo Instalador do CACIC
 * @copyright Copyright (C) 2007 Adriano dos Santos Vieira. All rights reserved.
 * @author Adriano dos Santos Vieira <harpiain at gmail.com>
 * @version 0.0.1
 * @license GNU/GPL
 * @description M�todos para serem usados pelo Instalador do CACIC em valida��es diversas
 *              de campos e funcionalidades.
 */ 
 
