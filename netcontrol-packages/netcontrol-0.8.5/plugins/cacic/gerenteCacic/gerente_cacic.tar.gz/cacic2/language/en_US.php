<?php
  // Descricao do idioma - escrito como no pa�s de origem.
  $language_def = 'English (US)';
  // Sigla conforme padr�o estabelecido.
  $language_abbr = 'en_US';
  // Charset - conjunto de codifica��o de caracteres a ser usado
  $language_charset = 'iso-8859-1';
  // Dire��o de escrita
  $language_direction = '0'; // 0=esquerda para direita, 1=direita para esquerda
  // Vers�o da tradu��o
  $language_version = '0.1';
  // Vers�o do CACIC
  $language_cacic_version = '2.6.0-Beta-2';
?>