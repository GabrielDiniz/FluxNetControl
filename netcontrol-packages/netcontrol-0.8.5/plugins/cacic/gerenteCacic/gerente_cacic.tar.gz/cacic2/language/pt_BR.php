<?php
  //Descricao
  $language_def = 'Portugu�s Brasileiro';
  //Sigla
  $language_abbr = 'pt_BR';
  //Charset
  $language_charset = 'iso-8859-1';
  //Dire��o de escrita
  $language_direction = '0'; // 0=direita, 1=esquerda
  //Vers�o
  $language_version = '0.1';
  //Vers�o do CACIC
  $language_cacic_version = '2.6.0-Beta-2';
?>
