en_US     kciq_msg apoio                                                                                      Geral     info                Support
en_US     language_en-us                                                                                      Geral     info      en-US     
en_US     language_es                                                                                         Geral     info      es        
en_US     language_fr                                                                                         Geral     info      fr        
en_US     geral                                                                                               Geral     TagHeader           General
en_US     language                                                                                            Geral     info                Language
en_US     instalador                                                                                          geral     TagHeader           Installer
en_US     kciq_msg legenda                                                                                    geral     info                Legend
en_US     manuten��o                                                                                          geral     TagHeader           Maintenance
en_US     kciq_msg mensagem                                                                                   Geral     info                Message
en_US     kciq_msg no                                                                                         geral     info                No
en_US     kciq_msg access level                                                                               Geral     info                Access level
en_US     kciq_menu fast search                                                                               Geral     info                Search
en_US     kciq_menu search                                                                                    Geral     info                Search
en_US     kciq_msg next                                                                                       Geral     info                Next
en_US     kciq_msg password                                                                                   Geral     info                Password
en_US     kciq_msg yes                                                                                        geral     info                Yes
en_US     kciq_msg user                                                                                       Geral     info                User
en_US     kciq_msg check                                                                                      geral     info                Check
en_US     kciq_msg check_notok                                                                                geral     info                Check not ok
en_US     kciq_msg check_ok                                                                                   geral     info                Check ok
en_US     kciq_msg aceitar                                                                                    instaladorinfo                Accept
en_US     kciq_msg aceito                                                                                     instaladorinfo                I accept this license
en_US     kciq_msg check_advise                                                                               instaladorinfo                Advise, you could continue the installation
en_US     kciq_msg previous                                                                                   instaladorinfo                Back
en_US     kciq_msg cfgfile_writeable                                                                          instaladorinfo                Could write <i><b>config.php</b></i> file?
en_US     kciq_msg finish                                                                                     instaladorinfo                Finish
en_US     kciq_msg inst end hist title                                                                        instaladorinfo                CACIC changelog history
en_US     kciq_msg def_language                                                                               instaladorinfo                Language
en_US     kciq_msg finish title                                                                               instaladorinfo                Start using CACIC!
en_US     kciq_installertitle                                                                                 instaladorinfo                CACIC Web Installer
en_US     kciq_msg web_installer                                                                              instaladorinfo                CACIC Web Installer
en_US     kciq_msg advise_title                                                                               instaladorinfo                PHP/Apache flags
en_US     kciq_installerintrotitle                                                                            instaladorinfo                Introdution
en_US     kciq_msg license title                                                                              instaladorinfo                License
en_US     kciq_msg php_memory                                                                                 instaladorinfo                Memory for PHP scripts
en_US     kciq_msg js_enable                                                                                  instaladorinfo                <b>JavaScript</b> is needed for web installer process.
en_US     kciq_msg mcrypt_suporte                                                                             instaladorinfo      php-MCryptPHP MCrypt support needed
en_US     kciq_msg gd_suporte                                                                                 instaladorinfo      php-GD    PHP GD library support needed
en_US     kciq_msg ftp_suporte                                                                                instaladorinfo      php-FTP   PHP FTP support needed
en_US     kciq_msg mysql_suporte                                                                              instaladorinfo      php-MySQL PHP MySQL version support needed
en_US     kciq_msg license advise                                                                             instaladorinfo                Please, read the license bellow. You need to accept it to continue the installation process!
en_US     kciq_installerresources                                                                             instaladorinfo                Installer features:
en_US     kciq_msg requisitos                                                                                 instaladorinfo                Requiriment
en_US     kciq_msg def_version                                                                                instaladorinfo                Version
en_US     kciq_msg phpversion                                                                                 instaladorinfo                PHP version
en_US     e mais...                                                                                           instaladorinfo                and more...
en_US     kciq_msg inst end advise file                                                                       instaladorarquivo             inst_end_advise_file.html
en_US     kciq_msg features file                                                                              instaladorarquivo             inst_end_features_file.html
en_US     kciq_msg inst end hist file                                                                         instaladorarquivo             inst_end_hist_file.html
en_US     kciq_installer_introdution                                                                          instaladorarquivo             introduction.html
en_US     kciq_msg license en_read                                                                            instaladorinfo                read it in English
en_US     kciq_msg license pt_read                                                                            instaladorinfo                read it in Portuguese
en_US     kciq_mnt_lang traducao                                                                              manutencaoinfo                Language
en_US     kciq_mnt_tradutor                                                                                   manutencaoinfo                CACIC Language translate
