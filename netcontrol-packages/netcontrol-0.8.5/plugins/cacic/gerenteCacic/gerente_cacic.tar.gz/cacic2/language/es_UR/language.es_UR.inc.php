es_UR     (softwares nao classificados e softwares lixo)                                                      admin     info                (Programas no clasificados y software basura)
es_UR     (diferente de administrador):                                                                       admin     info                (diferente del administrador)
es_UR     (icone na bandeja da estacao):                                                                      admin     info                (icono en la bandeja de la estaci�n)
es_UR     --- selecione ---                                                                                   admin     info                --- Seleccione ---
es_UR     1 hora apos a inicializacao do cacic                                                                admin     info                1 hora despu�s de la inicializaci�n de CACIC
es_UR     10 minutos apos a inicializacao do cacic                                                            admin     info                10 minutos despues de la incializaci�n de CACIC
es_UR     20 minutos apos a inicializacao do cacic                                                            admin     info                20 minutos despu�s de la inicializaci�n de CACIC
es_UR     30 minutos apos a inicializacao do cacic                                                            admin     info                30 minutos despu�s de la incializaci�n de CACIC
es_UR     a cada 10 horas                                                                                     admin     info                Cada 10 horas
es_UR     a cada 2 horas                                                                                      admin     info                Cada 2 horas
es_UR     a cada 4 horas                                                                                      admin     info                Cada 4 horas
es_UR     a cada 6 horas                                                                                      admin     info                Cada 6 horas
es_UR     a cada 8 horas                                                                                      admin     info                Cada 8 horas
es_UR     a inclusao de %1 e restrita ao administrador do sistema                                             admin     info                La inserci�n de %1 es restringido para el Administrador del Sistema
es_UR     a inclusao de %1 e restrita ao nivel administrativo.                                                admin     info                La inserci�n de %1 es restringida al nivel administrativo
es_UR     a sigla do local e obrigatoria                                                                      admin     info                La sigla local es obligatoria
es_UR     admin - excluir historico de software                                                               admin     info                ADMIN - Excluir hist�rico de software
es_UR     atencao: verifique os campos para notificacao de alteracao de hardware                              admin     info                ATENCI�N: Verifique los campos para la notificaci�n del cambio de hardware
es_UR     abrangencia                                                                                         admin     info                Amplitud
es_UR     abrir janela de coleta ao detectar alteracoes de localizacao fisica                                 admin     info                Abrir una ventana de recolecci�n para detectar cambios de localizaci�n f�sica
es_UR     acesso                                                                                              admin     info                Acceso
es_UR     acesso nao autorizado                                                                               admin     info                Acceso no autorizado
es_UR     acessos                                                                                             admin     info                Accesos
es_UR     acessos locais                                                                                      admin     info                Accesos locales
es_UR     acoes - configuracoes                                                                               admin     info                Acciones - Configuraciones
es_UR     aguarde processamento...                                                                            admin     info                Aguarde el procesamiento...
es_UR     ainda nao existem informacoes de patrimonio associadas ao local!                                    admin     info                Todav�a no existen informaciones de patrimonio asociados al local!
es_UR     ainda nao existem redes associadas ao local!                                                        admin     info                Todav�a no existen redes asociadas a los locales
es_UR     ainda nao existem usuarios associados ao local!                                                     admin     info                Todav�a no existen usuarios asociados al local
es_UR     apenas nas redes selecionadas                                                                       admin     info                Solo en las redes seleccionadas
es_UR     aplicativos (janelas) a evitar                                                                      admin     info                Aplicaciones (ventanas) a evitar
es_UR     kciq_msg modulos help                                                                               admin     info                Aqui usted podr� configurar varios m�dulos disponibles de CACIC. Cliquee sobre el modulo deseado y a continuaci�n realice las configuraciones
es_UR     aquisicao                                                                                           admin     info                Adquisici�n
es_UR     aquisicao:                                                                                          admin     info                Adquisici�n:
es_UR     aquisicoes                                                                                          admin     info                Adquisiciones
es_UR     arquivo                                                                                             admin     info                Archivo
es_UR     ksiq_msg tipos_software                                                                             admin     info                Las informaciones que deber�n ser registrados abajo se refieren a un tipo de software gerenciado por CACIC, para posteriormente ser utilizado en reportes gerenciales y/o estad�sticos, como apoyo a decisiones concernientes a la utilizaci�n de softwares en el ambiente gerencial.
es_UR     as informacoes referem-se a um tipo de software cadastrado no sistema cacic.                        admin     info                Las informaciones que aqu� se refieren es a un tipo de software registrado en el sistema CACIC.
es_UR     ksiq_msg so                                                                                         admin     info                Las informaciones de abajo se refieren a un sistema operativo instalado en el parque de computadoras inventariado por CACIC, donde el ID interna se refiere al valor enviado por el Gerente de Recolecci�n (ger_cols.exe) compuesto por
es_UR     kciq_msg detalhes de usuario help                                                                   admin     info                Las informaciones de abajo se refieren al usuario registrado en el sistema. Despues del login, sera mostrado la primera y la ultima parte del campo Nombre Completo. Al reiniciar la clave este asume el valor contenido en el campo Identificacion.
es_UR     as informacoes abaixo referem-se as caracteristicas de instalacao de sistema a serem monitorados    admin     info                Las informaciones de abajo se refieren a las caracter�sticas de la instalaci�n del sistema que ser�n monitoreados
es_UR     inclusao de local help                                                                              admin     info                Las informaciones que deberan ser registradas abajo se refieren a un local originario de la llamada al sistema CACIC. Como por ejemplo una region, un estado, un �rgano, etc.
es_UR     kciq_msg inclusao de novo usuario help                                                              admin     info                Las informaciones que deber�n ser registradas abajo de los usuarios del sistema, donde se determinara el tipo de acceso. La clave inicial sera generada autom�ticamente en funcion de la identificaci�n y se podra cambiar por el usuario en la opcion Acceso - Cambio de cable en el Menu Principal. Despues del login, seran mostradas la primera y la ultima parte del campo Nombre Completo.
es_UR     as informacoes referem-se a um local originario de chamadas ao sistema cacic                        admin     info                Las informaciones est�n referidas a un local originario de las llamadas del sistema CACIC
es_UR     as opcoes abaixo determinam como o modulo gerente devera se comportar.                              admin     info                Las opciones de abajo determinan el comportamiento del modulo gerente
es_UR     as opcoes abaixo determinam qual sera o comportamento dos agentes do                                admin     info                Las opciones de abajo determinan cual sera el comportamiento de los agentes del
es_UR     atencao                                                                                             admin     info                Atenci�n
es_UR     atencao: informe os emails separados por virgulas                                                   admin     info                Atenci�n: informe los correos separados por comas
es_UR     atencao: informe os enderecos separados por virgulas                                                admin     info                Atenci�n: informe las direcciones separadas por comas
es_UR     atencao: informe os nomes separados por virgulas                                                    admin     info                Atenci�n: informe los nombres separados por comas
es_UR     atualizando                                                                                         admin     info                Actualizando
es_UR     atualizacao especial                                                                                admin     info                Actualizaci�n Especial
es_UR     atualizacao de base de dados                                                                        admin     info                Actualizaci�n de la Base de Datos
es_UR     autorizado                                                                                          admin     info                Autorizado
es_UR     autorizados                                                                                         admin     info                Autorizados
es_UR     autorizacao                                                                                         admin     info                Autorizaci�n
es_UR     acoes selecionadas para essa rede:                                                                  admin     info                Acciones seleccionadas para esta red:
es_UR     bairro                                                                                              admin     info                Barrio
es_UR     contenha                                                                                            admin     info                CONTENGA
es_UR     cacic2                                                                                              admin     info                Cacic2
es_UR     cadastro de                                                                                         admin     info                Registro de
es_UR     cadastro de aquisicao                                                                               admin     info                Registro de Adquisici�n
es_UR     cadastro de aquisicoes                                                                              admin     info                Registro de Adquisiciones
es_UR     cadastro de local                                                                                   admin     info                Registro de locales
es_UR     cadastro de perfis de sistemas monitorados                                                          admin     info                Registro de Perfiles de los Sistemas Monitoreados
es_UR     cadastro de sistemas operacionais                                                                   admin     info                Registro de Sistemas Operativos
es_UR     cadastro de softwares                                                                               admin     info                Registro de Softwares
es_UR     cadastro de softwares po estacao                                                                    admin     info                Registro de Softwares por Estacion
es_UR     cadastro de subredes                                                                                admin     info                Registro de Subredes
es_UR     cadastro de tipos de softwares                                                                      admin     info                Registro de Tipos de Softwares
es_UR     cadastro de unidade organizacional nivel 2                                                          admin     info                Registro de Unidad Organizacional Nivel 2
es_UR     cadastro de usuarios                                                                                admin     info                Registro de Usuarios
es_UR     caminho no servidor de atualizacoes                                                                 admin     info                Camino del servidor de actualizaciones
es_UR     caminhochavevalor em registry                                                                       admin     info                Camino Clave Valor en Registro
es_UR     caminhonome do arquivo/secao/chave de arquivo ini                                                   admin     info                Camino Nombre del archivo/Seccion/Clave de Archivo INI
es_UR     campo                                                                                               admin     info                Campo
es_UR     cancelar                                                                                            admin     info                Cancelar
es_UR     caracteristicas em ambientes windows 9x/me                                                          admin     info                Caracter�sticas en ambientes Windows 9x/Me
es_UR     caracteristicas em ambientes windows nt/2000/xp/2003                                                admin     info                Caracter�sticas en ambientes Windows NT/2000/XP/2003
es_UR     cidade                                                                                              admin     info                Ciudad
es_UR     cinco                                                                                               admin     info                Cinco
es_UR     classificar softwares selecionados                                                                  admin     info                Clasificar softwares Seleccionados
es_UR     classificacao de software                                                                           admin     info                Clasificacion de Software
es_UR     clique nas colunas para ordenar                                                                     admin     info                Clickee en las columnas para Ordenar
es_UR     coleta induzida por computador                                                                      admin     info                Recolecci�n inducida por Computador
es_UR     computador                                                                                          admin     info                Computador
es_UR     computador removido!                                                                                admin     info                Computadora borrada!
es_UR     computador:                                                                                         admin     info                Computadora:
es_UR     computadores onde esta acao-configuracao nao devera ser aplicada                                    admin     info                Computadoras donde esta acci�n-configuraci�n no deber�n ser aplicados
es_UR     condicao                                                                                            admin     info                Condici�n
es_UR     configuracao basica                                                                                 admin     info                Configuraci�n B�sica
es_UR     configuracao da tela de patrimonio                                                                  admin     info                Configuraci�n de la pantalla de Patrimonio
es_UR     configuracao padrao                                                                                 admin     info                Configuraci�n Padr�n
es_UR     configuracoes do modulo gerente                                                                     admin     info                Configuraciones del Modulo Gerente
es_UR     configuracoes dos modulos agentes                                                                   admin     info                Configuraciones de los m�dulos Agentes
es_UR     confirma a remocao deste computador?                                                                admin     info                Confirma el borrado de este computador?
es_UR     confirma configuracao de                                                                            admin     info                Confirma Configuraci�n de
es_UR     confirma configuracao de acao?                                                                      admin     info                Confirma Configuraci�n de Acci�n?
es_UR     confirma configuracao de agentes?                                                                   admin     info                Confirma Configuraci�n de Agentes?
es_UR     confirma configuracao de etiqueta 1?                                                                admin     info                Confirma Configuraci�n de Etiqueta 1?
es_UR     confirma configuracao de etiqueta 1a?                                                               admin     info                Confirma Configuraci�n de Etiqueta 1a?
es_UR     confirma configuracao de etiqueta 2?                                                                admin     info                Confirma Configuraci�n de Etiqueta 2?
es_UR     confirma configuracao de etiqueta 3?                                                                admin     info                Confirma Configuraci�n de Etiqueta 3?
es_UR     confirma configuracao para coleta de patrimonio?                                                    admin     info                Confirma configuraci�n para la recolecci�n de Patrimonio?
es_UR     confirma exclusao                                                                                   admin     info                Confirma exclusi�n
es_UR     confirma exclusao de                                                                                admin     info                Confirma Exclusi�n de
es_UR     confirma exclusao de rede                                                                           admin     info                Confirma exclusi�n de la Red
es_UR     confirma exclusao de perfil de sistema monitorado?                                                  admin     info                Confirma exclusi�n del perfil del sistema monitoreado?
es_UR     confirma exclusao de usuario?                                                                       admin     info                Confirma Exclusi�n de Usuario?
es_UR     confirma exclusao do local e todas as suas dependencias?                                            admin     info                Confirma Exclusi�n de Local y TODAS SUS DEPENDENCIAS?
es_UR     confirma exclusao?                                                                                  admin     info                Confirma Exclusi�n?
es_UR     confirma inclusao de local?                                                                         admin     info                Confirma Inlcusi�n de Local?
es_UR     confirma inclusao de usuario?                                                                       admin     info                Confirma Inclusi�n de Usuario?
es_UR     confirma informacoes para                                                                           admin     info                Confirma Informaciones para
es_UR     confirma informacoes para o local?                                                                  admin     info                Confirma Informaciones para el Local?
es_UR     confirma informacoes para perfil de sistema monitorado?                                             admin     info                Comfirma informaciones para el perfil del sistema monitoreado?
es_UR     confirma informacoes para usuario?                                                                  admin     info                Confirma informaciones para el usuario?
es_UR     confirma troca de senha?                                                                            admin     info                Confirma cambio de clave?
es_UR     consulta de softwares autorizados por orgao                                                         admin     info                Consulta de softwares autorizados por organo
es_UR     consulta quantidade de licencas                                                                     admin     info                Consulta cantidad de licencias
es_UR     consultar                                                                                           admin     info                Consultar
es_UR     contato                                                                                             admin     info                Contacto
es_UR     contatos para a subrede                                                                             admin     info                Contactos para la subred
es_UR     conteudo do repositorio                                                                             admin     info                Contenido de repositorio
es_UR     conteudo do servidor de atualizacoes                                                                admin     info                Contenido del servidor de actualizaciones
es_UR     dd/mm/aaaa                                                                                          admin     info                DD/MM/AAAA
es_UR     diferente de                                                                                        admin     info                DIFERENTE DE
es_UR     data                                                                                                admin     info                Fecha
es_UR     data de autorizacao:                                                                                admin     info                Fecha de Autorizaci�n:
es_UR     data de desinstalacao:                                                                              admin     info                Fecha de desintalaci�n:
es_UR     data de expiracao:                                                                                  admin     info                Fecha de Expiraci�n:
es_UR     data de arquivo                                                                                     admin     info                Fecha del archivo
es_UR     data de autorizacao e um campo obrigatorio!                                                         admin     info                Fecha de actualizaci�n es un campo obligatorio!
es_UR     data e hora                                                                                         admin     info                Fecha y Hora:
es_UR     definir as configuracoes para sugestoes em formularios                                              admin     info                Definir las configuraciones para sugestiones en formularios
es_UR     desabilitar acao-configuracao nas redes                                                             admin     info                Deshabilitar acci�n-configuraci�n en las redes
es_UR     descripcao                                                                                          admin     info                Descripci�n
es_UR     descricao do tipo de software:                                                                      admin     info                Descripci�n de Tipo de Software:
es_UR     descricao                                                                                           admin     info                Descripci�n
es_UR     descricao do tipo de acesso                                                                         admin     info                Descripci�n de tipo de acceso
es_UR     descricao:                                                                                          admin     info                Descripci�n:
es_UR     destacar as seguintes duplicidades no relatorio de patrimonio                                       admin     info                Destacar los siguientes duplicados en el reporte de Patrimonio
es_UR     destacar duplicidades neste campo                                                                   admin     info                Destacar los duplicados de este campo
es_UR     detalhes da subrede                                                                                 admin     info                Detalles de la subred
es_UR     detalhes de                                                                                         admin     info                Detalles de
es_UR     detalhes de perfil de sistema monitorado                                                            admin     info                Detalles del perfil del sistema monitoreado
es_UR     detalhes de usuario                                                                                 admin     info                Detalles de usuario
es_UR     detalhes do local                                                                                   admin     info                Detalles del Local
es_UR     detalhes do software                                                                                admin     info                Detalles del Software
es_UR     detalhes do tipo de software                                                                        admin     info                Detalles de Tipo de Software
es_UR     deve-se ter o cuidado quanto a sensibilidade no uso de letras maiusculas e minusculas.              admin     info                Se debe tener cuidado con el uso de may�sculas y min�sculas
es_UR     dez                                                                                                 admin     info                Diez
es_UR     dica: use shift ou ctrl para selecionar multiplos itens                                             admin     info                Ayuda: use SHIFT o CTRL para seleccionar m�ltiples items
es_UR     digite a porta ftp do servidor de atualizacoes                                                      admin     info                Digite el puerto del servidor FTP de actualizaciones
es_UR     digite o identificador do servidor de banco de dados                                                admin     info                Digite el identificador del Servidor de la Base de Datos
es_UR     digite o nome do usuario para login no servidor de atualizacoes pelo modulo agente                  admin     info                Digite el nombre del usuario para el login al servidor de actualizaciones para el modulo Agente
es_UR     digite o nome do usuario para login no servidor de atualizacoes pelo modulo gerente                 admin     info                Digite el nombre del usuario para el login del servidor de actualizaciones por el modulo Gerente
es_UR     digite o caminho no servidor de atualizacoes                                                        admin     info                Digite el camino del servidor de actualizaciones
es_UR     digite o identificador do servidor de atualizacoes                                                  admin     info                Digite el identificador del servidor de actualizaciones
es_UR     digite pelo menos 03 caracteres...                                                                  admin     info                Digite por los menos 3 caracteres
es_UR     disponibilizar informacoes ao usuario comum?                                                        admin     info                Disponibilizar informaciones para el usuario comun?Dsi
es_UR     disponibilizar informacoes no systray?                                                              admin     info                Disponibilizar informaciones no Systray?
es_UR     disponiveis                                                                                         admin     info                Disponibles
es_UR     divisao                                                                                             admin     info                Division
es_UR     divisoes                                                                                            admin     info                Divisiones
es_UR     dois                                                                                                admin     info                Dos
es_UR     doze                                                                                                admin     info                Doce
es_UR     e-mails para notificar alteracoes de hardware                                                       admin     info                Correos para notificar las alteraciones del hardware
es_UR     eh necessario informar ao menos uma condicao para pesquisa                                          admin     info                Es necesario informar al menos una condici�n para la busqueda
es_UR     eh um sistema operacional?                                                                          admin     info                Es un sistema operativo???
es_UR     emails para contato                                                                                 admin     info                Emails para Contacto
es_UR     endereco                                                                                            admin     info                Direcci�n
es_UR     endereco ip                                                                                         admin     info                Direcci�n IP
es_UR     endereco ip origem                                                                                  admin     info                Direcci�n IP origen
es_UR     endereco mac                                                                                        admin     info                Direcci�n MAC
es_UR     endereco eletronico                                                                                 admin     info                Direcci�n electronica
es_UR     endereco/mascara                                                                                    admin     info                Direcci�n/Mascara
es_UR     enderecos mac a desconsiderar                                                                       admin     info                Direcciones MAC a descartar
es_UR     enderooso eletronicos a notificar ao detectar alteracoes de patrimonio ou localizacao fisica        admin     info                Direcciones electr�nicas para notificar al detectar modificaciones en el patrimonio o localizacion fisica
es_UR     enviando                                                                                            admin     info                Enviando
es_UR     enviando...                                                                                         admin     info                Enviando...
es_UR     erro no select ou sua sessao expirou                                                                admin     info                Error en el select o su sesi�n de trabajo termino
es_UR     erro no select ou sua sessao expirou!                                                               admin     info                Error en el select o su sesi�n de trabajo termino
es_UR     esta opcao permite a selecao final para exclusao dos computadores selecionados na pesquisa          admin     info                Esta opci�n permite la seleccion final para la exclusi�n de las computadoras seleccionadas en la b�squeda
es_UR     kciq_msg excluir computadores advise                                                                admin     info                Esta opci�n permite la exclusi�n de las informaciones almacenadas en la base sobre las estaciones monitoreadas. Se debe tomar mucho cuidado con la
es_UR     kciq_msg mac address help                                                                           admin     info                Esta opci�n tiene por finalidad informar a los agentes recolectores de informaciones de TCP/IP acerca de las direcciones MAC invalidas, o sea, las direcciones utilizadas como padrones en protocolos y/o disposiitivos diferentes de TCP/Ethernet. Los recolectores consideraran solo las direcciones MAC diferentes o que no contengan informaciones aqui recolectadas, pudiendo ser partes de
es_UR     esta pagina permite induzir coletas em determinado computador                                       admin     info                Esta pagina permite inducir recolecci�n en determinado computador
es_UR     estacao                                                                                             admin     info                Estaci�n
es_UR     kciq_msg log de atividades help                                                                     admin     info                Este modulo permite la visualizaci�n de las actividades realizadas con el uso de las operaciones de INSERT/UPDATE/DELETE ocurridas en el Sistema CACIC. Una ordenacion de las columnas podr� ser definida clickeando en sus nombres.
es_UR     ksiq_msg insuceso help                                                                              admin     info                Este modulo permite la visualizaci�n de las tentativas de instalaci�n de los agentes cuyos resultados sean un INSUCESO.
es_UR     kciq_msg log de acessos help                                                                        admin     info                Este modulo permite la visualizaci�n de los accesos efectuados en el sistema. Es  posible visualizar las actividades ejecutadas por el usuario en una fecha, basta clickear sobre una de sus informaciones.
es_UR     etiqueta 1                                                                                          admin     info                Etiqueta 1
es_UR     etiqueta 1a                                                                                         admin     info                Etiqueta 1a
es_UR     etiqueta 2                                                                                          admin     info                Etiqueta 2
es_UR     etiqueta 3                                                                                          admin     info                Etiqueta 3
es_UR     evita que o gerente de coletas seja acionado enquanto tais aplicativos (janelas) estiverem ativos   admin     info                Evita que el Gerente de Recolecci�n sea accionado cuando estas aplicaciones (ventanas) esten activas
es_UR     excluir                                                                                             admin     info                Excluir
es_UR     excluir computadores                                                                                admin     info                Excluir Computadoras
es_UR     excluir local                                                                                       admin     info                Excluir local
es_UR     excluir computadores selecionados                                                                   admin     info                Excluir computadoras seleccionadas
es_UR     excluir perfil de sistema monitorado                                                                admin     info                Excluir perfil del sistema monitoreado
es_UR     excluir rede                                                                                        admin     info                Excluir Red
es_UR     excluir usuario                                                                                     admin     info                Excluir Usuario
es_UR     exclusao de softwares                                                                               admin     info                Exclusi�n de software
es_UR     exclusao de softwares nao associados a nenhuma maquina                                              admin     info                Exclusi�n de softwares no asociados a ninguna computadora
es_UR     executado apenas nas redes selecionadas                                                             admin     info                Ejecutado solo en las redes seleccionadas
es_UR     executado em todas as redes                                                                         admin     info                Ejecutado en todas las redes
es_UR     exemplo                                                                                             admin     info                Ejemplo
es_UR     exemplo:                                                                                            admin     info                Ejemplo:
es_UR     exemplo: arquivos de programascacicdadosconfig.ini/patrimonio/nu_cpu                                admin     info                Ejemplo: Archivos de ProgramasCacicDatosConfig.ini/Patrimonio/nu_CPU
es_UR     exemplo: hkey_local_machinesoftwaredataprevcacic2id_versao                                          admin     info                Ejemplo: HKEY_LOCAL_MACHINESoftwaresDATAPREVCacic2id_version
es_UR     exibe janela de patrimonio                                                                          admin     info                Muestra ventana de patrimonio
es_UR     exibe os softwares inventariados nos computadores que nao estao associados a nenhuma maquina.       admin     info                Muestra los programas inventariados en las computadoras que no est�n asociadas a ninguna maquina.
es_UR     exibir                                                                                              admin     info                Mostrar
es_UR     exibir graficos na pagina principal e detalhes                                                      admin     info                Mostrar Graficos en la Pagina Principal y detalles
es_UR     exibir erros criticos aos usuarios                                                                  admin     info                Mostrar errores criticos a los usuarios
es_UR     exibir o icone do cacic na bandeja (systray)                                                        admin     info                Mostrar el icono de CACIC en la bandeja (systray)
es_UR     ftp nao configurado                                                                                 admin     info                FTP no configurado
es_UR     falha em exclusao na tabela (%1) ou sua sessao expirou!                                             admin     info                Falla en la exclusion en la tabla (%1) o su sesion de trabajo finalizo
es_UR     falha em inclusao na tabela (%1) ou sua sessao expirou!                                             admin     info                Falla en la inclusi�n en la tabla (%1) o su sessi�n expir�!!
es_UR     falha na consulta a tabela (%1) ou sua sessao expirou!                                              admin     info                Falla en la Consulta de la tabla (%1) o su sesion de trabajo finalizo
es_UR     falha na insercao em (%1) ou sua sessao expirou!                                                    admin     info                Falla en la inserci�n en (%1) o su sesion de trabajo finalizo
es_UR     falha na atualizacao da tabela (%1) ou sua sessao expirou!                                          admin     info                Falla en la actualizaci�n en (%1) o su sesi�n de trabajo finalizo
es_UR     falha na atualizacao de configuracoes                                                               admin     info                Falla en la actualizaci�n de configuraciones
es_UR     falha na atualizacao na tabela (%1) ou sua sessao expirou!                                          admin     info                Falla en las actualizaciones en la tabla (%1) o su sesi�n de trabajo finalizo
es_UR     falha na exclusao de configuracoes                                                                  admin     info                Falla en la exclusi�n de configuraciones
es_UR     formato da data                                                                                     admin     info                Formato de fecha
es_UR     formulario para classificacao de softwares                                                          admin     info                Formulario para la clasificaci�n de softwares
es_UR     formulario para importar dados de aquisicoes                                                        admin     info                Formulario para importar datos de adquisiciones
es_UR     formulario para importar dados de itens de aquisicoes                                               admin     info                Formulario para importar datos de items de adquisiciones
es_UR     formulario para importar dados de software                                                          admin     info                Formulario para importar datos de software
es_UR     gercols                                                                                             admin     info                GerCols
es_UR     gerado em                                                                                           admin     info                Generado el
es_UR     gerado por                                                                                          admin     info                Generado por
es_UR     gerafo em                                                                                           admin     info                Generado en
es_UR     gerencia                                                                                            admin     info                Gerencia
es_UR     gerencias                                                                                           admin     info                Gerencias
es_UR     graficos a serem exibidos                                                                           admin     info                Gr�ficos a ser mostrados
es_UR     gravar                                                                                              admin     info                Grabar
es_UR     gravar alteracoes                                                                                   admin     info                Grabar modificaciones
es_UR     gravar alteracoes?                                                                                  admin     info                Grabar modificaciones??
es_UR     gravar informacoes                                                                                  admin     info                Grabar informaciones
es_UR     hod - microsoft word - corel draw - photoshop                                                       admin     info                HOD - Microsoft Word - Corel Draw - PhotoShop
es_UR     habilitar acao-configuracao em todas as redes                                                       admin     info                Habilitar acci�n-configuraci�n en todas las redes
es_UR     consulta quantidade de licencas help                                                                admin     info                Habiendo saldo positivo en una versi�n no implica disponibilidad de licencias. El Saldo puede estar cubriendo un saldo negativo de las versiones anteriores.
es_UR     resumo quantitativo de licencas help                                                                admin     info                Habiendo saldo positivo en una versi�n no implica disponibilidad de licencias. El Saldo puede estar cubriendo un saldo negativo de las versiones anteriores.
es_UR     historico                                                                                           admin     info                Hist�rico
es_UR     historio de softwares excluidos com sucesso da base de dados                                        admin     info                Historia de softwares excluidos con �xito de la base de datos
es_UR     igual a                                                                                             admin     info                Igual a
es_UR     inicie com                                                                                          admin     info                Inicie con
es_UR     ip gerente                                                                                          admin     info                IP Gerente
es_UR     ip origem                                                                                           admin     info                IPOrigen
es_UR     ip de estacao e rede                                                                                admin     info                IP de estaci�n y red
es_UR     ide                                                                                                 admin     info                Ide
es_UR     identificacao                                                                                       admin     info                Identificaci�n
es_UR     identificador de instalacao                                                                         admin     info                Identificador de la instalaci�n
es_UR     identificador de licenca                                                                            admin     info                Identificador de la licencia
es_UR     identificador de versao/configuracao                                                                admin     info                Identificador de la versi�n/configuraci�n
es_UR     imediatamente apos a inicializacao do cacic                                                         admin     info                Inmediatamente despu�s de la inicializaci�n de CACIC
es_UR     importante                                                                                          admin     info                Importante
es_UR     importante:                                                                                         admin     info                Importante:
es_UR     incluir                                                                                             admin     info                Incluir
es_UR     incluir aquisicao                                                                                   admin     info                Incluir adquisici�n
es_UR     incluir informacoes de novo tipo de software                                                        admin     info                Incluir Informaci�n de Nuevo Tipo de Software
es_UR     incluir informacoes de novo local                                                                   admin     info                Incluir informaciones del Nuevo Local
es_UR     incluir nova subrede                                                                                admin     info                Incluir Subred Nueva
es_UR     incluir novo perfil de sistema                                                                      admin     info                Incluir Nuevo Perfil de Sistema
es_UR     incluir novo sistema operacional                                                                    admin     info                Incluir Nuevo Sistema Operativo
es_UR     incluir novo software                                                                               admin     info                Incluir nuevo software
es_UR     incluir novo usuario                                                                                admin     info                Incluir nuevo Usuario
es_UR     inclusao de tipo de software                                                                        admin     info                Inclusi�n de Tipo de Software
es_UR     inclusao                                                                                            admin     info                Inclusi�n
es_UR     inclusao de local                                                                                   admin     info                Inclusi�n de Local
es_UR     inclusao de novo usuario                                                                            admin     info                Inclusi�n de nuevo usuario
es_UR     induzir coletas                                                                                     admin     info                Forzar recolecci�n
es_UR     informacoes de patrimonio associadas ao local                                                       admin     info                Informaciones de Patrimonio Asociados al Local
es_UR     informe a classificacao para o software.                                                            admin     info                Informe de clasificaci�n para los softwares.
es_UR     informe a senha anterior, caso nao se lembre, solicite a um administrador que a reinicialize.       admin     info                Informe de clave anterior. en caso de no recordar, solicite a un administrador que la reinicialize
es_UR     informe o endereco mac do computador.                                                               admin     info                Informe la MAC de la computadora
es_UR     informe o numero do processo:                                                                       admin     info                Informe el numero del proceso:
es_UR     informe o periodo em que foi realizada a aquisicao:                                                 admin     info                Informe el periodo en que fue realizada la adquisicion:
es_UR     informe o setor onde esta localizado o equipamento.                                                 admin     info                Informe el sector donde esta localizado el equipamiento
es_UR     informe os enderecos eletronicos separados por virgulas                                             admin     info                Informe las direcciones electr�nicas separadas por comas
es_UR     inicio de execucao das acoes                                                                        admin     info                Inicio de ejecuci�n de las acciones
es_UR     instalacoes                                                                                         admin     info                Instalaciones
es_UR     intervalo de execucao das acoes                                                                     admin     info                Intervalo de ejecuci�n de las acciones
es_UR     intervalo de solicitacao aos usuarios de renovacao das informacoes de patrimonio e local fisica     admin     info                Intervalo para solicitar los usuarios de renovaci�n de las informaciones de patrimonio y local f�sico.
es_UR     legenda                                                                                             admin     info                Leyenda
es_UR     licencas                                                                                            admin     info                Licencias
es_UR     licencas autorizadas por estacao                                                                    admin     info                Licencias autorizadas por estacion
es_UR     limite de conexoes ftp                                                                              admin     info                Limite de conexiones FTP
es_UR     linha de negocio                                                                                    admin     info                Linea de Negocio
es_UR     linhas de negocios                                                                                  admin     info                Lineas de Negocios
es_UR     locais                                                                                              admin     info                Locales
es_UR     locais secundarios                                                                                  admin     info                Locales secundarios
es_UR     local                                                                                               admin     info                Local
es_UR     local da midia                                                                                      admin     info                Local de Media
es_UR     local de aplicacao                                                                                  admin     info                Local de Aplicacion
es_UR     local/rede                                                                                          admin     info                Local/Red
es_UR     localizacao da midia:                                                                               admin     info                Localizacion de Media:
es_UR     log de acessos                                                                                      admin     info                Log de Accesos
es_UR     log de atividades                                                                                   admin     info                Log de Actividades
es_UR     log de insucessos nas instalacoes dos agentes                                                       admin     info                Log de insucesos en las instalaciones de los Agentes
es_UR     maior que                                                                                           admin     info                Mayor que
es_UR     menor que                                                                                           admin     info                Menor que
es_UR     manutencao de redes/subredes                                                                        admin     info                Mantenimiento de redes/Subredes
es_UR     maquinas                                                                                            admin     info                Maquinas
es_UR     mascara                                                                                             admin     info                Mascara
es_UR     mecanismo para atualizacao de arquivos diversos no servidor, no ambito da aplicacao.                admin     info                Mecanismo para actualizacion de diversos archivos en el servidor, en el ambito de la aplicacion
es_UR     mensagens                                                                                           admin     info                Mensajes
es_UR     modulo para atualizacao das informacoes coletadas dos modulos gerentes descentralizados             admin     info                Modulo para la actualizaci�n de las informaciones recolectadas de los m�dulos gerentes descentralizados
es_UR     modulo para cadastramento de unidades organizacionais de nivel 1                                    admin     info                Modulo para recolecci�n de Unidades Organizacionales de Nivel 1
es_UR     modulo para cadastramento de unidades organizacionais de nivel 1a                                   admin     info                Modulo para recolecci�n de Unidades Organizacionales de Nivel 1a
es_UR     modulo para cadastramento de unidades organizacionais de nivel 2                                    admin     info                Modulo para recolecci�n de Unidades Organizacionales de Nivel 2
es_UR     modulo para cadastramento manual de softwares por estacao                                           admin     info                Modulo para registro manual de softwares por estaci�n
es_UR     modulos                                                                                             admin     info                M�dulos
es_UR     mostrar todos                                                                                       admin     info                Mostrar todos
es_UR     motivo                                                                                              admin     info                Motivo
es_UR     kciq_msg cadastro de softwares help                                                                 admin     info                Modulo para registro manual de software para despu�s ser utilizado como referencia junto con los datos de las licencias
es_UR     nao contenha                                                                                        admin     info                No Contenga
es_UR     nao atualizado                                                                                      admin     info                No actualizado
es_UR     nao enviado                                                                                         admin     info                No Enviado
es_UR     nao ha registro de aquisicao de softwares                                                           admin     info                No hay registro de Adquisici�n de Softwares
es_UR     nao classificados:                                                                                  admin     info                No clasificados
es_UR     nao e executado em nenhuma rede                                                                     admin     info                No es ejecutado en ninguna red
es_UR     nao foi possivel excluir o arquivo %1. verifique as permissoes de escrita no diretorio repositorio! admin     info                No fue posible excluir el archivo %1. Verifique los permisos de escritura en el directorio del repositorio.
es_UR     nao foi possivel gravar o registro!                                                                 admin     info                No fue posible grabar el registro!
es_UR     nao foi selecionada nenhuma rede. deseja continuar?                                                 admin     info                No fue seleccionada ninguna red. Desea continuar?
es_UR     nao foi selecionado nenhum sistema operacional. deseja continuar?                                   admin     info                No fue seleccionado ningun sistema operativo. Desea continuar?
es_UR     nao foram encontrados registros                                                                     admin     info                No fueron encontrados registros
es_UR     nao ha autorizacao para esta maquina                                                                admin     info                No tiene autorizaci�n para esta maquina
es_UR     nao ha historico desta maquina                                                                      admin     info                No tiene hist�rico de esta maquina
es_UR     nao instalados:                                                                                     admin     info                No instalados
es_UR     nao solicitar renovacao                                                                             admin     info                No solicitar renovaci�n
es_UR     nenhum acesso realizado no periodo informado                                                        admin     info                Ningun acceso realizado en el periodo informado
es_UR     nenhum local cadastrado ou sua sessao expirou                                                       admin     info                Ningun local registrado o su sesion finalizo
es_UR     nenhum registro encontrado!                                                                         admin     info                Ning�n registro encontrado!
es_UR     nenhum software cadastrado                                                                          admin     info                Ning�n software registrado
es_UR     nenhum usuario cadastrado ou sua sessao expirou!                                                    admin     info                Ning�n usuario registrado o su sesi�n finalizo!
es_UR     nenhuma unidade organizacional de nivel %1 cadastrada                                               admin     info                Ninguna Unidad Organizacional de Nivel %1 registrada
es_UR     nenhuma acao realizada no periodo informado.                                                        admin     info                Ninguna acci�n realizada en el periodo informado
es_UR     nenhuma acao selecionada para essa rede!                                                            admin     info                Ninguna acci�n seleccionada para esta red!
es_UR     nenhuma atividade realizada no periodo informado                                                    admin     info                Ninguna actividad realizada en el periodo informado
es_UR     nenhuma rede cadastrada ou sua sessao expirou!                                                      admin     info                Ninguna red fue registrada o su sesi�n expiro!
es_UR     kciq_msg repositorio help                                                                           admin     info                En esta pagina es posible verificar el contenido del repositorio, bien como excluir objetos que no seran utilizados en las actualizaciones de las Subredes
es_UR     ksiq_msq sistemas_operacionais                                                                      admin     info                En este m�dulo se deber�n registrar los sistemas operativos instalados en el parque de computadoras monitoreado.
es_UR     neste modulo deverao ser cadastrados todos os tipos dos softwares manipulados pelo sistema          admin     info                En este m�dulo deber�n ser registrados todos los tipos de softwares manejados por el sistema
es_UR     neste modulo deverao ser cadastrados os softwares avulsos, manipulados pelo sistema                 admin     info                En este m�dulo se deber� registrar los softwares copiados, manejados por el sistema
es_UR     neste modulo deverao ser cadastrados os usuarios que acessarao o sistema.                           admin     info                En este modulo deber�n ser registrados los usuarios que acceder�n al sistema.
es_UR     ksiq_msg subredes help                                                                              admin     info                En este modulo deber�n ser registradas todas las subredes donde los agentes de CACIC ser�n instalados.
es_UR     ksiq_msg perfis                                                                                     admin     info                En este modulo deber�n ser registrados los perfiles de los sistemas que ser�n monitoreados por CACIC.
es_UR     ksiq_msg cadastro help                                                                              admin     info                En este modulo deber�n ser registrados todos los locales originales al sistema, para que sea posible el control centralizado
es_UR     nivel                                                                                               admin     info                Nivel
es_UR     nivel de acesso                                                                                     admin     info                Nivel de Acceso
es_UR     nome                                                                                                admin     info                Nombre
es_UR     nome completo                                                                                       admin     info                Nombre Completo
es_UR     nome da empresa:                                                                                    admin     info                Nombre de la empresa:
es_UR     nome da maquina                                                                                     admin     info                Nombre de la maquina
es_UR     nome da organizacao                                                                                 admin     info                Nombre de la organizaci�n
es_UR     nome da organizacao-empresa-orgao                                                                   admin     info                Nombre de la organizaci�n-empresa-�rgano
es_UR     nome da rede                                                                                        admin     info                Nombre de la Red
es_UR     nome de executavel                                                                                  admin     info                Nombre del ejecutable
es_UR     nome de rede                                                                                        admin     info                Nombre de la red
es_UR     nome do computador                                                                                  admin     info                Nombre del computador
es_UR     nome do local                                                                                       admin     info                Nombre del local
es_UR     nome do software                                                                                    admin     info                Nombre del Software
es_UR     nome do proprietario:                                                                               admin     info                Nombre del propietario:
es_UR     nome do sistema:                                                                                    admin     info                Nombre del sistema
es_UR     nome e um campo obrigatorio!                                                                        admin     info                Nombre es un campo obligatorio!
es_UR     nome ou ip do servidor de aplicacao (gerente)                                                       admin     info                Nombre o IP del servidor de aplicaci�n (gerente)
es_UR     nome ou ip do servidor de atualizacao (ftp)                                                         admin     info                Nombre o IP del servidor de actualizaci�n (FTP)
es_UR     nova senha                                                                                          admin     info                Nueva Clave
es_UR     nove                                                                                                admin     info                Nueve
es_UR     numero da midia                                                                                     admin     info                Numero de Media
es_UR     numero da midia:                                                                                    admin     info                Numero de Media:
es_UR     numero da nota fiscal:                                                                              admin     info                Numero de la nota fiscal:
es_UR     numero do patrimonio                                                                                admin     info                Numero del patrimonio
es_UR     numero do processo:                                                                                 admin     info                Numero del proceso
es_UR     nao                                                                                                 admin     info                NO
es_UR     ksiq_msg not                                                                                        admin     info                No
es_UR     o aplicativo (%1) ja esta cadastrado                                                                admin     info                La aplicaci�n (%1) ya esta registrado
es_UR     o campo nome do aplicativo e obrigatorio.                                                           admin     info                El campo nombre de la aplicaci�n es obligatorio.
es_UR     o local da rede e obrigatorio                                                                       admin     info                El local de la red es obligatorio
es_UR     o nome do local e obrigatorio                                                                       admin     info                El nombre del local es obligatorio
es_UR     ok                                                                                                  admin     info                OK
es_UR     observacao                                                                                          admin     info                Observaci�n
es_UR     observacao:                                                                                         admin     info                Observaci�n:
es_UR     observacoes                                                                                         admin     info                Observaciones
es_UR     ocorreu erro no processamento...                                                                    admin     info                Ocurri� un error en el procesamiento...
es_UR     ocorreu um erro durante a atualizacao da tabela %1 ou sua sessao expirou                            admin     info                Ocurri� un error durante la actualizaci�n de la tabla %1 o su sesi�n finalizo
es_UR     ocorreu um erro durante a consulta a tabela tipos_software ou sua sessao expirou!                   admin     info                Ocurri� un error durante la consulta de las tablas tipos_software o su sesi�n esta finalizada!
es_UR     ocorreu um erro durante exclusao de referencia em %1 ou sua sessao expirou!                         admin     info                Ocurri� un error durante la exclusi�n de referencia de la tabla %1 o su sesi�n finalizo
es_UR     ocorreu um erro no acesso a tabela %1 ou sua sessao expirou                                         admin     info                Ocurri� un error en el acceso a la tabla %1 o su sesion expiro
es_UR     ocorreu um erro no select ou sua sessao expirou!                                                    admin     info                Ocurri� un error en el select o su sesi�n finalizo
es_UR     ocorreu um erro no select ou sua sessão expirou!                                                   admin     info                Ocurri� un error en el select o su sesi�n finalizo
es_UR     oito                                                                                                admin     info                Ocho
es_UR     ok!                                                                                                 admin     info                OK!
es_UR     onde executar essa acao-configuracao                                                                admin     info                Donde ejecutar esta acci�n-configuraci�n
es_UR     onze                                                                                                admin     info                Once
es_UR     opcoes avancadas                                                                                    admin     info                Opciones avanzadas
es_UR     opcoes da coleta de informacoes patrimoniais e localizacao fisica                                   admin     info                Opciones de la recolecci�n de informaciones Patrimoniales y Localizaci�n F�sica
es_UR     operacao                                                                                            admin     info                Operaci�n
es_UR     outros                                                                                              admin     info                Otros
es_UR     tela de coleta de informacoes de patrimonio - ajuda                                                 admin     info                Para configurar una interface de la pantalla de recoleccion de informaciones de patrimonio que seran mostradas a los usuarios, cliquee sobre los items de la pantalla de abajo e informe los valores deseados.
es_UR     particular                                                                                          admin     info                Particular
es_UR     patrimonio                                                                                          admin     info                Patrimonio
es_UR     patrimonio de destino:                                                                              admin     info                Patrimonio de Destino:
es_UR     patrimonio e um campo obrigatorio!                                                                  admin     info                Patrimonio es un campo obligatorio!
es_UR     patrimonio:                                                                                         admin     info                Patrimonio:
es_UR     percentual                                                                                          admin     info                Porcentual
es_UR     plural de texto da                                                                                  admin     info                Plural del testo da:
es_UR     por favor, preencha campo                                                                           admin     info                Por favor, complete campo
es_UR     por favor, selecione                                                                                admin     info                Por favor, seleccione
es_UR     kciq_msg help - induzir o envio das informacoes coletadas                                           admin     info                Por padr�n, los agentes de CACIC solo enviaran las informaciones recolectadas para el servidor en caso que sea identificado alguna modificaci�n en relaci�n con la recolecci�n anterior. Abajo estan relacionadas las acciones de recoleccion posibles y las redes habilitadas via opcion Administracion/Modulos. en caso que que selecciones alguna red abajo, el envio de las informaciones recolectadas seran forzadas, o sea, las informaciones seran enviadas al M�dulo Gerente aunque sean identicas a la de la ultima recoleccion.
es_UR     porta                                                                                               admin     info                Puerto
es_UR     processamento realizado com sucesso                                                                 admin     info                Procesamiento realizado con �xito
es_UR     processo                                                                                            admin     info                Proceso
es_UR     processo:                                                                                           admin     info                Proceso:
es_UR     script                                                                                              admin     info                Programa
es_UR     programa                                                                                            admin     info                Programa
es_UR     proprietario                                                                                        admin     info                Propietario
es_UR     quant.                                                                                              admin     info                Cant.
es_UR     quantidade                                                                                          admin     info                Cantidad
es_UR     quantidade comprada                                                                                 admin     info                Cantidad comprada
es_UR     quantidade instalada                                                                                admin     info                Cantidad instalada
es_UR     quantidade de licencas                                                                              admin     info                Cantidad de licencias
es_UR     quantidade de licencas:                                                                             admin     info                Cantidad de Licencias:
es_UR     quantidade de licencas e um campo obrigatorio!                                                      admin     info                Cantidad de licencias es un campo obligatorio
es_UR     quantidade maxima de linhas em relatorios                                                           admin     info                Cantidad m�xima de lineas en los reportes
es_UR     quatro                                                                                              admin     info                Cuatro
es_UR     realizada com sucesso                                                                               admin     info                Realizada con �xito
es_UR     realizar notificacao caso haja alteracoes nas seguintes configuracoes de hardware                   admin     info                Realizar notificaciones en caso de que hayan alteraciones en las siguientes configuraciones de hardware
es_UR     rede                                                                                                admin     info                Red
es_UR     redes                                                                                               admin     info                Redes
es_UR     redes associadas ao local                                                                           admin     info                Redes asociadas al local
es_UR     registro gravado!                                                                                   admin     info                Registro grabado!
es_UR     reinicializar senha                                                                                 admin     info                Reiniciar clave
es_UR     relatorio de aquisicoes de software                                                                 admin     info                Reporte de Adquisiciones de software
es_UR     relatorio de aquisicoes de software particular                                                      admin     info                Reporte de Adquisiciones de Software Particular
es_UR     relatorio de autorizacoes cadastradas                                                               admin     info                Reporte de Autorizaciones Registradas
es_UR     relatorio de cadastros inconsistentes                                                               admin     info                Reporte de registros inconsistentes
es_UR     relatorio de instalacoes de software                                                                admin     info                Reporte de Instalaciones de Software
es_UR     relatorio de instalacoes de software particular                                                     admin     info                Reporte de Instalaciones de Software Particular
es_UR     relatorio de inventario de softwares                                                                admin     info                Reporte de Inventario de Softwares
es_UR     relatorio de processos de compra de software                                                        admin     info                Reporte de Procesos de Compra de Software
es_UR     relatorio de softwares adquiridos                                                                   admin     info                Reporte de Softwares Adquiridos
es_UR     relatorio de softwares inventariados                                                                admin     info                Reporte de Softwares Inventariados
es_UR     relatorio de softwares inventariados por maquinas                                                   admin     info                Reporte de Softwares Inventariados por Maquinas
es_UR     relatorio de softwares particulares                                                                 admin     info                Reporte de Softwares Particulares
es_UR     relatorio de softwares por aquisicao                                                                admin     info                Reporte de Software por Adquisici�n
es_UR     relatorio de softwares por processo                                                                 admin     info                Reporte de Softwares por Proceso
es_UR     relatorio de cadastros inconsistentes ii                                                            admin     info                Reporte de registros inconsistentes!!!
es_UR     relatorio gerado pelo                                                                               admin     info                Reporte generado por
es_UR     remocao de computador                                                                               admin     info                Remover computador
es_UR     remover softwares da base de dados                                                                  admin     info                Remover Softwares de la Base de Datos
es_UR     repositorio                                                                                         admin     info                Repositorio
es_UR     responsavel                                                                                         admin     info                Responsable
es_UR     restaurar valores                                                                                   admin     info                Restaurar valores
es_UR     resultado da consulta                                                                               admin     info                Resultado de la consulta
es_UR     resumo das operacoes                                                                                admin     info                Resumen de las Operaciones
es_UR     resumo das tentativas de instalacao                                                                 admin     info                Resumen de las tentativas de Instalaci�n
es_UR     resumo quantitativo de licencas                                                                     admin     info                Resumen cuantitativo de licencias
es_UR     retorna aos detalhes de local                                                                       admin     info                Devuelve los detalles del Local
es_UR     retorna para                                                                                        admin     info                Vuelve a
es_UR     seja nulo                                                                                           admin     info                Sea Nulo
es_UR     seja vazio                                                                                          admin     info                Sea Vacio
es_UR     saldo                                                                                               admin     info                Saldo
es_UR     seis                                                                                                admin     info                Seis
es_UR     selecao de redes para aplicacao desta coleta de informacoes                                         admin     info                Selecci�n de las redes para la aplicaci�n de la recolecci�n de informaciones
es_UR     selecionadas                                                                                        admin     info                Seleccionadas
es_UR     selecionados                                                                                        admin     info                Seleccionados
es_UR     selecionados:                                                                                       admin     info                Seleccionados:
es_UR     selecionar computadores para exclusao                                                               admin     info                Seleccionar computadoras para excluir
es_UR     selecionar novamente                                                                                admin     info                Seleccionar nuevamente
es_UR     selecione                                                                                           admin     info                Seleccione
es_UR     selecione a gerencia de localizacao este equipamento                                                admin     info                Seleccione la Gerencia de localizaci�n en este equipamiento
es_UR     selecione a linha de negocio de localizacao deste equipamento                                       admin     info                Seleccione la linea de Negocio de Localizaci�n de este equipamiento
es_UR     selecione a divisao onde encontra-se este equipamento                                               admin     info                Seleccione una divisi�n donde se encuentra este equipamiento
es_UR     selecione local                                                                                     admin     info                Seleccione local
es_UR     selecione o periodo em que devera ser realizada a consulta                                          admin     info                Seleccione el periodo en que se debera realizar la consulta
es_UR     selecione o periodo em que devera ser realizada a consulta:                                         admin     info                Seleccione el periodo en que debera ser realizada la consulta:
es_UR     selecione o periodo no qual devera ser realizada a consulta                                         admin     info                Seleccione el periodo en el cual deber� ser realizada la consulta
es_UR     selecione o software                                                                                admin     info                Seleccione el software
es_UR     selecione os filtros da consulta:                                                                   admin     info                Seleccione los filtros de la consulta:
es_UR     selecione os softwares que deseja classificar:                                                      admin     info                Seleccione los softwares que desea clasificar:
es_UR     selecione os softwares que deseja remover:                                                          admin     info                Seleccione los softwares que desean remover:
es_UR     selecione pelo menos 1 software.                                                                    admin     info                Seleccione por los menos 1 software
es_UR     selecione pelo menos um software                                                                    admin     info                Seleccione por lo menos un software
es_UR     senha                                                                                               admin     info                Clave
es_UR     senha atual                                                                                         admin     info                Clave actual
es_UR     senha padrao para administrar o agente                                                              admin     info                Clave padron para administrar el agente
es_UR     senha para admnistrar o agente                                                                      admin     info                Clave para administrar el agente
es_UR     senha usada para configurar e finalizar os agentes                                                  admin     info                Clave utilizada para configurar y finalizar los agentes
es_UR     servidor offline                                                                                    admin     info                Servidor Offline
es_UR     servidor de aplicacao padrao                                                                        admin     info                Servidor de Aplicacion principal
es_UR     servidor de atualizacoes (ftp)                                                                      admin     info                Servidor de actualizaciones (FTP)
es_UR     servidor de updates padrao                                                                          admin     info                Servidor de actualizaciones principal
es_UR     servidor de aplicacao (gerente)                                                                     admin     info                Servidor de aplicaciones (gerente)
es_UR     servidor nao encontrado                                                                             admin     info                Servidor no encontrado
es_UR     sete                                                                                                admin     info                Siete
es_UR     setor                                                                                               admin     info                Sector
es_UR     sigla do local                                                                                      admin     info                Sigla del Local
es_UR     sim                                                                                                 admin     info                SI
es_UR     sistema monitorado                                                                                  admin     info                Sistema Monitoreado
es_UR     sistema operacional                                                                                 admin     info                Sistema Operativo
es_UR     sistemas operacionais onde essa acao-configuracao devera ser aplicada                               admin     info                Sistemas Operativos donde esta acci�n-configuraci�n deber�n ser aplicados
es_UR     sistemas operacionais                                                                               admin     info                Sistemas operacionales
es_UR     software                                                                                            admin     info                Software
es_UR     software interno                                                                                    admin     info                Software interno
es_UR     software e um campo obrigatorio!                                                                    admin     info                Software es un campo obligatorio!
es_UR     software(s) classificado(s) com sucesso!                                                            admin     info                Software(s) clasificado(s) con �xito!
es_UR     software(s) deletado(s) com sucesso da base de dados.                                               admin     info                Software(s) borrado(s) con �xito de la base de datos
es_UR     softwares por aquisicao                                                                             admin     info                Software por Adquisici�n
es_UR     status                                                                                              admin     info                Estado
es_UR     sua tentativa foi registrada no log                                                                 admin     info                Su intento fue registrado en el log
es_UR     subrede                                                                                             admin     info                Subred
es_UR     sucesso na conexao ftp                                                                              admin     info                �xito con la conexi�n FTP
es_UR     termine com                                                                                         admin     info                Termine con
es_UR     tabela                                                                                              admin     info                Tabla
es_UR     tamanho (kb)                                                                                        admin     info                Tama�o (kb)
es_UR     tamanho(kb)                                                                                         admin     info                Tama�o(kb)
es_UR     tela de coleta de informacoes de patrimonio                                                         admin     info                Pantalla de recolecci�n de informaciones de Patrimonio
es_UR     telefone                                                                                            admin     info                Tel�fono
es_UR     telefones para contato                                                                              admin     info                Tel�fonos de contacto
es_UR     texto da                                                                                            admin     info                Texto de la
es_UR     texto de ajuda da                                                                                   admin     info                Texto de ayuda de la
es_UR     tipo da licenca                                                                                     admin     info                Tipo de Licencia
es_UR     tipo de acesso                                                                                      admin     info                Tipo de Acceso
es_UR     tipo de licenca                                                                                     admin     info                Tipo de Licencia
es_UR     tipo do software:                                                                                   admin     info                Tipo de software
es_UR     totais de redes alvo                                                                                admin     info                Total de Redes incluidas
es_UR     total                                                                                               admin     info                Total
es_UR     tres                                                                                                admin     info                Tres
es_UR     troca de senha de acesso                                                                            admin     info                Cambiar la clave de acceso
es_UR     ultima alteracao em                                                                                 admin     info                Ultima modificaci�n en
es_UR     unidade organizacional                                                                              admin     info                Unidad Organizacional
es_UR     unidade organizacional nivel 1                                                                      admin     info                Unidad Organizacional Nivel 1
es_UR     unidade organizacional nivel 1a                                                                     admin     info                Unidad Organizacional Nivel 1a
es_UR     unidade organizacional nivel 2                                                                      admin     info                Unidad Organizacional Nivel 2
es_UR     unidade da federacao                                                                                admin     info                Unidad de la Federaci�n
es_UR     usuario                                                                                             admin     info                Usuario
es_UR     usuarios associados ao local                                                                        admin     info                Usuarios asociados al local
es_UR     usuarios primarios                                                                                  admin     info                Usuarios Primarios
es_UR     usuarios secundarios                                                                                admin     info                Usuarios Secundarios
es_UR     valor para pesquisa                                                                                 admin     info                Valor para la busqueda
es_UR     verificacao ativa                                                                                   admin     info                Verificaci�n Activa
es_UR     verificacao ativa?                                                                                  admin     info                Verificaci�n Activa?
es_UR     verificacao efetuada                                                                                admin     info                Verificaci�n efectuada
es_UR     verifique os campos destacados em amarelo                                                           admin     info                Verifique los campos destacados con amarillo
es_UR     versao de executavel                                                                                admin     info                Versi�n del ejecutable
es_UR     visualizacao das ocorrencias com as operacoes de atualizacao, inclusao e exclusao no sistema.       admin     info                Visualizaci�n de las ocurrencias con las operaciones de actualizaci�n, inclusi�n e exclusi�n del sistema
es_UR     voce deve informar a data de aquisicao.                                                             admin     info                Usted debe informar la fecha de la adquisici�n
es_UR     voce deve informar o numero do processo no formato                                                  admin     info                Usted debe de informar el numero de proceso en el formato
es_UR     voltar                                                                                              admin     info                Volver
es_UR     a                                                                                                   admin     info                a
es_UR     aaaa/nnnnnn                                                                                         admin     info                aaaa/nnnn
es_UR     desenvolvido por                                                                                    admin     info                desarrollado por
es_UR     formato                                                                                             admin     info                formato
es_UR     formato:                                                                                            admin     info                formato:
es_UR     jose.silva@es.previdenciasocial.gov.br, luis.almeida@xyz.com                                        admin     info                jose.silva@es.previdenciasocial.gov.br, jdelavega@centrolinux.com.uy
es_UR     mes                                                                                                 admin     info                mes
es_UR     meses                                                                                               admin     info                meses
es_UR     para acesso do agente                                                                               admin     info                para acceso al gerente
es_UR     para acesso do gerente                                                                              admin     info                para acceso al gerente
es_UR     a pesquisa nao retornou registros                                                                   statisticsinfo                La recolecci�n no retorno registros
es_UR     clique sobre o nome da maquina para ver os detalhes da mesma                                        statisticsinfo                Cliquee sobre el nombre de la maquina para ver los detalles de la misma
es_UR     dica: use shift or ctrl para selecionar multiplos itens                                             statisticsinfo                Ayuda: use SHIFT o CTRL para seleccionar m�ltiples items
es_UR     disponiveis:                                                                                        statisticsinfo                Disponibles:
es_UR     engine                                                                                              statisticsinfo                Motor
es_UR     estatisticas de antivirus officescan - informe                                                      statisticsinfo                Esta opcion muestra sobre el Antivirus OfficeScan en los computadores de las redes seleccionadas. Es posible determinar los sistemas operativos
es_UR     estatisticas de sistemas monitorados - informe                                                      statisticsinfo                Esta opcion
es_UR     estatisticas de antivirus officescan                                                                statisticsinfo                Estad�sticas de Antivirus OfficeScan
es_UR     estatisticas de sistemas monitorados                                                                statisticsinfo                Estad�sticas de los sistemas monitoreados
es_UR     gerar relatorio                                                                                     statisticsinfo                Generar reporte
es_UR     ip                                                                                                  statisticsinfo                IP
es_UR     licenca                                                                                             statisticsinfo                Licencia
es_UR     pattern                                                                                             statisticsinfo                Plantilla
es_UR     relacao de maquinas com o engine                                                                    statisticsinfo                Relaci�n de maquinas con el motor
es_UR     relacao de maquinas com o pattern                                                                   statisticsinfo                Relaci�n de maquinas con la plantilla
es_UR     selecione os sistemas monitorados que deseja exibir:                                                statisticsinfo                Seleccione los sistemas monitoreados que desea mostrar:
es_UR     sequencial                                                                                          statisticsinfo                Secuencial
es_UR     total de maquinas                                                                                   statisticsinfo                Total de maquinas
es_UR     versao                                                                                              statisticsinfo                Versi�n
es_UR     ultima coleta                                                                                       statisticsinfo                Ultima recolecci�n
es_UR     % livre                                                                                             geral     info                % libre
es_UR     % ocupado                                                                                           geral     info                % ocupado
es_UR     (dica: use shift ou ctrl para selecionar multiplos itens)                                           geral     info                (Ayuda: use SHIFT o CTRL para seleccionar m�ltiples items)
es_UR     (obs: estao sendo exibidas somente as redes selecionadas pelo administrador.)                       geral     info                (OBS: Est�n siendo mostradas solamente las redes seleccionadas por el administrador.)
es_UR     kciq_msg total referente a multi-locais                                                             geral     info                <b>ATENCI�N:</b> Total referente a mas de una localidad.
es_UR     <strong>todas</strong> as redes                                                                     geral     info                Todas las redes
es_UR     kciq_msg access denied                                                                              geral     erro                Acceso no permitido
es_UR     kciq_msg admin not reg                                                                              geral     info                Administrador no fue registrado
es_UR     admin                                                                                               geral     TagHeader           Administraci�n
es_UR     kciq_msg advise                                                                                     geral     info                Alerta
es_UR     apenas redes <strong>selecionadas</strong>                                                          geral     info                Solo redes seleccionadas
es_UR     kciq_msg apoio                                                                                      Geral     info                Apoyo colaborativo
es_UR     kciq_msg file saved                                                                                 geral     info                Archivo (%1) fue salvado
es_UR     kciq_msg attention                                                                                  geral     info                Atenci�n
es_UR     kciq_msg update                                                                                     geral     info                Actualizaci�n
es_UR     acao                                                                                                geral     info                Acci�n
es_UR     kciq_msg database not exist                                                                         geral     info                Base de datos (%1) no existe!
es_UR     kciq_msg computadores monitorados hoje                                                              geral     info                Computadores monitoreados por local en estos datos
es_UR     kciq_msg connected ok                                                                               geral     info                Conexi�n realizada con �xito
es_UR     kciq_msg configurations                                                                             Geral     info                Configuraciones
es_UR     kciq_msg verify                                                                                     geral     info                Confirmaci�n
es_UR     kciq_msg backup                                                                                     geral     info                Copia de seguridad
es_UR     de 180 a 365 dias...                                                                                geral     info                De 180 a 365 d�as...
es_UR     de 30 a 180 dias....                                                                                geral     info                De 30 a 180 d�as...
es_UR     de 5 a 30 dias......                                                                                geral     info                De 5 a 30 d�as...
es_UR     kciq_msg ftp change dir ok                                                                          geral     info                Directorio FTP modificado con �xito
es_UR     kciq_msg org label                                                                                  geral     info                Empresa
es_UR     kciq_msg email                                                                                      geral     info                Correo electr�nico
es_UR     language_en-us                                                                                      Geral     info      en-US     Ingles (US)
es_UR     kciq_msg error                                                                                      geral     erro                Error
es_UR     kciq_msg org name update error                                                                      geral     erro                Error al intentar actualizar el nombre de la empresa
es_UR     kciq_msg update on table fail                                                                       geral     erro                Error al intentar actualizar registros en la(s) tabla(s) (%1)
es_UR     kciq_msg delete row on table fail                                                                   geral     erro                Error al intentar excluir registros de la tabla %1
es_UR     kciq_msg insert row on table fail                                                                   geral     erro                Error al intentar incluir registro(s) en la(s) tabla(s) %1
es_UR     kciq_msg login insert error                                                                         geral     erro                Error al intentar insertar datos de login!
es_UR     kciq_msg local insert error                                                                         geral     erro                Error al intentar insertar datos de Local!
es_UR     kciq_msg config local insert error                                                                  geral     erro                Error al intentar insertar configuraciones de Local!
es_UR     kciq_msg user insert error                                                                          geral     erro                Error al intentar insertar el usuario ('.$cacic_config['db_user'].')!
es_UR     kciq_msg select on table fail                                                                       geral     erro                Error al intentar obtener registros en la(s) tabla(s) (%1)
es_UR     language_es                                                                                         Geral     info      es        Espa�ol
es_UR     essa opcao permite a selecao de coletas de informacoes de sistemas monitorados para essa rede.      geral     info                Esta opcion permite una selecci�n de recolecci�n de informaciones de sistemas monitoreados para esta red.
es_UR     statistics                                                                                          geral     TagHeader           Estad�sticas
es_UR     kciq_msg statistics                                                                                 geral     info                Estad�sticas
es_UR     kciq_msg cacic statistics                                                                           geral     info                Estad�sticas de CACIC
es_UR     kciq_msg ftp login connect fail                                                                     geral     erro                Falla al loguearse en el servidor FTP
es_UR     kciq_msg ftp change dir fail                                                                        geral     erro                Falla al intentar cambiar el directorio FTP
es_UR     kciq_msg ftp connect fail                                                                           geral     erro                Falla en la conexion FTP
es_UR     language_fr                                                                                         Geral     info      fr        Frances
es_UR     geral                                                                                               Geral     TagHeader           General
es_UR     ha 1 dia............                                                                                geral     info                Hasta 1 d�a...
es_UR     ha 2 dias...........                                                                                geral     info                Hasta 2 d�as...
es_UR     ha 3 dias...........                                                                                geral     info                Hasta 3 d�as...
es_UR     ha 4 dias...........                                                                                geral     info                Hasta 4 d�as...
es_UR     ha mais de 365 dias.                                                                                geral     info                Hasta mas dce 365 d�as...
es_UR     hoje................                                                                                geral     info                Hoy......
es_UR     id externa                                                                                          geral     info                ID Externa
es_UR     language                                                                                            Geral     info                Idioma
es_UR     induzir o envio das informacoes coletadas                                                           geral     info                Forzar el envio de las informaciones recolectadas
es_UR     kciq_msg instalada                                                                                  geral     info                Instalada
es_UR     instalador                                                                                          geral     TagHeader           Instalador
es_UR     kciq_msg legenda                                                                                    geral     info                Legenda
es_UR     kciq_msg local already exist                                                                        geral     info                Local (%1) ya esta registrado!
es_UR     kciq_msg local not exist                                                                            geral     info                Local (%1) no registrado!
es_UR     kciq_msg local not reg                                                                              geral     info                Local no fue registrado
es_UR     localizacao ou nome da subrede                                                                      geral     info                Localizaci�n o nombre de la Sub-Red
es_UR     kciq_msg login                                                                                      Geral     info                Login
es_UR     kciq_msg login already exist                                                                        geral     info                Login (%1) ya esta registrado!
es_UR     kciq_msg login not exist                                                                            geral     info                Login (%1) no existe.
es_UR     kciq_msg ftp login ok                                                                               geral     info                Login con exito en el FTP
es_UR     kciq_msg admin login needed                                                                         geral     info                Login del administrador debe ser informado!
es_UR     kciq_msg logout                                                                                     Geral     info                Logoff
es_UR     manuten��o                                                                                          geral     TagHeader           Mantenimiento
es_UR     manutencao                                                                                          geral     TagHeader           Mantenimiento
es_UR     marca ou desmarca acao para as redes abaixo                                                         geral     info                Marca o Desmarca Acci�n para las redes de abajo
es_UR     marca/desmarca todas as acoes para todas as redes abaixo                                            geral     info                Marca/Desmarca todas las acciones para todas las redes de abajo
es_UR     kciq_msg mensagem                                                                                   Geral     info                Mensaje
es_UR     kciq_msg server msg                                                                                 geral     info                Mensaje del servidor
es_UR     verificacao-atualizacao dos servidores de updates help                                              geral     info                Modulo para verificaci�n/actualizaci�n de las versiones de los objetos localizados en los servidores de actualizaci�n de las subredes monitoreadas.
es_UR     nao disponivel                                                                                      geral     info                No disponibles
es_UR     navegar nas redes detectadas pelos agentes nas estacoes                                             geral     info                Navegar en las redes detectadas por los agentes en las estaciones
es_UR     kciq_msg login needed                                                                               geral     info                Necesario estar autenticado
es_UR     kciq_msg name                                                                                       geral     info                Nombre
es_UR     kciq_msg org label needed                                                                           geral     erro                Nombre de la empres debe de ser informado!
es_UR     kciq_msg org label help                                                                             geral     ajuda               Nombre de la empresa donde esta instalado el gerente
es_UR     kciq_msg admin name needed                                                                          geral     info                Nombre del administrador debe ser informado!
es_UR     kciq_msg local name needed                                                                          geral     info                Nombre del local debe ser informado!
es_UR     kciq_msg ftp user help                                                                              geral     ajuda               Nombre del usuario FTP
es_UR     kciq_msg ftp host help                                                                              geral     help                Nombre o IP del servidor FTP
es_UR     kciq_msg new                                                                                        Geral     info                Nueva
es_UR     kciq_msg no                                                                                         geral     info                No
es_UR     kciq_msg database connect fail                                                                      geral     erro                No fue posible conectar a la base de datos
es_UR     kciq_msg access level                                                                               Geral     info                Nivel de acceso
es_UR     kciq_msg javascript not enabled                                                                     geral     erro                Javascript es imprescindible para el perfecto funcionamiento del Sistema
es_UR     kciq_msg obs                                                                                        geral     info                Observaci�n
es_UR     ocorreu um erro no acesso a tabela %1 ou sua sessao expirou!                                        geral     info                Ocurri� un error en el acceso a la tabla %1 o su sesi�n finalizo
es_UR     kciq_msg ok                                                                                         geral     info                Ok
es_UR     kciq_menu fast search                                                                               Geral     info                B�squeda r�pida
es_UR     kciq_menu search                                                                                    Geral     info                Buscar
es_UR     kciq_msg ftp port help                                                                              geral     ajuda               Puerta FTP en el servidor
es_UR     language_pt_br                                                                                      Geral     info                Espa�ol Uruguay
es_UR     kciq_msg next                                                                                       Geral     info                Pr�ximo
es_UR     quantidade real baseada em mac-address                                                              geral     info                Cantidad real basada en la direcci�n-MAC
es_UR     kciq_msg ftp verify help                                                                            geral     info                Realiza testeo de verificaci�n del servidor FTP, no graba en la base de datos del sistema debiendo ser configurado despues de la instalaci�n
es_UR     kciq_msg backup help                                                                                geral     info                Realizar copia de la base de datos por seguridad.
es_UR     redes cadastradas                                                                                   geral     info                Redes registradas
es_UR     relatorio de estacoes por sistema operacional                                                       geral     info                Reporte de estaciones por sistema operativo
es_UR     relatorios                                                                                          geral     TagHeader           Reportes
es_UR     kciq_msg requerida                                                                                  geral     info                Requerida
es_UR     kciq_msg save                                                                                       geral     info                Salvar
es_UR     selecao para coleta de informacoes de sistemas monitorados:                                         geral     info                Seleccione para recolectar informaciones de los sistemas monitoreados:
es_UR     selecionadas:                                                                                       geral     info                Seleccionadas:
es_UR     selecione os locais:                                                                                geral     info                Seleccione los locales:
es_UR     kciq_msg password                                                                                   Geral     info                clave
es_UR     kciq_msg ftp password help                                                                          geral     ajuda               Clave de usuario FTP:
es_UR     kciq_msg password needed                                                                            geral     info                Las claves deben ser informadas y confirmadas!
es_UR     kciq_msg password not same                                                                          geral     info                Las claves no son iguales!
es_UR     kciq_msg session fail                                                                               geral     erro                Session finalizo
es_UR     kciq_msg abbr                                                                                       geral     info                Sigla
es_UR     kciq_msg local abbr needed                                                                          geral     info                Sigla del local debe ser informada!
es_UR     kciq_msg yes                                                                                        geral     info                Si
es_UR     kciq_msg ftp subdir                                                                                 geral     info                Subdirectorio FTP
es_UR     kciq_msg ftp subdir help                                                                            geral     ajuda               Subdirectorio FTP en el servidor
es_UR     kciq_msg phone                                                                                      geral     info                Tel�fono
es_UR     kciq_msg total of computers per local                                                               geral     info                Total de computadoras monitoreadas por local
es_UR     kciq_msg total of computers per os                                                                  geral     info                Total de computadoras monitoreados por sistemas operacionales
es_UR     kciq_msg real total of computers mac based                                                          geral     info                Total real de computadores monitoreados (con base en la Mac-Address)
es_UR     ultimo acesso                                                                                       geral     info                ultimo acceso
es_UR     um                                                                                                  geral     info                Uno
es_UR     kciq_msg user                                                                                       Geral     info                Usuario
es_UR     kciq_msg invalid user or pass                                                                       geral     info                Usuario no registrado clave invalida
es_UR     kciq_msg details                                                                                    geral     info                Ver detalles
es_UR     verificacao/atualizacao dos servidores de updates                                                   geral     info                Verificacion/Actualizacion de los Servidores de Actualizacion
es_UR     kciq_msg check                                                                                      geral     info                Verificar
es_UR     kciq_msg ftp verify                                                                                 geral     info                Verificacion del servidor FTP
es_UR     kciq_msg check_notok                                                                                geral     info                Verificaci�n no completada
es_UR     kciq_msg check_ok                                                                                   geral     info                Verificaci�n completa
es_UR     versao do agente principal                                                                          geral     info                Version del agente principal
es_UR     kciq_msg version                                                                                    geral     info                Versi�n
es_UR     kciq_msg last agents access                                                                         geral     info                �ltimos accesos a los agentes
es_UR     kciq_msg last agents access on local                                                                geral     info                �ltimos accesos a los agentes de este local
es_UR     kciq_msg last agents access per local                                                               geral     info                �ltimos accesos a los agentes por local en esta fecha
es_UR     kciq_msg inst end advise                                                                            instaladorinfo                <p><b>Atenci�n:</b> Lea los mensajes en el fin de esta pagina sobre el proceso de instalaci�n, tales como las <b>recomendaciones</b> abajo:</p>
es_UR     kciq_msg aceitar                                                                                    instaladorinfo                Aceptar
es_UR     kciq_msg aceito                                                                                     instaladorinfo                Acepto la licencia
es_UR     kciq_msg admin mgm title                                                                            instaladorinfo                Administraci�n del CACIC-Gerente
es_UR     kciq_msg check_advise                                                                               instaladorinfo                Alerta, pero podr� continuar
es_UR     kciq_msg previous                                                                                   instaladorinfo                Anterior
es_UR     kciq_msg cfgfile_writeable                                                                          instaladorinfo                Archivo <i><b>config.php</b></i> puede ser grabado
es_UR     kciq_msg inst org name update                                                                       instaladorinfo                Actualizando nombre de la empresa...
es_UR     kciq_msg update help                                                                                instaladorinfo                Actualizar las tablas de la base con respecto a la versi�n elegida.
es_UR     kciq_msg inst update tables on database                                                             instaladorinfo                Actualizaci�n de las tablas en la base de datos (%1)...
es_UR     kciq_msg database                                                                                   instaladorinfo                Base de datos
es_UR     kciq_msg inst database exist                                                                        instaladorinfo                Base de datos (%1) ya existe!
es_UR     kciq_msg inst make database permissions                                                             instaladorinfo                Concediendo permisos para el usuario (%1).
es_UR     kciq_msg inst end title                                                                             instaladorinfo                Conclusi�n de la instalaci�n de CACIC
es_UR     kciq_msg inst connecting to database server                                                         instaladorinfo                Conectando al servidor de la base de datos
es_UR     kciq_msg inst database connect ok                                                                   instaladorinfo                Conexi�n realizada con suceso!
es_UR     kciq_msg admin mgm verify pass help                                                                 instaladorinfo                Confirmar clave de Administrador de CACIC
es_UR     kciq_msg build bd                                                                                   instaladorinfo                Construir BD
es_UR     kciq_msg new help                                                                                   instaladorinfo                Construir la base de datos para una nueva instalaci�n de CACIC.
es_UR     kciq_msg inst database build fail                                                                   instaladorinfo                Construcci�n de la base de datos para el CACIC no fue realizada adecuadamente!
es_UR     kciq_msg inst building tables on database                                                           instaladorinfo                Creando las tablas en la base de datos...
es_UR     kciq_msg inst build database                                                                        instaladorinfo                Creando la base (%1) ...
es_UR     kciq_msg build bd help                                                                              instaladorinfo                Crear base de datos.
es_UR     kciq_msg database table build                                                                       instaladorinfo                Creaci�n de las tablas de la base de datos!
es_UR     kciq_msg inst admin data succesfuly created                                                         instaladorinfo                Datos administrativos insertados con �xito!
es_UR     kciq_msg admin mgm local                                                                            instaladorinfo                Datos de localizaci�n
es_UR     kciq_msg admin mgm data title                                                                       instaladorinfo                Datos do Administrador
es_UR     kciq_msg inst database data save fail                                                               instaladorinfo                Datos del Local y Usuario administrador no grabados en la base de datos!
es_UR     kciq_msg inst admin help                                                                            instaladorinfo                Datos de administrador para crear la base de datos.
es_UR     kciq_msg check cacic configfile data                                                                instaladorinfo                Datos de archivo de configuraci�n (%1) deben ser verificados.
es_UR     kciq_msg demo                                                                                       instaladorinfo                Demostraci�n
es_UR     kciq_msg admin mgm email help                                                                       instaladorinfo                Correo electr�nico del Administrador de CACIC para env�o de mensajes
es_UR     kciq_msg inst check dir perm                                                                        instaladorinfo                Error al intentar grabar el archivo %1. Verifique directorio y permisos!
es_UR     kciq_msg inst build database error                                                                  instaladorerro                Error en la creaci�n de la base de datos (%1)!
es_UR     kciq_msg php_memory_help                                                                            instaladorinfo                Esa directiva ir� a afectar el desempe�o de la ejecuci�n de los programas en PHP.
es_UR     kciq_msg php_flag_on_advise                                                                         instaladorinfo                Esa directiva es verificada solo para versi�n PHP = 5.x.y.
es_UR     kciq_msg finish                                                                                     instaladorinfo                Finalizar
es_UR     kciq_msg savecfgfile                                                                                instaladorinfo                Grabar <i>config.php</i>
es_UR     kciq_msg inst config file saved                                                                     instaladorinfo                Grabaci�n del archivo de configuraciones no realizado adecuadamente!
es_UR     kciq_msg inst end hist title                                                                        instaladorinfo                Hist�rico de alteraciones en CACIC
es_UR     kciq_msg ideal                                                                                      instaladorinfo                Ideal
es_UR     kciq_msg def_language                                                                               instaladorinfo                Idioma
es_UR     kciq_msg inst insert basic data                                                                     instaladorinfo                Inclusi�n de datos b�sicos en las tablas de las bases de datos (%1)
es_UR     kciq_msg inst insert demo data                                                                      instaladorinfo                Inclusi�n de datos para demostraci�n
es_UR     kciq_msg finish title                                                                               instaladorinfo                Iniciar uso de CACIC!
es_UR     kciq_msg inst login insert                                                                          instaladorinfo                Insertando datos del administrador (%1)...
es_UR     kciq_msg inst local insert                                                                          instaladorinfo                Insertando local (%1)...
es_UR     kciq_msg inst config local insert                                                                   instaladorinfo                Insertando configuraciones de local (%1)...
es_UR     kciq_msg demo help                                                                                  instaladorinfo                Insertar datos para demostraci�n de CACIC.
es_UR     kciq_installertitle                                                                                 instaladorinfo                Instalador WEB para CACIC
es_UR     kciq_msg web_installer                                                                              instaladorinfo                Instalador WEB para CACIC
es_UR     kciq_msg inst finished and verified                                                                 instaladorinfo                Instalaci�n de CACIC finalizada y verificada!
es_UR     kciq_msg advise_title                                                                               instaladorinfo                Instrucci�n PHP/Apache
es_UR     kciq_installerintrotitle                                                                            instaladorinfo                Introducci�n
es_UR     kciq_msg license title                                                                              instaladorinfo                Licencia
es_UR     kciq_msg admin mgm name help                                                                        instaladorinfo                Local al cual la aplicaci�n gerente est� asociado.
es_UR     kciq_msg admin mgm user help                                                                        instaladorinfo                Login de Administrador de CACIC
es_UR     kciq_msg user help                                                                                  instaladorinfo                Login de administrador de la base de datos.
es_UR     kciq_msg php_memory                                                                                 instaladorinfo                Memoria para ejecuci�n de programas PHP
es_UR     kciq_msg showcfgfile                                                                                instaladorinfo                Mostrar <i>config.php</i>
es_UR     kciq_msg showcfgfile help                                                                           instaladorinfo                Mostrar un archivo de configuraciones para CACIC.
es_UR     kciq_msg js_enable                                                                                  instaladorinfo                Necesario activar <b>JavaScript</b> para usar el Instalador Web
es_UR     kciq_msg admin mgm adminname help                                                                   instaladorinfo                Nombre del Administrador CACIC
es_UR     kciq_msg database name                                                                              instaladorinfo                Nombre de la base de datos
es_UR     kciq_msg inst database name not defined                                                             instaladorerro                Nombre de la base de datos debe ser informado!
es_UR     kciq_msg database name help                                                                         instaladorinfo                Nombre de la base de datos pre-existente.
es_UR     kciq_msg database host help                                                                         instaladorinfo                Nombre del servidor (o IP) de la base de datos.
es_UR     kciq_msg dbuser help                                                                                instaladorinfo                Nombre del usuario para ser usado por CACIC para conectar a la base de datos.
es_UR     kciq_msg inst config file read                                                                      instaladorinfo                No fue posible leer el archivo (%1) de configuraciones
es_UR     kciq_msg inst database sqldemodata not defined                                                      instaladorerro                No hay datos (%1) disponibles para  la demonstraci�n!
es_UR     kciq_msg inst insert demo data error                                                                instaladorerro                No hay datos disponibles para demonstraci�n!
es_UR     kciq_msg inst database sqldata not defined                                                          instaladorerro                No hay instrucciones SQL (%1 o %2) referentes a los datos base para CACIC!
es_UR     kciq_msg inst database sqlupdatedata not defined                                                    instaladorerro                No hay instrucciones SQL (%1) para actualizaci�n de la base de datos de CACIC!
es_UR     kciq_msg inst database sqlbuild not defined                                                         instaladorerro                No hay instrucciones SQL (%1) para la creaci�n de tablas de la base de datos!
es_UR     kciq_msg inst database standard sqldata should be used                                              instaladorerro                No hay instrucciones SQL (%1) referidos a los datos base de CACIC! Datos padr�n (%2) ser�n usados!
es_UR     kciq_msg inst tables update error                                                                   instaladorerro                No hay instrucciones SQL para actualizar las tablas de la base de datos!
es_UR     kciq_msg inst tables build error                                                                    instaladorerro                No hay instrucciones SQL para crear las tablas de la base de datos!
es_UR     kciq_msg inst insert basic data error                                                               instaladorerro                No hay instrucciones SQL para insertar los datos base en las tablas de la base de datos!
es_UR     kciq_msg admin mgm phone help                                                                       instaladorinfo                N�mero de tel�fono del Administrador de CACIC para contactar.
es_UR     kciq_msg admin mgm obs help                                                                         instaladorinfo                Observaciones (informaciones) para el local al cual la aplicaci�n gerente est� asociada.
es_UR     kciq_msg mcrypt_suporte                                                                             instaladorinfo                Soporte la criptografia con MCrypt
es_UR     kciq_msg mail_suporte                                                                               instaladorinfo                PHP con soporte para envio de email
es_UR     kciq_msg gd_suporte                                                                                 instaladorinfo                Soporte las im�genes con GD
es_UR     kciq_msg ftp_suporte                                                                                instaladorinfo                FTP
es_UR     kciq_msg ldap_suporte                                                                               instaladorinfo                Soporte a LDAP
es_UR     kciq_msg mysql_suporte                                                                              instaladorinfo                Soporte a la versi�n MySQL
es_UR     kciq_msg phpmcrypt_help                                                                             instaladorinfo                Para ejecutar CACIC es necesario instalar la biblioteca de manipulaci�n criptografica con MCrypt.
es_UR     kciq_msg phpgd_help                                                                                 instaladorinfo                Para ejecutar CACIC es necesario instalar la biblioteca de manipulaci�n de im�genes con GD.
es_UR     kciq_msg phpftp_help                                                                                instaladorinfo                Para ejecutar CACIC es necesario instalar la biblioteca para el uso de FTP.
es_UR     kciq_msg phpldap_help                                                                               instaladorinfo                Para ejecutar CACIC es necesario instalar la biblioteca para el uso de LDAP.
es_UR     kciq_msg phpmysql_help                                                                              instaladorinfo                Para ejecutar CACIC es necesario instalar la biblioteca para la base de datos MYSQL.
es_UR     kciq_msg phpversion_help                                                                            instaladorinfo                Para ejecutar CACIC es necesario instalar una versi�n de PHP indicada.
es_UR     kciq_msg inst database admin not defined                                                            instaladorerro                Para instalaci�n nueva, informe al usuario administrador de la base de datos!
es_UR     kciq_msg php_flag_on                                                                                instaladorinfo                Para que el CACIC funcione correctamente es necesario - activar esa directiva.
es_UR     kciq_msg fix_requiriment_help                                                                       instaladorinfo                Por favor, corrija dependencias para continuar el proceso de instalaci�n!
es_UR     kciq_msg license advise                                                                             instaladorinfo                Por favor, lea los t�rminos de la licencia que sigue. Usted debe aceptar los t�rminos de �sta para continuar la instalaci�n!
es_UR     kciq_msg database port                                                                              instaladorinfo                Puerta
es_UR     kciq_msg database port help                                                                         instaladorinfo                Puerta de conexi�n a la base de datos.
es_UR     kciq_msg inst database server port not defined                                                      instaladorerro                Puerta del servidor de la base de datos debe ser informada!
es_UR     kciq_msg inst database build process ok                                                             instaladorinfo                Proceso de construcci�n de la base de datos (%1) finalizado con suceso!
es_UR     kciq_msg database type help                                                                         instaladorinfo                cual es el tipo de base de datos a usar (Solamente MySQL por ahora).
es_UR     kciq_msg real                                                                                       instaladorinfo                Real
es_UR     kciq_msg inst end advise title                                                                      instaladorinfo                Recomendaciones
es_UR     kciq_installerresources                                                                             instaladorinfo                Recursos del Instalador:
es_UR     kciq_msg features title                                                                             instaladorinfo                Recursos para las pr�ximas versiones de CACIC
es_UR     kciq_msg requisitos                                                                                 instaladorinfo                Requisitos
es_UR     retorne aos passos anteriores e configure adequadamente                                             instaladorinfo                Retorne a los pasos anteriores y configure adecuadamente
es_UR     kciq_msg savecfgfile help                                                                           instaladorinfo                Graba el archivo de configuraciones para CACIC.
es_UR     kciq_msg save title                                                                                 instaladorinfo                Grabar datos del administrador de CACIC.
es_UR     kciq_msg inst version to update                                                                     instaladorerro                Seleccione la versi�n a ser actualizada!
es_UR     kciq_msg version help                                                                               instaladorinfo                Seleccione la versi�n de CACIC a ser actualizada.
es_UR     kciq_msg inst type not defined                                                                      instaladorerro                Seleccione uno de los dos tipos de instalaci�n!
es_UR     kciq_msg admin mgm pass help                                                                        instaladorinfo                Clave del Administrador de CACIC
es_UR     kciq_msg password help                                                                              instaladorinfo                Clave del administrador de la base de datos.
es_UR     kciq_msg dbpass help                                                                                instaladorinfo                clave para el usuario de la base de datos.
es_UR     kciq_msg database host                                                                              instaladorinfo                Servidor
es_UR     kciq_msg inst database server not defined                                                           instaladorerro                Servidor de base de datos debe ser informado!
es_UR     kciq_msg admin mgm abbr help                                                                        instaladorinfo                Sigla del local al cual la aplicaci�n gerente est� asociada.
es_UR     kciq_msg test conn help                                                                             instaladorinfo                Testear conexi�n con la base de datos.
es_UR     kciq_msg test conn                                                                                  instaladorinfo                Testear la conexi�n
es_UR     kciq_msg database type                                                                              instaladorinfo                Tipo
es_UR     kciq_msg inst database type not defined                                                             instaladorinfo                Tipo de base de datos debe ser informado!
es_UR     kciq_msg install type                                                                               instaladorinfo                Tipo de instalaci�n
es_UR     kciq_msg inst url not defined                                                                       instaladorinfo                URL de la aplicaci�n debe ser informada!
es_UR     kciq_msg inst database user not defined                                                             instaladorerro                Usuario de conexi�n con la base de datos debe ser informado!
es_UR     kciq_msg inst verify admin                                                                          instaladorinfo                Verificando administrador (%1)...
es_UR     kciq_msg inst verify database existence                                                             instaladorinfo                Verificando existencia de la base de datos (%1)...
es_UR     kciq_msg inst verify local                                                                          instaladorinfo                Verificando local (%1)...
es_UR     kciq_msg inst path not executable                                                                   instaladorinfo                Verifique as permiss�es de leitura e execu��o do caminho f�sico informado!
es_UR     kciq_msg def_version                                                                                instaladorinfo                Versi�n
es_UR     kciq_msg version header                                                                             instaladorinfo                Versi�n a ser actualizada.
es_UR     kciq_msg phpversion                                                                                 instaladorinfo                Versi�n del PHP
es_UR     kciq_msg database server version invalid                                                            instaladorerro                Versi�n del Servidor de la base de datos inv�lida
es_UR     kciq_msg phpcfgfile_help                                                                            instaladorinfo                Usted podr� continuar la instalaci�n y el archivo podr� (opcionalmente) ser mostrado en la pantalla. Asi, usted podr� copiarlo y pegarlo en el directorio adecuado.
es_UR     e mais...                                                                                           instaladorinfo                y mas ...
es_UR     kciq_msg inst end advise file                                                                       instaladorarquivo             inst_end_advise_file.html
es_UR     kciq_msg features file                                                                              instaladorarquivo             inst_end_features_file.html
es_UR     kciq_msg inst end hist file                                                                         instaladorarquivo             inst_end_hist_file.html
es_UR     kciq_installer_introdution                                                                          instaladorarquivo             introducao.html
es_UR     kciq_msg license en_read                                                                            instaladorinfo                lea en ingl�s
es_UR     kciq_msg license pt_read                                                                            instaladorinfo                lea en portugu�s
es_UR     kciq_mnt_lang traducao                                                                              manutencaoinfo                Idioma a traducir
es_UR     kciq_mnt_tradutor                                                                                   manutencaoinfo                Traducci�n de texto de CACIC
es_UR     acrescentado                                                                                        relatoriosinfo                Incremental
es_UR     agente principal                                                                                    relatoriosinfo                Agente Principal
es_UR     analisar rota de rede                                                                               relatoriosinfo                Analizar ruta de red
es_UR     analise se ativo na rede                                                                            relatoriosinfo                Analizar si esta activo en la red
es_UR     antivirus ativo                                                                                     relatoriosinfo                Antivirus activo
es_UR     antivirus officescan                                                                                relatoriosinfo                Antivirus officeScan
es_UR     ativo                                                                                               relatoriosinfo                Activo
es_UR     bios                                                                                                relatoriosinfo                BIOS
es_UR     cpu                                                                                                 relatoriosinfo                CPU
es_UR     campos obrigatorios                                                                                 relatoriosinfo                Campos Obligatorios
es_UR     clique sobre o nome da maquina para ver os detalhes                                                 relatoriosinfo                Cliquee sobre el nombre de la maquina para ver los detalles
es_UR     comentario                                                                                          relatoriosinfo                Comentario
es_UR     compartilhamento de diretorio                                                                       relatoriosinfo                Directorio compartido
es_UR     compartilhamento de impressora                                                                      relatoriosinfo                Impresora compartida
es_UR     compartilhamentos de diretorios e impressoras                                                       relatoriosinfo                Directorios e impresoras compartidas
es_UR     computador inexistente                                                                              relatoriosinfo                Computadora no existe
es_UR     dados da modificacao                                                                                relatoriosinfo                Datos de la modificaci�n
es_UR     dados historicos                                                                                    relatoriosinfo                Datos hist�ricos
es_UR     dados historicos obtidos de versoes anteriores a 2.4                                                relatoriosinfo                Datos hist�ricos obtenidos de las versiones anteriores a la 2.4
es_UR     data da alteracao                                                                                   relatoriosinfo                Fecha de cambio
es_UR     data da ultima coleta                                                                               relatoriosinfo                Fecha de la �ltima recolecci�n
es_UR     data de alteracao                                                                                   relatoriosinfo                Fecha de cambio
es_UR     data de instalacao                                                                                  relatoriosinfo                Fecha de instalaci�n
es_UR     data/hora da ultima coleta                                                                          relatoriosinfo                Fecha/Hora de la �ltima recolecci�n
es_UR     data/hora do ultimo acesso                                                                          relatoriosinfo                Fecha/Hora del �ltimo acceso
es_UR     data/hora inclusao                                                                                  relatoriosinfo                Fecha/Hora inclusi�n
es_UR     data/hora instalacao                                                                                relatoriosinfo                Fecha/Hora instalaci�n
es_UR     depende de senha                                                                                    relatoriosinfo                Depende de la clave
es_UR     desativado                                                                                          relatoriosinfo                Desactivado
es_UR     detalhes do computador                                                                              relatoriosinfo                Detalles de la computadora
es_UR     diretorio                                                                                           relatoriosinfo                Directorio
es_UR     dominio dns                                                                                         relatoriosinfo                Dominio DNS
es_UR     endereco tcp/ip                                                                                     relatoriosinfo                Direcci�n TCP/IP
es_UR     endereco de rede                                                                                    relatoriosinfo                Direcci�n de la red
es_UR     endereco do servidor                                                                                relatoriosinfo                Direcci�n del servidor
es_UR     espaco (mb)                                                                                         relatoriosinfo                Espacio (MB)
es_UR     estado do officescan                                                                                relatoriosinfo                Estado del officeScan
es_UR     exibe as alteracoes nas configuracoes de hardware dos computadores.                                 relatoriosinfo                Muestra los cambios en las configuraciones del hardware de las computadoras.
es_UR     exibir informacoes de patrimonio                                                                    relatoriosinfo                Muestra informaciones del patrimonio
es_UR     fabricante                                                                                          relatoriosinfo                Fabricante
es_UR     ferramentas                                                                                         relatoriosinfo                Herramientas
es_UR     forcar coletas                                                                                      relatoriosinfo                Forzar recolecci�n
es_UR     gateway                                                                                             relatoriosinfo                Gateway
es_UR     gerador por                                                                                         relatoriosinfo                Generado por
es_UR     gerente de coletas                                                                                  relatoriosinfo                Gerente de recolecci�n
es_UR     gravacao                                                                                            relatoriosinfo                Grabaci�n
es_UR     hardware instalado                                                                                  relatoriosinfo                Hardware instalado
es_UR     historico de alteracoes das informacoes de patrimonio                                               relatoriosinfo                Hist�rico de cambios en la configuraci�n de patrimonio
es_UR     historico de alteracoes na configuracao de hardware                                                 relatoriosinfo                Hist�rico de cambios en la configuraci�n de hardware
es_UR     historico de alteracoes na configuracao de rede                                                     relatoriosinfo                Hist�rico de cambios en la configuraci�n de la red
es_UR     identificador/versao                                                                                relatoriosinfo                Identificador/Versi�n
es_UR     informacoes basicas                                                                                 relatoriosinfo                Informaciones b�sicas
es_UR     informacoes de patrimonio e localizacao fisica                                                      relatoriosinfo                Informaciones de patrimonio y localizaci�n f�sica
es_UR     instalado                                                                                           relatoriosinfo                Instalado
es_UR     leitura                                                                                             relatoriosinfo                Lectura
es_UR     limpar                                                                                              relatoriosinfo                Limpiar
es_UR     livre                                                                                               relatoriosinfo                Libre
es_UR     memoria ram                                                                                         relatoriosinfo                Memoria RAM
es_UR     modem                                                                                               relatoriosinfo                Modem
es_UR     mostrar somente dados historicos?                                                                   relatoriosinfo                Mostrar solamente datos hist�ricos?
es_UR     mostrar tambem dados historicos?                                                                    relatoriosinfo                Mostrar tambi�n datos hist�ricos?
es_UR     mouse                                                                                               relatoriosinfo                Mouse
es_UR     mascara de rede                                                                                     relatoriosinfo                M�scara de red
es_UR     modulo de coleta de compartilhamentos de diretorios e impressoras nao habilitado pelo administrador relatoriosinfo                M�dulo de recolecci�n de directorios compartidos e impresoras no habilitado por el Administrador
es_UR     nao existem compartilhamentos nesta maquina                                                         relatoriosinfo                Nada compartido en esta maquina
es_UR     nao existem unidades de disco nesta maquina                                                         relatoriosinfo                No existen unidades de disco en esta maquiina
es_UR     nao foram coletadas informacoes de aplicativos monitorados referente a esta maquina                 relatoriosinfo                No fueron recolectados informaciones de aplicaciones monitoreados referente a esta maquina
es_UR     nao foram coletadas informacoes de patrimonio e/ou localizacao fisica                               relatoriosinfo                No fueron recolectados informaciones de patrimonio y/o localizaci�n f�sica
es_UR     nao foram coletadas informacoes de software inventariado referente a esta maquina                   relatoriosinfo                No fueron recolectados informaciones de software inventariado referente a esta maquina
es_UR     nao foram coletadas informacoes de software referente a esta maquina                                relatoriosinfo                No fueron recolectados informaciones de software referente a esta maquina
es_UR     nao foram coletadas informacoes de variaveis de ambiente referente a esta maquina                   relatoriosinfo                No fueron recolectados informaciones de variables de ambiente referente a esta maquina
es_UR     nao foram coletadas informacoes do officescan referente a esta maquina                              relatoriosinfo                No fueron recolectados informaciones de officeScan referente a esta maquina
es_UR     nao foram encontradas alteracoes de hardware!                                                       relatoriosinfo                No fueron encontrados cambios de hardware!
es_UR     numero serial                                                                                       relatoriosinfo                N�mero de serie
es_UR     o modulo de coleta de informacoes de hardware nao foi habilitado pelo administrador                 relatoriosinfo                El m�dulo de recolecci�n de informaciones de hardware no fue habilitado por el Administrador
es_UR     o modulo de coleta de informacoes das unidades de disco nao foi habilitado pelo administrador       relatoriosinfo                El m�dulo de recolecci�n de informaciones de las Unidades de Disco no fue habilitado por el Administrador
es_UR     o modulo de coleta de informacoes de patrimonio nao foi habilitado pelo administrador               relatoriosinfo                El m�dulo de recolecci�n de informaciones de patrimonio no fue habilitado por el Administrador
es_UR     o modulo de coleta de informacoes de sistemas monitorados nao foi habilitado pelo administrador     relatoriosinfo                El m�dulo de recolecci�n de informaciones de sistemas monitoreados no fue habilitado por el Administrador
es_UR     o modulo de coleta de informacoes de software nao foi habilitado pelo administrador                 relatoriosinfo                El m�dulo de recolecci�n de informaciones de software no fue habilitado por el Administrador
es_UR     o modulo de coleta de informacoes do antivirus officescan nao foi habilitado pelo administrador     relatoriosinfo                El m�dulo de recolecci�n de informaciones de Antivirus officeScan no fue habilitado por el Administrador
es_UR     opcoes administrativas                                                                              relatoriosinfo                Opciones administrativas
es_UR     permissao                                                                                           relatoriosinfo                Permisos
es_UR     periodo                                                                                             relatoriosinfo                Per�odo
es_UR     periodo da data de instalacao do antivirus para pesquisa                                            relatoriosinfo                Per�odo de la fecha de instalaci�n del antivirus para la b�squeda
es_UR     pesquisar                                                                                           relatoriosinfo                Buscar
es_UR     placa de som                                                                                        relatoriosinfo                Tarjeta de sonido
es_UR     placa de video                                                                                      relatoriosinfo                Tarjeta de video
es_UR     placa mae                                                                                           relatoriosinfo                Placa madre
es_UR     protocolo tcp/ip (configuracao principal)                                                           relatoriosinfo                Protocolo TCP/IP (Configuraci�n Principal)
es_UR     quantidade de cores                                                                                 relatoriosinfo                Cantidad de colores
es_UR     quantidade de memoria                                                                               relatoriosinfo                Cantidad de memoria
es_UR     registros                                                                                           relatoriosinfo                Registros
es_UR     registros nao encontrados na tabela %1 ou sua sessao expirou!                                       relatoriosinfo                Registros no encontrados en la tabla %1 o su sesi�n termino!
es_UR     registros nao encontrados na tabela %1 para os dados fornecidos!                                    relatoriosinfo                Registros no encontrados en la tabla %1 para los datos siempre!
es_UR     relatorio de alteracao de hardware                                                                  relatoriosinfo                Reporte de cambio de hardware
es_UR     relatorio de alteracoes de hardware                                                                 relatoriosinfo                Reporte de cambios de hardware
es_UR     relatorio de alteracoes de software                                                                 relatoriosinfo                Reporte de cambios de software
es_UR     relatorio de alteracoes de softwares instalados nos computadores da rede selecionada                relatoriosinfo                Reporte de cambios de software instalados en las computadoras de la red seleccionada
es_UR     relatorio de configuracoes de hardware                                                              relatoriosinfo                Reporte de las configuraciones de hardware
es_UR     relatorio de configuracoes do antivirus officescan                                                  relatoriosinfo                Reporte de las configuraciones de antivirus OfficeScan
es_UR     relatorio de informacoes de patrimonio e localizacao fisica                                         relatoriosinfo                Reporte de informaciones de patrimonio y localizaci�n f�sica
es_UR     relatorio de maquinas com inventario desatualizado                                                  relatoriosinfo                Reporte de las maquinas con inventario desactualizado
es_UR     relatorio de maquinas com inventario em branco                                                      relatoriosinfo                Reporte de las maquinas con inventario en blanco
es_UR     relatorio de maquinas com nome repetido                                                             relatoriosinfo                Reporte de las maquinas con el nombre repetido
es_UR     relatorio de pastas compartilhadas                                                                  relatoriosinfo                Reporte de directorios compartidos
es_UR     relatorio que exibe os compartilhamentos nos microcomputadores das redes selecionadas               relatoriosinfo                Reporte de muestra lo compartido en las computadoras de las redes seleccionadas
es_UR     remover computador                                                                                  relatoriosinfo                Borrar computadora
es_UR     removido                                                                                            relatoriosinfo                Borrado
es_UR     resolucao                                                                                           relatoriosinfo                Resoluci�n
es_UR     risco alto: integridade e privacidade                                                               relatoriosinfo                Riesgo alto: integridad y privacidad
es_UR     risco medio: privacidade                                                                            relatoriosinfo                Riesgo medio: privacidad
es_UR     rotulo                                                                                              relatoriosinfo                Rotulo:
es_UR     selecione as configuracoes de hardware que deseja exibir                                            relatoriosinfo                Seleccione las configuraciones de hardware que desea mostrar
es_UR     selecione as configuracoes que deseja exibir                                                        relatoriosinfo                Seleccione las configuraciones que desea mostrar
es_UR     selecione as redes                                                                                  relatoriosinfo                Seleccione las redes
es_UR     selecione os servidores de atualizacao para consulta                                                relatoriosinfo                Seleccione los servidores de actualizaci�n para consulta
es_UR     selecione os tipos de hardware a serem exibidos no relatorio.                                       relatoriosinfo                Seleccione los tipos de hardware que ser�n mostrados en el reporte
es_UR     servidor dhcp                                                                                       relatoriosinfo                Servidor DHCP
es_UR     servidor dns primario                                                                               relatoriosinfo                Servidor DNS primario
es_UR     servidor dns secundario                                                                             relatoriosinfo                Servidor DNS secundario
es_UR     servidor wins primario                                                                              relatoriosinfo                Servidor WINS primario
es_UR     servidor wins secundario                                                                            relatoriosinfo                Servidor WINS secundario
es_UR     servidor do officescan                                                                              relatoriosinfo                Servidor del OfficeScan
es_UR     servicos abertos para a rede                                                                        relatoriosinfo                Servicios abiertos para la red
es_UR     sistema de arquivos                                                                                 relatoriosinfo                Sistema de archivos
es_UR     sistemas monitorados                                                                                relatoriosinfo                Sistemas monitoreados
es_UR     slot                                                                                                relatoriosinfo                Slot
es_UR     softwares inventariados                                                                             relatoriosinfo                Softwares inventariados
es_UR     sao necessarios parametros para gerar o relatorios!                                                 relatoriosinfo                Son necesarios par�metros para generar los reportes!
es_UR     tamanho (mb)                                                                                        relatoriosinfo                Tama�o (MB)
es_UR     teclado                                                                                             relatoriosinfo                Teclado
es_UR     texto                                                                                               relatoriosinfo                Texto
es_UR     tipo                                                                                                relatoriosinfo                Tipo
es_UR     tipo componente                                                                                     relatoriosinfo                Tipo componente
es_UR     tipo de alteracao                                                                                   relatoriosinfo                Tipo de cambio
es_UR     todas                                                                                               relatoriosinfo                Todas
es_UR     unidades de discos                                                                                  relatoriosinfo                Unidades de disco
es_UR     utilizado                                                                                           relatoriosinfo                Utilizado
es_UR     utilizacao (%)                                                                                      relatoriosinfo                Utilizado (%)
es_UR     variaveis de ambiente                                                                               relatoriosinfo                Variables de ambiente
es_UR     versao do dao                                                                                       relatoriosinfo                Versi�n de DAO
es_UR     versao da maquina virtual java (jvm)                                                                relatoriosinfo                Versi�n de la maquina virtual java (JVM)
es_UR     versao do ado                                                                                       relatoriosinfo                Versi�n DAO
es_UR     versao do acrobat reader                                                                            relatoriosinfo                Versi�n del Acrobat Reader
es_UR     versao do bde                                                                                       relatoriosinfo                Versi�n de BDE
es_UR     versao do directx                                                                                   relatoriosinfo                Versi�n de DirectX
es_UR     versao do mozilla                                                                                   relatoriosinfo                Versi�n de Mozilla
es_UR     versao do odbc                                                                                      relatoriosinfo                Versi�n de ODBC
es_UR     versao agente principal                                                                             relatoriosinfo                Versi�n del agente principal
es_UR     versao do engine                                                                                    relatoriosinfo                Versi�n del motor
es_UR     versao gerente de coletas                                                                           relatoriosinfo                Versi�n del gerente de recolecci�n
es_UR     versao do gerente de coletas                                                                        relatoriosinfo                Versi�n del gerente de recolecci�n
es_UR     versao do internet explorer                                                                         relatoriosinfo                Versi�n de internet explorer
es_UR     versao do pattern                                                                                   relatoriosinfo                Versi�n de pattern
es_UR     versoes de softwares basicos                                                                        relatoriosinfo                Versi�n de software b�sicos
es_UR     ultimo login                                                                                        relatoriosinfo                �ltimo login
