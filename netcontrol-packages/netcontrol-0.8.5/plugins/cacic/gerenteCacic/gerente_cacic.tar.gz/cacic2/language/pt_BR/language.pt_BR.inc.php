pt_BR     (softwares nao classificados e softwares lixo)                                                      admin     info                (Softwares n�o classificados e softwares lixo)
pt_BR     (diferente de administrador):                                                                       admin     info                (diferente de administrador):
pt_BR     (icone na bandeja da estacao):                                                                      admin     info                (�cone na bandeja da esta��o):
pt_BR     --- selecione ---                                                                                   admin     info                --- Selecione ---
pt_BR     1 hora apos a inicializacao do cacic                                                                admin     info                1 hora ap�s a inicializa��o do CACIC
pt_BR     10 minutos apos a inicializacao do cacic                                                            admin     info                10 minutos ap�s a inicializa��o do CACIC
pt_BR     20 minutos apos a inicializacao do cacic                                                            admin     info                20 minutos ap�s a inicializa��o do CACIC
pt_BR     30 minutos apos a inicializacao do cacic                                                            admin     info                30 minutos ap�s a inicializa��o do CACIC
pt_BR     a cada 10 horas                                                                                     admin     info                A cada 10 horas
pt_BR     a cada 2 horas                                                                                      admin     info                A cada 2 horas
pt_BR     a cada 4 horas                                                                                      admin     info                A cada 4 horas
pt_BR     a cada 6 horas                                                                                      admin     info                A cada 6 horas
pt_BR     a cada 8 horas                                                                                      admin     info                A cada 8 horas
pt_BR     a inclusao de %1 e restrita ao administrador do sistema                                             admin     info                A inclus�o de %1 e restrita ao Administrador do sistema
pt_BR     a inclusao de %1 e restrita ao nivel administrativo.                                                admin     info                A inclus�o de %1 e restrita ao n�vel administrativo.
pt_BR     a sigla do local e obrigatoria                                                                      admin     info                A sigla do local � obrigat�ria
pt_BR     admin - excluir historico de software                                                               admin     info                ADMIN - Excluir hist�rico de software
pt_BR     atencao: verifique os campos para notificacao de alteracao de hardware                              admin     info                ATENCAO: Verifique os campos para notifica��o de altera��o de hardware
pt_BR     abrangencia                                                                                         admin     info                Abrang�ncia
pt_BR     abrir janela de coleta ao detectar alteracoes de localizacao fisica                                 admin     info                Abrir janela de coleta ao detectar altera��es de localiza��o f�sica
pt_BR     acesso                                                                                              admin     info                Acesso
pt_BR     acesso nao autorizado                                                                               admin     info                Acesso n�o autorizado
pt_BR     acessos                                                                                             admin     info                Acessos
pt_BR     acessos locais                                                                                      admin     info                Acessos locais
pt_BR     acoes                                                                                               admin     info                Acoes
pt_BR     acoes - configuracoes                                                                               admin     info                Acoes - Configura��es
pt_BR     aguarde processamento...                                                                            admin     info                Aguarde processamento...
pt_BR     ainda nao existem informacoes de patrimonio associadas ao local!                                    admin     info                Ainda n�o existem informa��es de patrim�nio associadas ao local!
pt_BR     ainda nao existem redes associadas ao local!                                                        admin     info                Ainda n�o existem redes associadas ao local!
pt_BR     ainda nao existem usuarios associados ao local!                                                     admin     info                Ainda n�o existem usu�rios associados ao local!
pt_BR     apenas nas redes selecionadas                                                                       admin     info                Apenas nas redes selecionadas
pt_BR     aplicativos (janelas) a evitar                                                                      admin     info                Aplicativos (janelas) a evitar
pt_BR     kciq_msg modulos help                                                                               admin     info                Aqui voc� podera configurar os v�rios m�dulos dispon�veis do CACIC. Clique sobre o m�dulo desejado e, em seguida, realize as configura��es.
pt_BR     aquisicao                                                                                           admin     info                Aquisi��o
pt_BR     aquisicao:                                                                                          admin     info                Aquisi��o:
pt_BR     aquisicoes                                                                                          admin     info                Aquisi��es
pt_BR     arquivo                                                                                             admin     info                Arquivo
pt_BR     kciq_msg detalhes de usuario help                                                                   admin     info                As informa��es abaixo referem-se ao usu�rio cadastrado no sistema. Ap�s o logon, ser�o exibidas a primeira e �ltima parte do campo <i>Nome completo</i>. Ao reinicializar a senha esta assume o valor contido no campo <i>Identifica��o</i>.
pt_BR     as informacoes abaixo referem-se as caracteristicas de instalacao de sistema a serem monitorados    admin     info                As informa��es abaixo referem-se �s caracter�sticas de instala��o de sistema a serem monitorados
pt_BR     inclusao de local help                                                                              admin     info                As informa��es que dever�o ser cadastradas abaixo referem-se a um local origin�rio de chamada ao sistema CACIC. Como por exemplo uma regi�o, um estado, um org�o etc.
pt_BR     kciq_msg inclusao de novo usuario help                                                              admin     info                As informa��es que dever�o ser cadastradas abaixo referem-se aos usu�rios do sistema, onde ser� determinado o tipo de acesso. <u><em>A senha inicial ser� gerada automaticamente em fun��o da identifica��o e poder� ser trocada pelo usu�rio na op��o <i>Acesso - Troca de Senha</i> no Menu Principal</em></u>. Ap�s o logon, ser�o exibidas a primeira e �ltima parte do campo <i>Nome completo</i>.
pt_BR     as informacoes referem-se a um local originario de chamadas ao sistema cacic                        admin     info                As informa��es referem-se a um local origin�rio de chamadas ao sistema CACIC
pt_BR     as opcoes abaixo determinam como o modulo gerente devera se comportar.                              admin     info                As op��es abaixo determinam como o m�dulo gerente dever� se comportar.
pt_BR     as opcoes abaixo determinam qual sera o comportamento dos agentes do                                admin     info                As op��es abaixo determinam qual ser� o comportamento dos agentes do
pt_BR     atencao                                                                                             admin     info                Aten��o
pt_BR     atencao: informe os emails separados por virgulas                                                   admin     info                Aten��o: informe os emails separados por v�rgulas
pt_BR     atencao: informe os enderecos separados por virgulas                                                admin     info                Aten��o: informe os endere�os separados por v�rgulas
pt_BR     atencao: informe os nomes separados por virgulas                                                    admin     info                Aten��o: informe os nomes separados por v�rgulas
pt_BR     atualizando                                                                                         admin     info                Atualizando
pt_BR     atualizacao especial                                                                                admin     info                Atualiza��o Especial
pt_BR     atualizacao de base de dados                                                                        admin     info                Atualiza��o de Base de Dados
pt_BR     autorizado                                                                                          admin     info                Autorizado
pt_BR     autorizados                                                                                         admin     info                Autorizados
pt_BR     autorizacao                                                                                         admin     info                Autoriza��o
pt_BR     acoes selecionadas para essa rede:                                                                  admin     info                A��es selecionadas para essa rede:
pt_BR     bairro                                                                                              admin     info                Bairro
pt_BR     contenha                                                                                            admin     info                CONTENHA
pt_BR     cacic2                                                                                              admin     info                Cacic2
pt_BR     cadastro de                                                                                         admin     info                Cadastro de
pt_BR     cadastro de aquisicao                                                                               admin     info                Cadastro de Aquisi��o
pt_BR     cadastro de aquisicoes                                                                              admin     info                Cadastro de Aquisi��es
pt_BR     cadastro de local                                                                                   admin     info                Cadastro de Local
pt_BR     cadastro de perfis de sistemas monitorados                                                          admin     info                Cadastro de Perfis de Sistemas Monitorados
pt_BR     cadastro de softwares                                                                               admin     info                Cadastro de Softwares
pt_BR     cadastro de softwares po estacao                                                                    admin     info                Cadastro de Softwares po Esta��o
pt_BR     cadastro de subredes                                                                                admin     info                Cadastro de Subredes
pt_BR     cadastro de unidade organizacional nivel 2                                                          admin     info                Cadastro de unidade organizacional n�vel 2
pt_BR     cadastro de usuarios                                                                                admin     info                Cadastro de usu�rios
pt_BR     caminho no servidor de atualizacoes                                                                 admin     info                Caminho no servidor de atualiza��es
pt_BR     caminho\\chave\\valor em registry                                                                   admin     info                Caminho\\Chave\\Valor em Registry
pt_BR     caminho\\nome do arquivo/secao/chave de arquivo ini                                                 admin     info                Caminho\\nome do arquivo/Se��o/Chave de Arquivo INI
pt_BR     campo                                                                                               admin     info                Campo
pt_BR     cancelar                                                                                            admin     info                Cancelar
pt_BR     cancelar alteracoes                                                                                 admin     info                Cancelar alteracoes
pt_BR     caracteristicas em ambientes windows 9x/me                                                          admin     info                Caracter�sticas em ambientes Windows 9x/Me
pt_BR     caracteristicas em ambientes windows nt/2000/xp/2003                                                admin     info                Caracter�sticas em ambientes Windows NT/2000/XP/2003
pt_BR     cidade                                                                                              admin     info                Cidade
pt_BR     cinco                                                                                               admin     info      5         Cinco
pt_BR     classificar softwares selecionados                                                                  admin     info                Classificar softwares selecionados
pt_BR     classificacao de software                                                                           admin     info                Classifica��o de software
pt_BR     clique nas colunas para ordenar                                                                     admin     info                Clique nas colunas para ordenar
pt_BR     coleta induzida por computador                                                                      admin     info                Coleta induzida por computador
pt_BR     computador                                                                                          admin     info                Computador
pt_BR     computador removido!                                                                                admin     info                Computador removido!
pt_BR     computador:                                                                                         admin     info                Computador:
pt_BR     computadores onde esta acao-configuracao nao devera ser aplicada                                    admin     info                Computadores onde esta a��o-configura��o n�o dever� ser aplicada
pt_BR     condicao                                                                                            admin     info                Condi��o
pt_BR     configuracao basica                                                                                 admin     info                Configura��o b�sica
pt_BR     configuracao da tela de patrimonio                                                                  admin     info                Configura��o da tela de patrim�nio
pt_BR     configuracao padrao                                                                                 admin     info                Configura��o padr�o
pt_BR     configuracoes do modulo gerente                                                                     admin     info                Configura��es do m�dulo Gerente
pt_BR     configuracoes dos modulos agentes                                                                   admin     info                Configura��es dos m�dulos Agentes
pt_BR     confirma a remocao deste computador?                                                                admin     info                Confirma a remo��o deste computador?
pt_BR     confirma configuracao de                                                                            admin     info                Confirma configura��o de
pt_BR     confirma configuracao de acao?                                                                      admin     info                Confirma configura��o de Acao?
pt_BR     confirma configuracao de agentes?                                                                   admin     info                Confirma configura��o de Agentes?
pt_BR     confirma configuracao de etiqueta 1?                                                                admin     info                Confirma configura��o de Etiqueta 1?
pt_BR     confirma configuracao de etiqueta 1a?                                                               admin     info                Confirma configura��o de Etiqueta 1a?
pt_BR     confirma configuracao de etiqueta 2?                                                                admin     info                Confirma configura��o de Etiqueta 2?
pt_BR     confirma configuracao de etiqueta 3?                                                                admin     info                Confirma configura��o de Etiqueta 3?
pt_BR     confirma configuracao para coleta de patrimonio?                                                    admin     info                Confirma configura��o para coleta de patrim�nio?
pt_BR     confirma exclusao                                                                                   admin     info                Confirma exclus�o
pt_BR     confirma exclusao de                                                                                admin     info                Confirma exclus�o de
pt_BR     confirma exclusao de rede                                                                           admin     info                Confirma exclus�o de Rede
pt_BR     confirma exclusao de perfil de sistema monitorado?                                                  admin     info                Confirma exclus�o de perfil de sistema monitorado?
pt_BR     confirma exclusao de usuario?                                                                       admin     info                Confirma exclus�o de usu�rio?
pt_BR     confirma exclusao do local e todas as suas dependencias?                                            admin     info                Confirma exclus�o do local E TODAS AS SUAS DEPEND�NCIAS?
pt_BR     confirma exclusao?                                                                                  admin     info                Confirma exclus�o?
pt_BR     confirma inclusao de local?                                                                         admin     info                Confirma inclus�o de local?
pt_BR     confirma inclusao de usuario?                                                                       admin     info                Confirma inclus�o de usu�rio?
pt_BR     confirma informacoes para                                                                           admin     info                Confirma informa��es para
pt_BR     confirma informacoes para o local?                                                                  admin     info                Confirma informa��es para o Local?
pt_BR     confirma informacoes para perfil de sistema monitorado?                                             admin     info                Confirma informa��es para perfil de sistema monitorado?
pt_BR     confirma informacoes para usuario?                                                                  admin     info                Confirma informa��es para usu�rio?
pt_BR     confirma troca de senha?                                                                            admin     info                Confirma troca de senha?
pt_BR     consulta de softwares autorizados por orgao                                                         admin     info                Consulta de softwares autorizados por org�o
pt_BR     consulta quantidade de licencas                                                                     admin     info                Consulta quantidade de licen�as
pt_BR     consultar                                                                                           admin     info                Consultar
pt_BR     contato                                                                                             admin     info                Contato
pt_BR     contatos para a subrede                                                                             admin     info                Contatos para a subrede
pt_BR     conteudo do repositorio                                                                             admin     info                Conte�do do reposit�rio
pt_BR     conteudo do servidor de atualizacoes                                                                admin     info                Conte�do do servidor de atualiza��es
pt_BR     controle de itens adiquiridos                                                                       admin     info                Controle de itens adiquiridos
pt_BR     controle de tipos de licencas                                                                       admin     info                Controle de tipos de licencas
pt_BR     dd/mm/aaaa                                                                                          admin     info                DD/MM/AAAA
pt_BR     diferente de                                                                                        admin     info                DIFERENTE DE
pt_BR     data                                                                                                admin     info                Data
pt_BR     data de autorizacao:                                                                                admin     info                Data de Autoriza��o:
pt_BR     data de desinstalacao:                                                                              admin     info                Data de Desinstala��o:
pt_BR     data de expiracao:                                                                                  admin     info                Data de Expira��o:
pt_BR     data de arquivo                                                                                     admin     info                Data de arquivo
pt_BR     data de autorizacao e um campo obrigatorio!                                                         admin     info                Data de autoriza��o e um campo obrigat�rio!
pt_BR     data de vencimento                                                                                  admin     info                Data de vencimento
pt_BR     data e hora                                                                                         admin     info                Data e hora
pt_BR     definir as configuracoes para sugestoes em formularios                                              admin     info                Definir as configura��es para sugest�es em formul�rios
pt_BR     desabilitar acao-configuracao nas redes                                                             admin     info                Desabilitar a��o-configura��o nas redes
pt_BR     descripcao                                                                                          admin     info                Descrip��o
pt_BR     descricao                                                                                           admin     info                Descri��o
pt_BR     descricao do tipo de acesso                                                                         admin     info                Descri��o do tipo de acesso
pt_BR     descricao:                                                                                          admin     info                Descri��o:
pt_BR     destacar as seguintes duplicidades no relatorio de patrimonio                                       admin     info                Destacar as seguintes duplicidades no relat�rio de patrim�nio
pt_BR     destacar duplicidades neste campo                                                                   admin     info                Destacar duplicidades neste campo
pt_BR     detalhes da subrede                                                                                 admin     info                Detalhes da Subrede
pt_BR     detalhes de                                                                                         admin     info                Detalhes de
pt_BR     detalhes de perfil de sistema monitorado                                                            admin     info                Detalhes de Perfil de Sistema Monitorado
pt_BR     detalhes de usuario                                                                                 admin     info                Detalhes de usu�rio
pt_BR     detalhes do local                                                                                   admin     info                Detalhes do Local
pt_BR     detalhes do software                                                                                admin     info                Detalhes do Software
pt_BR     deve-se ter o cuidado quanto a sensibilidade no uso de letras maiusculas e minusculas.              admin     info                Deve-se ter o cuidado quanto a sensibilidade no uso de letras mai�sculas e min�sculas.
pt_BR     dez                                                                                                 admin     info                Dez
pt_BR     dica: use shift ou ctrl para selecionar multiplos itens                                             admin     info                Dica: use SHIFT ou CTRL para selecionar m�ltiplos itens
pt_BR     digite a porta ftp do servidor de atualizacoes                                                      admin     info                Digite a porta FTP do servidor de atualiza��es
pt_BR     digite o identificador do servidor de banco de dados                                                admin     info                Digite o Identificador do Servidor de Banco de Dados
pt_BR     digite o nome do usuario para login no servidor de atualizacoes pelo modulo agente                  admin     info                Digite o Nome do Usuario para Login no Servidor de Atualizacoes pelo Modulo Agente
pt_BR     digite o nome do usuario para login no servidor de atualizacoes pelo modulo gerente                 admin     info                Digite o Nome do Usuario para Login no Servidor de Atualizacoes pelo Modulo Gerente
pt_BR     digite o caminho no servidor de atualizacoes                                                        admin     info                Digite o caminho no Servidor de Atualizacoes
pt_BR     digite o identificador do servidor de atualizacoes                                                  admin     info                Digite o identificador do servidor de atualiza��es
pt_BR     digite pelo menos 03 caracteres...                                                                  admin     info                Digite pelo menos 03 caracteres...
pt_BR     disponibilizar informacoes ao usuario comum?                                                        admin     info                Disponibilizar informa��es ao usu�rio comum?
pt_BR     disponibilizar informacoes no systray?                                                              admin     info                Disponibilizar informa��es no Systray?
pt_BR     disponiveis                                                                                         admin     info                Disponiveis
pt_BR     divisao                                                                                             admin     info                Divis�o
pt_BR     divisoes                                                                                            admin     info                Divis�es
pt_BR     dois                                                                                                admin     info                Dois
pt_BR     doze                                                                                                admin     info                Doze
pt_BR     e-mails para notificar alteracoes de hardware                                                       admin     info                E-mails para notificar alteracoes de hardware
pt_BR     editar registro                                                                                     admin     info                Editar registro
pt_BR     eh necessario informar ao menos uma condicao para pesquisa                                          admin     info                Eh necessario informar ao menos uma condicao para pesquisa
pt_BR     eh um sistema operacional?                                                                          admin     info                Eh um Sistema Operacional?
pt_BR     emails para contato                                                                                 admin     info                Emails para Contato
pt_BR     endereco                                                                                            admin     info                Endere�o
pt_BR     endereco ip                                                                                         admin     info                Endere�o IP
pt_BR     endereco ip origem                                                                                  admin     info                Endere�o IP origem
pt_BR     endereco mac                                                                                        admin     info                Endere�o MAC
pt_BR     endereco eletronico                                                                                 admin     info                Endere�o eletr�nico
pt_BR     endereco/mascara                                                                                    admin     info                Endere�o/M�scara
pt_BR     enderecos mac a desconsiderar                                                                       admin     info                Endere�os MAC a desconsiderar
pt_BR     enderooso eletronicos a notificar ao detectar alteracoes de patrimonio ou localizacao fisica        admin     info                Endere�os eletr�nicos a notificar ao detectar altera��es de patrim�nio ou localiza��o f�sica
pt_BR     enviando                                                                                            admin     info                Enviando
pt_BR     enviando...                                                                                         admin     info                Enviando...
pt_BR     erro no select ou sua sessao expirou                                                                admin     info                Erro no select ou sua sessao expirou
pt_BR     erro no select ou sua sessao expirou!                                                               admin     info                Erro no select ou sua sessao expirou!
pt_BR     esta opcao permite a selecao final para exclusao dos computadores selecionados na pesquisa          admin     info                Esta opcao permite a selecao final para exclusao dos computadores selecionados na pesquisa
pt_BR     kciq_msg excluir computadores advise                                                                admin     info                Esta op��o permite a exclus�o parametrizada das informa��es armazenadas na base sobre as esta��es monitoradas. Deve-se tomar muito cuidado com a abrang�ncia da condi��o a ser formulada.
pt_BR     kciq_msg mac address help                                                                           admin     info                Esta op��o tem por finalidade informar aos agentes coletores de informa��es de TCP/IP acerca de endere�os MAC inv�lidos, ou seja, os endere�os utilizados como padr�es em protocolos e/ou dispositivos diferentes de TCP/Ethernet. Os coletores considerar��o apenas os endere�os MAC diferentes ou que n�o contenham as informa��es aqui cadastradas, podendo ser partes de endere�os.
pt_BR     esta pagina permite induzir coletas em determinado computador                                       admin     info                Esta pagina permite induzir coletas em determinado computador
pt_BR     estacao                                                                                             admin     info                Esta��o
pt_BR     kciq_msg log de atividades help                                                                     admin     info                Este m�dulo permite a visualiza��o das atividades realizados com o uso das opera��es de INSERT/UPDATE/DELETE ocorridas no Sistema CACIC. A ordena��o das colunas poder� ser definida clicando-se em seus nomes.
pt_BR     ksiq_msg insuceso help                                                                              admin     info                Este m�dulo permite a visualiza��o das tentativas de instala��o dos agentes cujos resultados sejam INSUCESSO.
pt_BR     kciq_msg log de acessos help                                                                        admin     info                Este m�dulo permite a visualiza��o dos acessos efetuados no sistema. � poss�vel visualizar as atividades executadas pelo usu�rio na data, bastando clicar sobre uma de suas informa��es.
pt_BR     etiqueta 1                                                                                          admin     info                Etiqueta 1
pt_BR     etiqueta 1a                                                                                         admin     info                Etiqueta 1a
pt_BR     etiqueta 2                                                                                          admin     info                Etiqueta 2
pt_BR     etiqueta 3                                                                                          admin     info                Etiqueta 3
pt_BR     evita que o gerente de coletas seja acionado enquanto tais aplicativos (janelas) estiverem ativos   admin     info                Evita que o Gerente de Coletas seja acionado enquanto tais aplicativos (janelas) estiverem ativos
pt_BR     excluir                                                                                             admin     info                Excluir
pt_BR     excluir computadores                                                                                admin     info                Excluir Computadores
pt_BR     excluir local                                                                                       admin     info                Excluir Local
pt_BR     excluir computadores selecionados                                                                   admin     info                Excluir computadores selecionados
pt_BR     excluir perfil de sistema monitorado                                                                admin     info                Excluir perfil de sistema monitorado
pt_BR     excluir rede                                                                                        admin     info                Excluir rede
pt_BR     excluir registro                                                                                    admin     info                Excluir registro
pt_BR     excluir usuario                                                                                     admin     info                Excluir usuario
pt_BR     exclusao de softwares                                                                               admin     info                Exclusao de Softwares
pt_BR     exclusao de softwares nao associados a nenhuma maquina                                              admin     info                Exclusao de softwares nao associados a nenhuma maquina
pt_BR     executado apenas nas redes selecionadas                                                             admin     info                Executado apenas nas redes selecionadas
pt_BR     executado em todas as redes                                                                         admin     info                Executado em todas as redes
pt_BR     exemplo                                                                                             admin     info                Exemplo
pt_BR     exemplo:                                                                                            admin     info                Exemplo:
pt_BR     exemplo: arquivos de programas\\cacic\\dados\\config.ini/patrimonio/nu_cpu                          admin     info                Exemplo: Arquivos de Programas\\Cacic\\Dados\\config.ini/Patrimonio/nu_CPU
pt_BR     exemplo: hkey_local_machine\\software\\dataprev\\cacic2\\id_versao                                  admin     info                Exemplo: HKEY_LOCAL_MACHINE\\Software\\Dataprev\\Cacic2\\id_versao
pt_BR     exibe janela de patrimonio                                                                          admin     info                Exibe janela de patrim�nio
pt_BR     exibe os softwares inventariados nos computadores que nao estao associados a nenhuma maquina.       admin     info                Exibe os softwares inventariados nos computadores que n�o est�o associados a nenhuma m�quina.
pt_BR     exibir                                                                                              admin     info                Exibir
pt_BR     exibir graficos na pagina principal e detalhes                                                      admin     info                Exibir Graficos na Pagina Principal e Detalhes
pt_BR     exibir erros criticos aos usuarios                                                                  admin     info                Exibir erros criticos aos usuarios
pt_BR     exibir o icone do cacic na bandeja (systray)                                                        admin     info                Exibir o icone do CACIC na bandeja (systray)
pt_BR     ftp nao configurado                                                                                 admin     info                FTP nao configurado
pt_BR     falha em exclusao na tabela (%1) ou sua sessao expirou!                                             admin     info                Falha em exclusao na tabela (%1) ou sua sessao expirou!
pt_BR     falha em inclusao na tabela (%1) ou sua sessao expirou!                                             admin     info                Falha em inclusao na tabela (%1) ou sua sessao expirou!
pt_BR     falha na consulta a tabela (%1) ou sua sessao expirou!                                              admin     info                Falha na Consulta a tabela (%1) ou sua sessao expirou!
pt_BR     falha na insercao em (%1) ou sua sessao expirou!                                                    admin     info                Falha na Insercao em (%1) ou sua sessao expirou!
pt_BR     falha na atualizacao da tabela (%1) ou sua sessao expirou!                                          admin     info                Falha na atualizacao da tabela (%1) ou sua sessao expirou!
pt_BR     falha na atualizacao de configuracoes                                                               admin     info                Falha na atualizacao de configuracoes
pt_BR     falha na atualizacao na tabela (%1) ou sua sessao expirou!                                          admin     info                Falha na atualizacao na tabela (%1) ou sua sessao expirou!
pt_BR     falha na exclusao de configuracoes                                                                  admin     info                Falha na exclusao de configuracoes
pt_BR     date view format                                                                                    admin     info      d/m/Y     Formata��o de data
pt_BR     formato da data                                                                                     admin     info                Formato da data
pt_BR     formulario para classificacao de softwares                                                          admin     info                Formul�rio para classifica��o de softwares
pt_BR     formulario para importar dados de aquisicoes                                                        admin     info                Formul�rio para importar dados de aquisi��es
pt_BR     formulario para importar dados de itens de aquisicoes                                               admin     info                Formul�rio para importar dados de �tens de aquisi��es
pt_BR     formulario para importar dados de software                                                          admin     info                Formul�rio para importar dados de software
pt_BR     gercols                                                                                             admin     info                GerCols
pt_BR     gerado em                                                                                           admin     info                Gerado em
pt_BR     gerado por                                                                                          admin     info                Gerado por
pt_BR     gerafo em                                                                                           admin     info                Gerado em
pt_BR     gerencia                                                                                            admin     info                Ger�ncia
pt_BR     gerencias                                                                                           admin     info                Ger�ncias
pt_BR     graficos a serem exibidos                                                                           admin     info                Gr�ficos a serem exibidos
pt_BR     gravar                                                                                              admin     info                Gravar
pt_BR     gravar alteracoes                                                                                   admin     info                Gravar altera��es
pt_BR     gravar alteracoes?                                                                                  admin     info                Gravar altera��es?
pt_BR     gravar informacoes                                                                                  admin     info                Gravar informa��es
pt_BR     hod - microsoft word - corel draw - photoshop                                                       admin     info                HOD - Microsoft Word - Corel Draw - PhotoShop
pt_BR     habilitar acao-configuracao em todas as redes                                                       admin     info                Habilitar a��o-configura��o em todas as redes
pt_BR     consulta quantidade de licencas help                                                                admin     info                Havendo saldo positivo numa vers�o n�o implica disponibilidade de licen�a. O saldo pode estar cobrindo saldo negativo de vers�es anteriores.
pt_BR     resumo quantitativo de licencas help                                                                admin     info                Havendo saldo positivo numa vers�o n�o implica disponibilidade de licen�a. O saldo pode estar cobrindo saldo negativo de vers�es anteriores
pt_BR     historico                                                                                           admin     info                Hist�rico
pt_BR     historio de softwares excluidos com sucesso da base de dados                                        admin     info                Hist�rico de softwares exclu�dos com sucesso da base de dados
pt_BR     igual a                                                                                             admin     info                IGUAL A
pt_BR     inicie com                                                                                          admin     info                INICIE COM
pt_BR     ip gerente                                                                                          admin     info                IP Gerente
pt_BR     ip origem                                                                                           admin     info                IP Origem
pt_BR     ip de estacao e rede                                                                                admin     info                IP de esta��o e rede
pt_BR     ide                                                                                                 admin     info                Ide
pt_BR     identificacao                                                                                       admin     info                Identifica��o
pt_BR     identificador de instalacao                                                                         admin     info                Identificador de instala��o
pt_BR     identificador de licenca                                                                            admin     info                Identificador de licen�a
pt_BR     identificador de versao/configuracao                                                                admin     info                Identificador de vers�o/configura��o
pt_BR     imediatamente apos a inicializacao do cacic                                                         admin     info                Imediatamente ap�s a inicializa��o do CACIC
pt_BR     importante                                                                                          admin     info                Importante
pt_BR     importante:                                                                                         admin     info                Importante:
pt_BR     incluir                                                                                             admin     info                Incluir
pt_BR     incluir aquisicao                                                                                   admin     info                Incluir Aquisi��o
pt_BR     incluir informacoes de novo local                                                                   admin     info                Incluir Informa��es de Novo Local
pt_BR     incluir nova subrede                                                                                admin     info                Incluir Nova Subrede
pt_BR     incluir novo perfil de sistema                                                                      admin     info                Incluir Novo Perfil de Sistema
pt_BR     incluir novo software                                                                               admin     info                Incluir Novo Software
pt_BR     incluir novo usuario                                                                                admin     info                Incluir novo usu�rio
pt_BR     inclusao                                                                                            admin     info                Inclus�o
pt_BR     inclusao de                                                                                         admin     info                Inclus�o de
pt_BR     inclusao de local                                                                                   admin     info                Inclus�o de Local
pt_BR     inclusao de novo usuario                                                                            admin     info                Inclus�o de novo usu�rio
pt_BR     induzir coletas                                                                                     admin     info                Induzir coletas
pt_BR     informacoes de patrimonio associadas ao local                                                       admin     info                Informacoes de Patrimonio Associadas ao Local
pt_BR     informe a classificacao para o software.                                                            admin     info                Informe a classificacao para o software.
pt_BR     informe a senha anterior, caso nao se lembre, solicite a um administrador que a reinicialize.       admin     info                Informe a senha anterior, caso nao se lembre, solicite a um Administrador que a reinicialize.
pt_BR     informe data valida                                                                                 admin     info                Informe data valida
pt_BR     informe esse campo                                                                                  admin     info                Informe esse campo
pt_BR     informe o endereco mac do computador.                                                               admin     info                Informe o endereco MAC do computador.
pt_BR     informe o numero do processo:                                                                       admin     info                Informe o numero do processo:
pt_BR     informe o periodo em que foi realizada a aquisicao:                                                 admin     info                Informe o periodo em que foi realizada a aquisicao:
pt_BR     informe o setor onde esta localizado o equipamento.                                                 admin     info                Informe o setor onde esta localizado o equipamento.
pt_BR     informe os enderecos eletronicos separados por virgulas                                             admin     info                Informe os enderecos eletronicos separados por virgulas
pt_BR     informe processo de aquisicao                                                                       admin     info                Informe processo de aquisicao
pt_BR     informe software                                                                                    admin     info                Informe software
pt_BR     informe tipo de licenca                                                                             admin     info                Informe tipo de licenca
pt_BR     inicio de execucao das acoes                                                                        admin     info                Inicio de execucao das acoes
pt_BR     instalacoes                                                                                         admin     info                Instalacoes
pt_BR     intervalo de execucao das acoes                                                                     admin     info                Intervalo de execucao das acoes
pt_BR     intervalo de solicitacao aos usuarios de renovacao das informacoes de patrimonio e local fisica     admin     info                Intervalo de solicitacao aos usuarios de renovacao das informacoes de patrimonio e Local fisica
pt_BR     itens adiquiridos                                                                                   admin     info                Itens adiquiridos
pt_BR     legenda                                                                                             admin     info                Legenda
pt_BR     licencas                                                                                            admin     info                Licen�as
pt_BR     licencas autorizadas por estacao                                                                    admin     info                Licen�as autorizadas por esta��o
pt_BR     limite de conexoes ftp                                                                              admin     info                Limite de conex�es FTP
pt_BR     linha de negocio                                                                                    admin     info                Linha de neg�cio
pt_BR     linhas de negocios                                                                                  admin     info                Linhas de neg�cios
pt_BR     locais                                                                                              admin     info                Locais
pt_BR     locais secundarios                                                                                  admin     info                Locais secund�rios
pt_BR     local                                                                                               admin     info                Local
pt_BR     local da midia                                                                                      admin     info                Local da M�dia
pt_BR     local de aplicacao                                                                                  admin     info                Local de Aplica��o
pt_BR     local/rede                                                                                          admin     info                Local/Rede
pt_BR     localizacao da midia:                                                                               admin     info                Localiza��o da M�dia:
pt_BR     log de acessos                                                                                      admin     info                Log de Acessos
pt_BR     log de atividades                                                                                   admin     info                Log de Atividades
pt_BR     log de insucessos nas instalacoes dos agentes                                                       admin     info                Log de Insucessos nas Instala��es dos Agentes
pt_BR     maior que                                                                                           admin     info                MAIOR QUE
pt_BR     menor que                                                                                           admin     info                MENOR QUE
pt_BR     manutencao de redes/subredes                                                                        admin     info                Manuten��o de redes/subredes
pt_BR     maquinas                                                                                            admin     info                M�quinas
pt_BR     mascara                                                                                             admin     info                M�scara
pt_BR     mecanismo para atualizacao de arquivos diversos no servidor, no ambito da aplicacao.                admin     info                Mecanismo para atualiza��o de arquivos diversos no servidor, no �mbito da aplica��o.
pt_BR     mensagens                                                                                           admin     info                Mensagens
pt_BR     modulo para atualizacao das informacoes coletadas dos modulos gerentes descentralizados             admin     info                M�dulo para atualiza��o das informa��es coletadas dos m�dulos gerentes descentralizados
pt_BR     modulo para cadastramento de unidades organizacionais de nivel 1                                    admin     info                M�dulo para cadastramento de Unidades Organizacionais de N�vel 1
pt_BR     modulo para cadastramento de unidades organizacionais de nivel 1a                                   admin     info                M�dulo para cadastramento de Unidades Organizacionais de N�vel 1a
pt_BR     modulo para cadastramento de unidades organizacionais de nivel 2                                    admin     info                M�dulo para cadastramento de Unidades Organizacionais de N�vel 2
pt_BR     modulo para cadastramento manual de softwares por estacao                                           admin     info                M�dulo para cadastramento manual de softwares por esta��o
pt_BR     modulos                                                                                             admin     info                M�dulos
pt_BR     mostrar todos                                                                                       admin     info                Mostrar Todos
pt_BR     motivo                                                                                              admin     info                Motivo
pt_BR     kciq_msg cadastro de softwares help                                                                 admin     info                M�dulo para cadastramento manual de softwares para posterior utiliza��o referencial junto aos dados de licen�as.
pt_BR     nao contenha                                                                                        admin     info                NAO CONTENHA
pt_BR     nao atualizado                                                                                      admin     info                Nao Atualizado
pt_BR     nao enviado                                                                                         admin     info                Nao Enviado
pt_BR     nao ha registro de aquisicao de softwares                                                           admin     info                Nao Ha Registro de Aquisicao de Softwares
pt_BR     nao classificados:                                                                                  admin     info                Nao classificados:
pt_BR     nao e executado em nenhuma rede                                                                     admin     info                Nao e executado em nenhuma rede
pt_BR     nao foi possivel excluir o arquivo %1. verifique as permissoes de escrita no diretorio repositorio! admin     info                Nao foi possivel excluir o arquivo %1. Verifique as permissoes de escrita no diretorio repositorio!
pt_BR     nao foi possivel gravar o registro!                                                                 admin     info                Nao foi possivel gravar o registro!
pt_BR     nao foi selecionada nenhuma rede. deseja continuar?                                                 admin     info                Nao foi selecionada nenhuma rede. Deseja continuar?
pt_BR     nao foi selecionado nenhum sistema operacional. deseja continuar?                                   admin     info                Nao foi selecionado nenhum sistema operacional. Deseja continuar?
pt_BR     nao foram encontrados registros                                                                     admin     info                Nao foram encontrados registros
pt_BR     nao ha autorizacao para esta maquina                                                                admin     info                Nao ha autorizacao para esta maquina
pt_BR     nao ha historico desta maquina                                                                      admin     info                Nao ha historico desta maquina
pt_BR     nao informada descricao do tipo de licenca                                                          admin     info                Nao informada descricao do tipo de licenca
pt_BR     nao instalados:                                                                                     admin     info                Nao instalados:
pt_BR     nao solicitar renovacao                                                                             admin     info                Nao solicitar renovacao
pt_BR     nenhum acesso realizado no periodo informado                                                        admin     info                Nenhum acesso realizado no periodo informado
pt_BR     nenhum local cadastrado ou sua sessao expirou                                                       admin     info                Nenhum local cadastrado ou sua sessao expirou
pt_BR     nenhum registro encontrado!                                                                         admin     info                Nenhum registro encontrado!
pt_BR     nenhum software cadastrado                                                                          admin     info                Nenhum software cadastrado
pt_BR     nenhum usuario cadastrado ou sua sessao expirou!                                                    admin     info                Nenhum usu�rio cadastrado ou sua sess�o expirou!
pt_BR     nenhuma unidade organizacional de nivel %1 cadastrada                                               admin     info                Nenhuma Unidade Organizacional de Nivel %1 cadastrada
pt_BR     nenhuma acao realizada no periodo informado.                                                        admin     info                Nenhuma a��o realizada no per�odo informado.
pt_BR     nenhuma acao selecionada para essa rede!                                                            admin     info                Nenhuma a��o selecionada para essa rede!
pt_BR     nenhuma atividade realizada no periodo informado                                                    admin     info                Nenhuma atividade realizada no per�odo informado
pt_BR     nenhuma rede cadastrada ou sua sessao expirou!                                                      admin     info                Nenhuma rede cadastrada ou sua sess�o expirou!
pt_BR     kciq_msg repositorio help                                                                           admin     info                Nesta p�gina � poss�vel verificar o conte�do do reposit�rio, bem como excluir os objetos que n�o ser�o utilizados nos updates das SubRedes.
pt_BR     neste modulo deverao ser cadastrados os softwares avulsos, manipulados pelo sistema                 admin     info                Neste m�dulo dever�o ser cadastrados os softwares avulsos, manipulados pelo sistema
pt_BR     neste modulo deverao ser cadastrados os usuarios que acessarao o sistema.                           admin     info                Neste m�dulo deverao ser cadastrados os usu�rios que acessar�o o sistema.
pt_BR     ksiq_msg subredes help                                                                              admin     info                Neste m�dulo dever�o ser registradas todas as subredes onde os agentes do CACIC ser�o instalados.
pt_BR     ksiq_msg perfis                                                                                     admin     info                Neste m�dulo dever�o ser registrados os perf�s dos sistemas que ser�o monitorados pelo CACIC.
pt_BR     ksiq_msg cadastro help                                                                              admin     info                Neste m�dulo dever�o ser registrados todos os locais originais do sistema, para que seja poss�vel o controle centralizado
pt_BR     nivel                                                                                               admin     info                Nivel
pt_BR     nivel de acesso                                                                                     admin     info                Nivel de Acesso
pt_BR     nome                                                                                                admin     info                Nome
pt_BR     nome completo                                                                                       admin     info                Nome completo
pt_BR     nome da empresa:                                                                                    admin     info                Nome da empresa:
pt_BR     nome da maquina                                                                                     admin     info                Nome da m�quina
pt_BR     nome da organizacao                                                                                 admin     info                Nome da organiza��o
pt_BR     nome da organizacao-empresa-orgao                                                                   admin     info                Nome da organiza��o-empresa-�rg�o
pt_BR     nome da rede                                                                                        admin     info                Nome da rede
pt_BR     nome de executavel                                                                                  admin     info                Nome de execut�vel
pt_BR     nome de rede                                                                                        admin     info                Nome de rede
pt_BR     nome do computador                                                                                  admin     info                Nome do Computador
pt_BR     nome do local                                                                                       admin     info                Nome do Local
pt_BR     nome do software                                                                                    admin     info                Nome do Software
pt_BR     nome do proprietario:                                                                               admin     info                Nome do propriet�rio:
pt_BR     nome do sistema:                                                                                    admin     info                Nome do sistema:
pt_BR     nome e um campo obrigatorio!                                                                        admin     info                Nome � um campo obrigat�rio!
pt_BR     nome ou ip do servidor de aplicacao (gerente)                                                       admin     info                Nome ou IP do servidor de aplica��o (gerente)
pt_BR     nome ou ip do servidor de atualizacao (ftp)                                                         admin     info                Nome ou IP do servidor de atualiza��o (FTP)
pt_BR     nova senha                                                                                          admin     info                Nova senha
pt_BR     nove                                                                                                admin     info                Nove
pt_BR     numero da midia                                                                                     admin     info                N�mero da M�dia
pt_BR     numero da midia:                                                                                    admin     info                N�mero da M�dia:
pt_BR     numero da nota fiscal:                                                                              admin     info                N�mero da nota fiscal:
pt_BR     numero do patrimonio                                                                                admin     info                N�mero do Patrim�nio
pt_BR     numero do processo:                                                                                 admin     info                N�mero do Processo:
pt_BR     ksiq_msg not                                                                                        admin     info                N�o
pt_BR     nao                                                                                                 admin     info                N�o
pt_BR     o aplicativo (%1) ja esta cadastrado                                                                admin     info                O aplicativo (%1) j� est� cadastrado
pt_BR     o campo nome do aplicativo e obrigatorio.                                                           admin     info                O campo nome do aplicativo e obrigat�rio.
pt_BR     o local da rede e obrigatorio                                                                       admin     info                O local da rede e obrigat�rio
pt_BR     o nome do local e obrigatorio                                                                       admin     info                O nome do local e obrigat�rio
pt_BR     ok                                                                                                  admin     info                OK
pt_BR     observacao                                                                                          admin     info                Observa��o
pt_BR     observacao:                                                                                         admin     info                Observa��o:
pt_BR     observacoes                                                                                         admin     info                Observa��es
pt_BR     ocorreu erro no processamento...                                                                    admin     info                Ocorreu erro no processamento...
pt_BR     ocorreu um erro durante a atualizacao da tabela %1 ou sua sessao expirou                            admin     info                Ocorreu um erro durante a atualiza��o da tabela %1 ou sua sess�o expirou
pt_BR     ocorreu um erro durante a consulta a tabela tipos_software ou sua sessao expirou!                   admin     info                Ocorreu um erro durante a consulta � tabela tipos_software ou sua sess�o expirou!
pt_BR     ocorreu um erro durante exclusao de referencia em %1 ou sua sessao expirou!                         admin     info                Ocorreu um erro durante exclus�o de refer�ncia em %1 ou sua sess�o expirou!
pt_BR     ocorreu um erro no acesso a tabela %1 ou sua sessao expirou                                         admin     info                Ocorreu um erro no acesso a tabela %1 ou sua sess�o expirou
pt_BR     ocorreu um erro no select ou sua sessao expirou!                                                    admin     info                Ocorreu um erro no select ou sua sess�o expirou!
pt_BR     ocorreu um erro no select ou sua sessão expirou!                                                   admin     info                Ocorreu um erro no select ou sua sess�o expirou!
pt_BR     oito                                                                                                admin     info                Oito
pt_BR     ok!                                                                                                 admin     info                Ok!
pt_BR     onde executar essa acao-configuracao                                                                admin     info                Onde executar essa a��o-configura��o
pt_BR     onze                                                                                                admin     info                Onze
pt_BR     opcoes avancadas                                                                                    admin     info                Op��es avan�adas
pt_BR     opcoes da coleta de informacoes patrimoniais e localizacao fisica                                   admin     info                Op��es da Coleta de Informa��es Patrimoniais e Localiza��o F�sica
pt_BR     operacao                                                                                            admin     info                Opera��o
pt_BR     outros                                                                                              admin     info                Outros
pt_BR     tela de coleta de informacoes de patrimonio - ajuda                                                 admin     info                Para configurar a interface da tela de coleta de informa��es de patrim�nio que ser� exibida aos usu�rios, clique sobre os itens da tela abaixo e informe os valores desejados.
pt_BR     particular                                                                                          admin     info                Particular
pt_BR     patrimonio                                                                                          admin     info                Patrim�nio
pt_BR     patrimonio de destino:                                                                              admin     info                Patrim�nio de Destino:
pt_BR     patrimonio e um campo obrigatorio!                                                                  admin     info                Patrim�nio e um campo obrigat�rio!
pt_BR     patrimonio:                                                                                         admin     info                Patrim�nio:
pt_BR     percentual                                                                                          admin     info                Percentual
pt_BR     plural de texto da                                                                                  admin     info                Plural de texto da
pt_BR     por favor, preencha campo                                                                           admin     info                Por favor, preencha campo
pt_BR     por favor, selecione                                                                                admin     info                Por favor, selecione
pt_BR     kciq_msg help - induzir o envio das informacoes coletadas                                           admin     info                Por padr�o, os agentes do CACIC s� enviam as informa��es coletadas para o servidor caso seja identificada alguma altera��o em rela��o � coleta anterior. Abaixo est�o relacionadas as a��es de coletas poss�veis e as redes habilitadas via op��o Administra��o/M�dulos. Caso voc� selecione alguma rede abaixo, o envio das informa��es coletadas ser� <i>for�ado</i>, ou seja, as informa��es ser�o enviadas ao M�dulo Gerente mesmo que sejam id�nticas � �ltima coleta. <br><i><b>Use essa op��o apenas quando realmente necess�rio</b></i>.
pt_BR     porta                                                                                               admin     info                Porta
pt_BR     processamento realizado com sucesso                                                                 admin     info                Processamento realizado com sucesso
pt_BR     processo                                                                                            admin     info                Processo
pt_BR     processo de aquisicao                                                                               admin     info                Processo de aquisicao
pt_BR     processo:                                                                                           admin     info                Processo:
pt_BR     script                                                                                              admin     info                Programa
pt_BR     programa                                                                                            admin     info                Programa
pt_BR     proprietario                                                                                        admin     info                Propriet�rio
pt_BR     quant.                                                                                              admin     info                Quant.
pt_BR     quantidade                                                                                          admin     info                Quantidade
pt_BR     quantidade comprada                                                                                 admin     info                Quantidade Comprada
pt_BR     quantidade instalada                                                                                admin     info                Quantidade Instalada
pt_BR     quantidade de licencas                                                                              admin     info                Quantidade de Licencas
pt_BR     quantidade de licencas:                                                                             admin     info                Quantidade de Licencas:
pt_BR     quantidade de licencas e um campo obrigatorio!                                                      admin     info                Quantidade de licencas e um campo obrigatorio!
pt_BR     quantidade deve ser valor numerico                                                                  admin     info                Quantidade deve ser valor numerico
pt_BR     quantidade maxima de linhas em relatorios                                                           admin     info                Quantidade maxima de linhas em relatorios
pt_BR     quatro                                                                                              admin     info                Quatro
pt_BR     realizar notificacao caso haja alteracoes nas seguintes configuracoes de hardware                   admin     info                Realizar notifica��o caso haja altera��es nas seguintes configura��es de hardware
pt_BR     rede                                                                                                admin     info                Rede
pt_BR     redes                                                                                               admin     info                Redes
pt_BR     redes associadas ao local                                                                           admin     info                Redes Associadas ao Local
pt_BR     registro gravado!                                                                                   admin     info                Registro gravado!
pt_BR     reinicializar senha                                                                                 admin     info                Reinicializar senha
pt_BR     relatorio de aquisicoes de software                                                                 admin     info                Relatorio de Aquisicoes de Software
pt_BR     relatorio de aquisicoes de software particular                                                      admin     info                Relatorio de Aquisicoes de Software Particular
pt_BR     relatorio de autorizacoes cadastradas                                                               admin     info                Relatorio de Autorizacoes Cadastradas
pt_BR     relatorio de cadastros inconsistentes                                                               admin     info                Relatorio de Cadastros Inconsistentes
pt_BR     relatorio de instalacoes de software                                                                admin     info                Relatorio de Instalacoes de Software
pt_BR     relatorio de instalacoes de software particular                                                     admin     info                Relatorio de Instalacoes de Software Particular
pt_BR     relatorio de inventario de softwares                                                                admin     info                Relatorio de Inventario de Softwares
pt_BR     relatorio de processos de compra de software                                                        admin     info                Relatorio de Processos de Compra de Software
pt_BR     relatorio de softwares adquiridos                                                                   admin     info                Relatorio de Softwares Adquiridos
pt_BR     relatorio de softwares inventariados                                                                admin     info                Relatorio de Softwares Inventariados
pt_BR     relatorio de softwares inventariados por maquinas                                                   admin     info                Relatorio de Softwares Inventariados por Maquinas
pt_BR     relatorio de softwares particulares                                                                 admin     info                Relatorio de Softwares Particulares
pt_BR     relatorio de softwares por aquisicao                                                                admin     info                Relatorio de Softwares por Aquisicao
pt_BR     relatorio de softwares por processo                                                                 admin     info                Relatorio de Softwares por Processo
pt_BR     relatorio de cadastros inconsistentes ii                                                            admin     info                Relatorio de cadastros inconsistentes II
pt_BR     relatorio gerado pelo                                                                               admin     info                Relatorio gerado pelo
pt_BR     remocao de computador                                                                               admin     info                Remocao de computador
pt_BR     remover softwares da base de dados                                                                  admin     info                Remover Softwares da Base de Dados
pt_BR     repositorio                                                                                         admin     info                Repositorio
pt_BR     responsavel                                                                                         admin     info                Responsavel
pt_BR     restaurar                                                                                           admin     info                Restaurar
pt_BR     restaurar valores                                                                                   admin     info                Restaurar valores
pt_BR     resultado da consulta                                                                               admin     info                Resultado da consulta
pt_BR     resumo das operacoes                                                                                admin     info                Resumo das Opera��es
pt_BR     resumo das tentativas de instalacao                                                                 admin     info                Resumo das Tentativas de Instala��o
pt_BR     resumo quantitativo de licencas                                                                     admin     info                Resumo quantitativo de licen�as
pt_BR     retorna aos detalhes de local                                                                       admin     info                Retorna aos detalhes de Local
pt_BR     retorna para                                                                                        admin     info                Retorna para
pt_BR     seja nulo                                                                                           admin     info                SEJA NULO
pt_BR     seja vazio                                                                                          admin     info                SEJA VAZIO
pt_BR     saldo                                                                                               admin     info                Saldo
pt_BR     seis                                                                                                admin     info                Seis
pt_BR     selecao de redes para aplicacao desta coleta de informacoes                                         admin     info                Selecao de redes para aplicacao desta coleta de informacoes
pt_BR     selecionadas                                                                                        admin     info                Selecionadas
pt_BR     selecionados                                                                                        admin     info                Selecionados
pt_BR     selecionados:                                                                                       admin     info                Selecionados:
pt_BR     selecionar computadores para exclusao                                                               admin     info                Selecionar computadores para exclus�o
pt_BR     selecionar novamente                                                                                admin     info                Selecionar novamente
pt_BR     selecione                                                                                           admin     info                Selecione
pt_BR     selecione a gerencia de localizacao este equipamento                                                admin     info                Selecione a Ger�ncia de localiza��o este equipamento
pt_BR     selecione a linha de negocio de localizacao deste equipamento                                       admin     info                Selecione a Linha de neg�cio de localiza��o deste equipamento
pt_BR     selecione a divisao onde encontra-se este equipamento                                               admin     info                Selecione a divis�o onde encontra-se este equipamento
pt_BR     selecione local                                                                                     admin     info                Selecione local
pt_BR     selecione o periodo em que devera ser realizada a consulta                                          admin     info                Selecione o per�odo em que dever� ser realizada a consulta
pt_BR     selecione o periodo em que devera ser realizada a consulta:                                         admin     info                Selecione o per�odo em que dever� ser realizada a consulta:
pt_BR     selecione o periodo no qual devera ser realizada a consulta                                         admin     info                Selecione o per�odo no qual dever� ser realizada a consulta
pt_BR     selecione o software                                                                                admin     info                Selecione o software
pt_BR     selecione os filtros da consulta:                                                                   admin     info                Selecione os filtros da consulta:
pt_BR     selecione os softwares que deseja classificar:                                                      admin     info                Selecione os softwares que deseja classificar:
pt_BR     selecione os softwares que deseja remover:                                                          admin     info                Selecione os softwares que deseja remover:
pt_BR     selecione pelo menos 1 software.                                                                    admin     info                Selecione pelo menos 1 software.
pt_BR     selecione pelo menos um software                                                                    admin     info                Selecione pelo menos um software
pt_BR     senha                                                                                               admin     info                Senha
pt_BR     senha atual                                                                                         admin     info                Senha Atual
pt_BR     senha padrao para administrar o agente                                                              admin     info                Senha padr�o para administrar o agente
pt_BR     senha para admnistrar o agente                                                                      admin     info                Senha para administrar o agente
pt_BR     senha usada para configurar e finalizar os agentes                                                  admin     info                Senha usada para configurar e finalizar os agentes
pt_BR     servidor offline                                                                                    admin     info                Servidor OffLine
pt_BR     servidor de aplicacao padrao                                                                        admin     info                Servidor de Aplica��o padrao
pt_BR     servidor de atualizacoes (ftp)                                                                      admin     info                Servidor de Atualiza��es (FTP)
pt_BR     servidor de updates padrao                                                                          admin     info                Servidor de Atualiza��es Padr�o
pt_BR     servidor de aplicacao (gerente)                                                                     admin     info                Servidor de aplica��o (gerente)
pt_BR     servidor nao encontrado                                                                             admin     info                Servidor n�o encontrado
pt_BR     sete                                                                                                admin     info                Sete
pt_BR     setor                                                                                               admin     info                Setor
pt_BR     sigla do local                                                                                      admin     info                Sigla do Local
pt_BR     sim                                                                                                 admin     info                Sim
pt_BR     sistema monitorado                                                                                  admin     info                Sistema Monitorado
pt_BR     sistema operacional                                                                                 admin     info                Sistema Operacional
pt_BR     sistemas operacionais onde essa acao-configuracao devera ser aplicada                               admin     info                Sistemas Operacionais onde essa a��o-configura��o dever� ser aplicada
pt_BR     sistemas operacionais                                                                               admin     info                Sistemas operacionais
pt_BR     software                                                                                            admin     info                Software
pt_BR     software interno                                                                                    admin     info                Software Interno
pt_BR     software e um campo obrigatorio!                                                                    admin     info                Software � um campo obrigat�rio!
pt_BR     software(s) classificado(s) com sucesso!                                                            admin     info                Software(s) classificado(s) com sucesso!
pt_BR     software(s) deletado(s) com sucesso da base de dados.                                               admin     info                Software(s) deletado(s) com sucesso da base de dados.
pt_BR     softwares por aquisicao                                                                             admin     info                Softwares por Aquisi��o
pt_BR     status                                                                                              admin     info                Status
pt_BR     sua tentativa foi registrada no log                                                                 admin     info                Sua tentativa foi registrada no log
pt_BR     subrede                                                                                             admin     info                Subrede
pt_BR     sucesso na conexao ftp                                                                              admin     info                Sucesso na conex�o FTP
pt_BR     termine com                                                                                         admin     info                TERMINE COM
pt_BR     tabela                                                                                              admin     info                Tabela
pt_BR     tamanho (kb)                                                                                        admin     info                Tamanho (KB)
pt_BR     tamanho(kb)                                                                                         admin     info                Tamanho(kb)
pt_BR     tela de coleta de informacoes de patrimonio                                                         admin     info                Tela de Coleta de Informa��es de Patrim�nio
pt_BR     telefone                                                                                            admin     info                Telefone
pt_BR     telefones para contato                                                                              admin     info                Telefones para Contato
pt_BR     texto da                                                                                            admin     info                Texto da
pt_BR     texto de ajuda da                                                                                   admin     info                Texto de ajuda da
pt_BR     tipo da licenca                                                                                     admin     info                Tipo da Licen�a
pt_BR     tipo de acesso                                                                                      admin     info                Tipo de Acesso
pt_BR     tipo de licenca                                                                                     admin     info                Tipo de Licenca
pt_BR     tipo de licenca ja cadastrado                                                                       admin     info                Tipo de licenca ja cadastrado
pt_BR     tipo do software:                                                                                   admin     info                Tipo do software:
pt_BR     tipos de licenca                                                                                    admin     info                Tipos de licenca
pt_BR     totais de redes alvo                                                                                admin     info                Totais de Redes Alvo
pt_BR     total                                                                                               admin     info                Total
pt_BR     tres                                                                                                admin     info                Tr�s
pt_BR     troca de senha de acesso                                                                            admin     info                Troca de Senha de Acesso
pt_BR     ultima alteracao em                                                                                 admin     info                Ultima Altera��o em
pt_BR     unidade organizacional                                                                              admin     info                Unidade Organizacional
pt_BR     unidade organizacional nivel 1                                                                      admin     info                Unidade Organizacional Nivel 1
pt_BR     unidade organizacional nivel 1a                                                                     admin     info                Unidade Organizacional Nivel 1a
pt_BR     unidade organizacional nivel 2                                                                      admin     info                Unidade Organizacional Nivel 2
pt_BR     unidade da federacao                                                                                admin     info                Unidade da Federa��o
pt_BR     usuario                                                                                             admin     info                Usu�rio
pt_BR     usuarios associados ao local                                                                        admin     info                Usu�rios Associados ao Local
pt_BR     usuarios primarios                                                                                  admin     info                Usu�rios Prim�rios
pt_BR     usuarios secundarios                                                                                admin     info                Usu�rios Secund�rios
pt_BR     valor para pesquisa                                                                                 admin     info                Valor para pesquisa
pt_BR     verificacao ativa                                                                                   admin     info                Verifica��o Ativa
pt_BR     verificacao ativa?                                                                                  admin     info                Verifica��o Ativa?
pt_BR     verificacao efetuada                                                                                admin     info                Verifica��o efetuada
pt_BR     verifique os campos destacados em amarelo                                                           admin     info                Verifique os campos destacados em amarelo
pt_BR     versao de executavel                                                                                admin     info                Vers�o de execut�vel
pt_BR     visualizacao das ocorrencias com as operacoes de atualizacao, inclusao e exclusao no sistema.       admin     info                Visualiza��o das ocorr�ncias com as opera��es de atualiza��o, inclus�o e exclus�o no sistema.
pt_BR     voce deve informar a data de aquisicao.                                                             admin     info                Voc� deve informar a data de aquisi��o.
pt_BR     voce deve informar o numero do processo no formato                                                  admin     info                Voc� deve informar o n�mero do processo no formato
pt_BR     voltar                                                                                              admin     info                Voltar
pt_BR     a                                                                                                   admin     info                a
pt_BR     aaaa/nnnnnn                                                                                         admin     info                aaaa/nnnnnn
pt_BR     desenvolvido por                                                                                    admin     info                desenvolvido por
pt_BR     formato                                                                                             admin     info                formato
pt_BR     formato:                                                                                            admin     info                formato:
pt_BR     jose.silva@es.previdenciasocial.gov.br, luis.almeida@xyz.com                                        admin     info                jose.silva@es.previdenciasocial.gov.br, luis.almeida@xyz.com
pt_BR     mes                                                                                                 admin     info                mes
pt_BR     meses                                                                                               admin     info                meses
pt_BR     messagem do servidor:                                                                               admin     info                messagem do servidor:
pt_BR     para acesso do agente                                                                               admin     info                para acesso do agente
pt_BR     para acesso do gerente                                                                              admin     info                para acesso do gerente
pt_BR     eh necessario informar ao menos uma condicao para pesquisa                                          admin     info                � necess�rio informar ao menos uma condi��o para pesquisa
pt_BR     eh um sistema operacional?                                                                          admin     info                � um Sistema Operacional?
pt_BR     a pesquisa nao retornou registros                                                                   statisticsinfo                A pesquisa n�o retornou registros
pt_BR     clique sobre o nome da maquina para ver os detalhes da mesma                                        statisticsinfo                Clique sobre o nome da m�quina para ver os detalhes da mesma
pt_BR     dica: use shift or ctrl para selecionar multiplos itens                                             statisticsinfo                Dica: use SHIFT or CTRL para selecionar m�ltiplos itens
pt_BR     disponiveis:                                                                                        statisticsinfo                Dispon�veis:
pt_BR     engine                                                                                              statisticsinfo                Engine
pt_BR     estatisticas de antivirus officescan - informe                                                      statisticsinfo                Esta op��o exibe estat�sticas sobre o Antiv�rus OfficeScan nos computadores das redes selecionadas. � poss�vel determinar os sistemas operacionais e a abrang�ncia das redes.
pt_BR     estatisticas de sistemas monitorados - informe                                                      statisticsinfo                Esta op��o exibe estat�sticas sobre os Sistemas monitorados nos computadores das redes selecionadas. � poss�vel determinar quais sistemas ser�o exibidos, os sistemas operacionais e a abrang�ncia das redes.
pt_BR     estatisticas de antivirus officescan                                                                statisticsinfo                Estat�sticas de Antiv�rus OfficeScan
pt_BR     estatisticas de sistemas monitorados                                                                statisticsinfo                Estat�sticas de sistemas monitorados
pt_BR     gerar relatorio                                                                                     statisticsinfo                Gerar relat�rio
pt_BR     ip                                                                                                  statisticsinfo                IP
pt_BR     licenca                                                                                             statisticsinfo                Licen�a
pt_BR     pattern                                                                                             statisticsinfo                Pattern
pt_BR     relacao de maquinas com o engine                                                                    statisticsinfo                Rela��o de m�quinas com o engine
pt_BR     relacao de maquinas com o pattern                                                                   statisticsinfo                Rela��o de m�quinas com o pattern
pt_BR     selecione os sistemas monitorados que deseja exibir:                                                statisticsinfo                Selecione os sistemas monitorados que deseja exibir:
pt_BR     sequencial                                                                                          statisticsinfo                Sequencial
pt_BR     total de maquinas                                                                                   statisticsinfo                Total de m�quinas
pt_BR     versao                                                                                              statisticsinfo                Vers�o
pt_BR     ultima coleta                                                                                       statisticsinfo                �ltima coleta
pt_BR     % livre                                                                                             geral     info                % livre
pt_BR     % ocupado                                                                                           geral     info                % ocupado
pt_BR     (dica: use shift ou ctrl para selecionar multiplos itens)                                           geral     info                (Dica: use SHIFT ou CTRL para selecionar multiplos itens)
pt_BR     (obs: estao sendo exibidas somente as redes selecionadas pelo administrador.)                       geral     info                (OBS: Est�o sendo exibidas somente as redes selecionadas pelo administrador.)
pt_BR     kciq_msg total referente a multi-locais                                                             geral     info                <b>ATEN��O:</b> Total referente a mais de uma localidade.
pt_BR     <strong>todas</strong> as redes                                                                     geral     info                <strong>Todas</strong> as redes
pt_BR     kciq_msg access denied                                                                              geral     erro                Acesso n�o permitido
pt_BR     kciq_msg admin not reg                                                                              geral     info                Administrador n�o foi cadastrado
pt_BR     admin                                                                                               geral     TagHeader           Administra��o
pt_BR     kciq_msg advise                                                                                     geral     info                Alerta
pt_BR     anterior                                                                                            geral     info                Anterior
pt_BR     apenas redes <strong>selecionadas</strong>                                                          geral     info                Apenas redes <strong>selecionadas</strong>
pt_BR     kciq_msg apoio                                                                                      Geral     info                Apoio colaborativo
pt_BR     kciq_msg file saved                                                                                 geral     info                Arquivo (%1) foi salvo
pt_BR     kciq_msg attention                                                                                  geral     info                Aten��o
pt_BR     kciq_msg update                                                                                     geral     info                Atualiza��o
pt_BR     acao                                                                                                geral     info                A��o
pt_BR     kciq_msg database not exist                                                                         geral     info                Banco de dados (%1) n�o existe!
pt_BR     kciq_msg computadores monitorados hoje                                                              geral     info                Computadores monitorados por local nesta data
pt_BR     kciq_msg connected ok                                                                               geral     info                Conex�o realizada com sucesso
pt_BR     kciq_msg configurations                                                                             Geral     info                Configura��es
pt_BR     kciq_msg verify                                                                                     geral     info                Confirma��o
pt_BR     kciq_msg backup                                                                                     geral     info                C�pia de seguran�a
pt_BR     de 180 a 365 dias...                                                                                geral     info                De 180 a 365 dias...
pt_BR     de 30 a 180 dias....                                                                                geral     info                De 30 a 180 dias....
pt_BR     de 5 a 30 dias......                                                                                geral     info                De 5 a 30 dias......
pt_BR     kciq_msg ftp change dir ok                                                                          geral     info                Diret�rio FTP mudado com sucesso
pt_BR     kciq_msg org label                                                                                  geral     info                Empresa
pt_BR     kciq_msg email                                                                                      geral     info                Endere�o eletr�nico
pt_BR     language_en-us                                                                                      Geral     info      en-US     English (US)
pt_BR     kciq_msg error                                                                                      geral     erro                Erro
pt_BR     kciq_msg org name update error                                                                      geral     erro                Erro ao tentar atualizar o nome da empresa
pt_BR     kciq_msg update on table fail                                                                       geral     erro                Erro ao tentar atualizar registros na(s) tabela(s) (%1)
pt_BR     kciq_msg delete row on table fail                                                                   geral     erro                Erro ao tentar excluir registros na tabela %1
pt_BR     kciq_msg insert row on table fail                                                                   geral     erro                Erro ao tentar incluir registro(s) na(s) tabela(s) %1
pt_BR     kciq_msg login insert error                                                                         geral     erro                Erro ao tentar inserir dados de login!
pt_BR     kciq_msg local insert error                                                                         geral     erro                Erro ao tentar inserir dados do Local!
pt_BR     kciq_msg config local insert error                                                                  geral     erro                Erro ao tentar inserir configuracoes para o Local!
pt_BR     kciq_msg user insert error                                                                          geral     erro                Erro ao tentar inserir o usu�rio (%1)
pt_BR     kciq_msg select on table fail                                                                       geral     erro                Erro ao tentar obter registros na(s) tabela(s) (%1)
pt_BR     language_es                                                                                         Geral     info      es        Espa�ol
pt_BR     essa opcao permite a selecao de coletas de informacoes de sistemas monitorados para essa rede.      geral     info                Essa opcao permite a selecao de coletas de informacoes de sistemas monitorados para essa rede.
pt_BR     statistics                                                                                          geral     TagHeader           Estat�sticas
pt_BR     kciq_msg statistics                                                                                 geral     info                Estat�sticas
pt_BR     kciq_msg cacic statistics                                                                           geral     info                Estat�sticas do CACIC
pt_BR     kciq_msg ftp login connect fail                                                                     geral     erro                Falha ao logar no servidor FTP
pt_BR     kciq_msg ftp change dir fail                                                                        geral     erro                Falha ao tentar alterar diret�rio FTP
pt_BR     kciq_msg ftp connect fail                                                                           geral     erro                Falha na conex�o FTP
pt_BR     language_fr                                                                                         Geral     info      fr        Franc�
pt_BR     geral                                                                                               Geral     TagHeader           Geral
pt_BR     hoje................                                                                                geral     info                Hoje................
pt_BR     ha 1 dia............                                                                                geral     info                H� 1 dia............
pt_BR     ha 2 dias...........                                                                                geral     info                H� 2 dias...........
pt_BR     ha 3 dias...........                                                                                geral     info                H� 3 dias...........
pt_BR     ha 4 dias...........                                                                                geral     info                H� 4 dias...........
pt_BR     ha mais de 365 dias.                                                                                geral     info                H� mais de 365 dias.
pt_BR     id externa                                                                                          geral     info                ID Externa
pt_BR     language                                                                                            Geral     info                Idioma
pt_BR     induzir o envio das informacoes coletadas                                                           geral     info                Induzir o envio das informacoes coletadas
pt_BR     kciq_msg instalada                                                                                  geral     info                Instalada
pt_BR     instalador                                                                                          geral     TagHeader           Instalador
pt_BR     kciq_msg legenda                                                                                    geral     info                Legenda
pt_BR     kciq_msg local already exist                                                                        geral     info                Local (%1) j� est� cadastrado!
pt_BR     kciq_msg local not exist                                                                            geral     info                Local (%1) n�o cadastrado!
pt_BR     kciq_msg local not reg                                                                              geral     info                Local n�o foi cadastrado
pt_BR     localizacao ou nome da subrede                                                                      geral     info                Localizacao ou nome da SubRede
pt_BR     kciq_msg login                                                                                      Geral     info                Login
pt_BR     kciq_msg login already exist                                                                        geral     info                Login (%1) j� est� cadastrado!
pt_BR     kciq_msg login not exist                                                                            geral     info                Login (%1) n�o existe.
pt_BR     kciq_msg ftp login ok                                                                               geral     info                Login com sucesso no FTP
pt_BR     kciq_msg admin login needed                                                                         geral     info                Login do administrador deve ser informado!
pt_BR     kciq_msg logout                                                                                     Geral     info                Logoff
pt_BR     manutencao                                                                                          geral     TagHeader           Manuten��o
pt_BR     manuten��o                                                                                          geral     TagHeader           Manuten��o
pt_BR     marca ou desmarca acao para as redes abaixo                                                         geral     info                Marca ou Desmarca Acao para as Redes abaixo
pt_BR     marca/desmarca todas as acoes para todas as redes abaixo                                            geral     info                Marca/Desmarca todas as Acoes para todas as Redes abaixo
pt_BR     kciq_msg mensagem                                                                                   Geral     info                Mensagem
pt_BR     kciq_msg server msg                                                                                 geral     info                Mensagem do servidor
pt_BR     verificacao-atualizacao dos servidores de updates help                                              geral     info                M�dulo para verifica��o/atualiza��o das vers�es dos objetos localizados nos servidores de updates das subredes monitoradas.
pt_BR     nao disponivel                                                                                      geral     info                Nao disponivel
pt_BR     navegar nas redes detectadas pelos agentes nas estacoes                                             geral     info                Navegar nas redes detectadas pelos agentes nas estacoes
pt_BR     kciq_msg login needed                                                                               geral     info                Necess�rio haver autentica��o
pt_BR     kciq_msg name                                                                                       geral     info                Nome
pt_BR     kciq_msg org label needed                                                                           geral     erro                Nome da empresa deve ser informado!
pt_BR     kciq_msg org label help                                                                             geral     ajuda               Nome da empresa onde est� instalado o gerente
pt_BR     kciq_msg admin name needed                                                                          geral     info                Nome do administrador deve ser informado!
pt_BR     kciq_msg local name needed                                                                          geral     info                Nome do local deve ser informado!
pt_BR     kciq_msg ftp user help                                                                              geral     ajuda               Nome do usu�rio FTP
pt_BR     kciq_msg ftp host help                                                                              geral     help                Nome ou IP do servidor FTP
pt_BR     kciq_msg new                                                                                        Geral     info                Nova
pt_BR     kciq_msg no                                                                                         geral     info                N�o
pt_BR     kciq_msg database connect fail                                                                      geral     erro                N�o foi poss�vel conectar ao banco de dados
pt_BR     kciq_msg access level                                                                               Geral     info                N�vel de acesso
pt_BR     kciq_msg javascript not enabled                                                                     geral     erro                O Javascript � indispens�vel ao perfeito funcionamento do Sistema
pt_BR     kciq_msg obs                                                                                        geral     info                Observa��o
pt_BR     ocorreu um erro no acesso a tabela %1 ou sua sessao expirou!                                        geral     info                Ocorreu um erro no acesso a tabela %1 ou sua sessao expirou!
pt_BR     kciq_msg ok                                                                                         geral     info                Ok
pt_BR     pagina anterior                                                                                     geral     info                Pagina anterior
pt_BR     paginacao                                                                                           geral     info                Paginacao
pt_BR     kciq_menu fast search                                                                               Geral     info                Pesquisa r�pida
pt_BR     kciq_menu search                                                                                    Geral     info                Pesquisar
pt_BR     kciq_msg ftp port help                                                                              geral     ajuda               Porta FTP no servidor
pt_BR     language_pt_br                                                                                      Geral     info      pt_BR     Portugu�s Brasileiro
pt_BR     primeira                                                                                            geral     info                Primeira
pt_BR     primeira pagina                                                                                     geral     info                Primeira pagina
pt_BR     proxima                                                                                             geral     info                Proxima
pt_BR     proxima pagina                                                                                      geral     info                Proxima pagina
pt_BR     kciq_msg next                                                                                       Geral     info                Pr�ximo
pt_BR     quantidade real baseada em mac-address                                                              geral     info                Quantidade real baseada em MAC-Address
pt_BR     kciq_msg ftp verify help                                                                            geral     info                Realiza teste de verifica��o de servidor FTP, n�o salva na base de dados do sistema devendo ser configurado p�s instala��o.
pt_BR     kciq_msg backup help                                                                                geral     info                Realizar c�pia do banco de dados por seguran�a.
pt_BR     redes cadastradas                                                                                   geral     info                Redes cadastradas
pt_BR     relatorio de estacoes por sistema operacional                                                       geral     info                Relatorio de estacoes por sistema operacional
pt_BR     relatorios                                                                                          geral     TagHeader           Relat�rios
pt_BR     kciq_msg requerida                                                                                  geral     info                Requerida
pt_BR     kciq_msg save                                                                                       geral     info                Salvar
pt_BR     selecao para coleta de informacoes de sistemas monitorados:                                         geral     info                Selecao para coleta de informacoes de sistemas monitorados:
pt_BR     selecionadas:                                                                                       geral     info                Selecionadas:
pt_BR     selecione os locais:                                                                                geral     info                Selecione os locais:
pt_BR     kciq_msg password                                                                                   Geral     info                Senha
pt_BR     kciq_msg ftp password help                                                                          geral     ajuda               Senha do usu�rio FTP
pt_BR     kciq_msg password needed                                                                            geral     info                Senhas devem ser informadas e confirmadas!
pt_BR     kciq_msg password not same                                                                          geral     info                Senhas n�o s�o iguais!
pt_BR     kciq_msg session fail                                                                               geral     erro                Sess�o expirou
pt_BR     kciq_msg abbr                                                                                       geral     info                Sigla
pt_BR     kciq_msg local abbr needed                                                                          geral     info                Sigla do local deve ser informada!
pt_BR     kciq_msg yes                                                                                        geral     info                Sim
pt_BR     kciq_msg ftp subdir                                                                                 geral     info                Subdiret�rio FTP
pt_BR     kciq_msg ftp subdir help                                                                            geral     ajuda               Subdiret�rio FTP no servidor
pt_BR     kciq_msg phone                                                                                      geral     info                Telefone
pt_BR     kciq_msg total of computers per local                                                               geral     info                Totais de computadores monitorados por local
pt_BR     kciq_msg total of computers per os                                                                  geral     info                Totais de computadores monitorados por sistemas operacionais
pt_BR     kciq_msg real total of computers mac based                                                          geral     info                Total real de computadores monitorados (com base no Mac-Address)
pt_BR     ultima                                                                                              geral     info                Ultima
pt_BR     ultima pagina                                                                                       geral     info                Ultima pagina
pt_BR     ultimo acesso                                                                                       geral     info                Ultimo acesso
pt_BR     um                                                                                                  geral     info                Um
pt_BR     kciq_msg user                                                                                       Geral     info                Usu�rio
pt_BR     kciq_msg invalid user or pass                                                                       geral     info                Usu�rio n�o cadastrado ou senha inv�lida
pt_BR     kciq_msg details                                                                                    geral     info                Ver detalhes
pt_BR     kciq_msg check                                                                                      geral     info                Verificar
pt_BR     kciq_msg ftp verify                                                                                 geral     info                Verifica��o de servidor FTP
pt_BR     kciq_msg check_notok                                                                                geral     info                Verifica��o n�o satisfeita
pt_BR     kciq_msg check_ok                                                                                   geral     info                Verifica��o satisfeita
pt_BR     verificacao/atualizacao dos servidores de updates                                                   geral     info                Verifica��o/Atualiza��o dos Servidores de Updates
pt_BR     kciq_msg version                                                                                    geral     info                Vers�o
pt_BR     versao do agente principal                                                                          geral     info                Vers�o do agente principal
pt_BR     kciq_msg login needed                                                                               geral     info                � necess�rio efetuar autentica��o
pt_BR     ultimo acesso                                                                                       geral     info                �ltimo acesso
pt_BR     kciq_msg last agents access                                                                         geral     info                �ltimos acessos dos agentes
pt_BR     kciq_msg last agents access on local                                                                geral     info                �ltimos acessos dos agentes deste local
pt_BR     kciq_msg last agents access per local                                                               geral     info                �ltimos acessos dos agentes por local nesta data
pt_BR     kciq_msg inst end advise                                                                            instaladorinfo                <p><b>Aten��o:</b> Leia as mensagens no fim desta p�gina sobre o processo de instala��o, bem como as <b>recomenda��es</b> abaixo:</p>
pt_BR     kciq_msg aceitar                                                                                    instaladorinfo                Aceitar
pt_BR     kciq_msg aceito                                                                                     instaladorinfo                Aceito a licen�a
pt_BR     kciq_msg admin mgm title                                                                            instaladorinfo                Administra��o do CACIC-Gerente
pt_BR     kciq_msg check_advise                                                                               instaladorinfo                Alerta, mas poder� continuar
pt_BR     kciq_msg previous                                                                                   instaladorinfo                Anterior
pt_BR     kciq_msg cfgfile_writeable                                                                          instaladorinfo                Arquivo <i><b>config.php</b></i> pode ser gravado
pt_BR     kciq_msg inst org name update                                                                       instaladorinfo                Atualizando nome da empresa...
pt_BR     kciq_msg update help                                                                                instaladorinfo                Atualizar as tabelas do banco conforme vers�o a ser escolhida.
pt_BR     kciq_msg inst update tables on database                                                             instaladorinfo                Atualiza��o das tabelas no banco de dados (%1)...
pt_BR     kciq_msg database                                                                                   instaladorinfo                Banco de dados
pt_BR     kciq_msg inst database exist                                                                        instaladorinfo                Banco de dados (%1) j� existe!
pt_BR     kciq_msg inst make database permissions                                                             instaladorinfo                Concedendo permiss�es ao usu�rio (%1).
pt_BR     kciq_msg inst end title                                                                             instaladorinfo                Conclus�o da instala��o do CACIC
pt_BR     kciq_msg inst connecting to database server                                                         instaladorinfo                Conectando ao servidor de banco de dados
pt_BR     kciq_msg inst database connect ok                                                                   instaladorinfo                Conex�o realizada com sucesso!
pt_BR     kciq_msg admin mgm verify pass help                                                                 instaladorinfo                Confirmar senha do Administrador do CACIC
pt_BR     kciq_msg build bd                                                                                   instaladorinfo                Construir BD
pt_BR     kciq_msg new help                                                                                   instaladorinfo                Construir o banco de dados para uma nova instala��o do CACIC.
pt_BR     kciq_msg inst database build fail                                                                   instaladorinfo                Constru��o do banco de dados para o CACIC n�o realizada adequadamente!
pt_BR     kciq_msg inst building tables on database                                                           instaladorinfo                Criando as tabelas no banco de dados (%1) ...
pt_BR     kciq_msg inst build database                                                                        instaladorinfo                Criando o banco (%1) ...
pt_BR     kciq_msg build bd help                                                                              instaladorinfo                Criar banco de dados.
pt_BR     kciq_msg database table build                                                                       instaladorinfo                Cria��o das tabelas do banco de dados!
pt_BR     kciq_msg inst admin data succesfuly created                                                         instaladorinfo                Dados administrativos inseridos com sucesso!
pt_BR     kciq_msg admin mgm local                                                                            instaladorinfo                Dados de localiza��o
pt_BR     kciq_msg admin mgm data title                                                                       instaladorinfo                Dados do Administrador
pt_BR     kciq_msg inst database data save fail                                                               instaladorinfo                Dados do Local e Usu�rio administrador n�o gravados no banco de dados!
pt_BR     kciq_msg inst admin help                                                                            instaladorinfo                Dados do administrador para criar o banco de dados.
pt_BR     kciq_msg check cacic configfile data                                                                instaladorinfo                Dados do arquivo de configura��o (%1) devem ser verificados.
pt_BR     kciq_msg demo                                                                                       instaladorinfo                Demonstra��o
pt_BR     kciq_msg admin mgm email help                                                                       instaladorinfo                Endere�o eletr�nico do Administrador do CACIC para envio de mesagens
pt_BR     kciq_msg inst check dir perm                                                                        instaladorinfo                Erro ao tentar gravar o arquivo %1. Verifique diret�rio e permiss�es!
pt_BR     kciq_msg inst build database error                                                                  instaladorerro                Erro na cria��o do banco de dados (%1)!
pt_BR     kciq_msg php_memory_help                                                                            instaladorinfo                Essa diretiva ir� afetar o desempenho de execu��o dos programas em PHP.
pt_BR     kciq_msg php_flag_on_advise                                                                         instaladorinfo                Essa diretiva � verificada apenas para vers�o PHP = 5.x.y.
pt_BR     kciq_msg finish                                                                                     instaladorinfo                Finalizar
pt_BR     kciq_msg savecfgfile                                                                                instaladorinfo                Gravar <i>config.php</i>
pt_BR     kciq_msg inst config file saved                                                                     instaladorinfo                Grava��o do arquivo de configura��es n�o realizada adequadamente!
pt_BR     kciq_msg inst end hist title                                                                        instaladorinfo                Hist�rico de altera��es no CACIC
pt_BR     kciq_msg ideal                                                                                      instaladorinfo                Ideal
pt_BR     kciq_msg def_language                                                                               instaladorinfo                Idioma
pt_BR     kciq_msg inst insert basic data                                                                     instaladorinfo                Inclus�o de dados b�sicos nas tabelas do banco de dados (%1)
pt_BR     kciq_msg inst insert demo data                                                                      instaladorinfo                Inclus�o de dados para demonstra��o
pt_BR     kciq_msg finish title                                                                               instaladorinfo                Iniciar uso do CACIC!
pt_BR     kciq_msg inst login insert                                                                          instaladorinfo                Inserindo dados do administrador (%1)...
pt_BR     kciq_msg inst local insert                                                                          instaladorinfo                Inserindo local (%1)...
pt_BR     kciq_msg inst config local insert                                                                   instaladorinfo                Inserindo configuracoes para o local (%1)...
pt_BR     kciq_msg demo help                                                                                  instaladorinfo                Inserir dados para demonstra��o do CACIC.
pt_BR     kciq_installertitle                                                                                 instaladorinfo                Instalador WEB para o CACIC
pt_BR     kciq_msg web_installer                                                                              instaladorinfo                Instalador WEB para o CACIC
pt_BR     kciq_msg inst finished and verified                                                                 instaladorinfo                Instala��o do CACIC finalizada e veficada!
pt_BR     kciq_msg advise_title                                                                               instaladorinfo                Instru��o PHP/Apache
pt_BR     kciq_installerintrotitle                                                                            instaladorinfo                Introdu��o
pt_BR     kciq_msg license title                                                                              instaladorinfo                Licen�a
pt_BR     kciq_msg admin mgm name help                                                                        instaladorinfo                Local ao qual a aplica��o gerente est� associada.
pt_BR     kciq_msg admin mgm user help                                                                        instaladorinfo                Login do Administrador do CACIC
pt_BR     kciq_msg user help                                                                                  instaladorinfo                Login do administrador do banco de dados.
pt_BR     kciq_msg php_memory                                                                                 instaladorinfo                Mem�ria para execu��o de programas PHP
pt_BR     kciq_msg showcfgfile                                                                                instaladorinfo                Mostrar <i>config.php</i>
pt_BR     kciq_msg showcfgfile help                                                                           instaladorinfo                Mostrar o arquivo de configura��es para o CACIC.
pt_BR     kciq_msg js_enable                                                                                  instaladorinfo                Necess�rio ativar <b>JavaScript</b> para usar o Instalador Web
pt_BR     kciq_msg admin mgm adminname help                                                                   instaladorinfo                Nome do Administrador do CACIC
pt_BR     kciq_msg database name                                                                              instaladorinfo                Nome do banco de dados
pt_BR     kciq_msg inst database name not defined                                                             instaladorerro                Nome do banco de dados deve ser informado!
pt_BR     kciq_msg database name help                                                                         instaladorinfo                Nome do banco de dados pr�-existente.
pt_BR     kciq_msg database host help                                                                         instaladorinfo                Nome do servidor (ou IP) do banco de dados.
pt_BR     kciq_msg dbuser help                                                                                instaladorinfo                Nome do usu�rio para ser usado pelo CACIC para conectar ao banco de dados.
pt_BR     kciq_msg inst config file read                                                                      instaladorinfo                N�o foi poss�vel ler o arquivo (%1) de configura��es
pt_BR     kciq_msg inst database sqldemodata not defined                                                      instaladorerro                N�o h� dados (%1) dispon�veis para demonstra��o!
pt_BR     kciq_msg inst insert demo data error                                                                instaladorerro                N�o h� dados dispon�veis para demonstra��o!
pt_BR     kciq_msg inst database sqldata not defined                                                          instaladorerro                N�o h� instru��es SQL (%1 ou %2) referentes aos dados base para o CACIC!
pt_BR     kciq_msg inst database sqlupdatedata not defined                                                    instaladorerro                N�o h� instru��es SQL (%1) para atualiza��o do banco de dados do CACIC!
pt_BR     kciq_msg inst database sqlbuild not defined                                                         instaladorerro                N�o h� instru��es SQL (%1) para cria��o das tabelas do banco de dados!
pt_BR     kciq_msg inst database standard sqldata should be used                                              instaladorerro                N�o h� instru��es SQL (%1) referentes aos dados base para o CACIC! Dados padr�o (%2) ser�o usados!
pt_BR     kciq_msg inst tables update error                                                                   instaladorerro                N�o h� instru��es SQL para atualiza��o das tabelas do banco de dados!
pt_BR     kciq_msg inst tables build error                                                                    instaladorerro                N�o h� instru��es SQL para cria��o das tabelas do banco de dados!
pt_BR     kciq_msg inst insert basic data error                                                               instaladorerro                N�o h� instru��es SQL para inser��o de dados base nas tabelas do banco de dados!
pt_BR     kciq_msg admin mgm phone help                                                                       instaladorinfo                N�mero do telefone do Administrador do CACIC para contato.
pt_BR     kciq_msg admin mgm obs help                                                                         instaladorinfo                Observa��es (informa��es) para o local ao qual a aplica��o gerente est� associada.
pt_BR     kciq_msg mcrypt_suporte                                                                             instaladorinfo      php-MCryptPHP com suporte a criptografia com MCrypt
pt_BR     kciq_msg mail_suporte                                                                               instaladorinfo                PHP com suporte a envio de email
pt_BR     kciq_msg gd_suporte                                                                                 instaladorinfo      php-GD    PHP com suporte a imagens com GD
pt_BR     kciq_msg ftp_suporte                                                                                instaladorinfo      php-FTP   PHP com suporte a troca de arquivos por FTP.
pt_BR     kciq_msg ldap_suporte                                                                               instaladorinfo      php-LDAP  PHP com suporte a conex�o a servi�o de diret�rios padr�o LDAP.
pt_BR     kciq_msg mysql_suporte                                                                              instaladorinfo      php-MySQL PHP com suporte ao MySQL vers�o
pt_BR     kciq_msg phpmcrypt_help                                                                             instaladorinfo                Para executar o CACIC � necess�rio instalar a biblioteca PHP de manipula��o criptogr�fica com MCrypt.
pt_BR     kciq_msg phpgd_help                                                                                 instaladorinfo                Para executar o CACIC � necess�rio instalar a biblioteca de manipula��o de imagens com GD.
pt_BR     kciq_msg phpftp_help                                                                                instaladorinfo                Para executar o CACIC � necess�rio instalar a biblioteca de para uso de FTP.
pt_BR     kciq_msg phpldap_help                                                                               instaladorinfo                Para executar o CACIC � necess�rio instalar a biblioteca de para uso de LDAP.
pt_BR     kciq_msg phpmysql_help                                                                              instaladorinfo                Para executar o CACIC � necess�rio instalar a biblioteca para banco de dados MYSQL.
pt_BR     kciq_msg phpversion_help                                                                            instaladorinfo                Para executar o CACIC � necess�rio instalar a vers�o do PHP indicada.
pt_BR     kciq_msg inst database admin not defined                                                            instaladorerro                Para instala��o nova, informe o usu�rio administrador do banco de dados!
pt_BR     kciq_msg php_flag_on                                                                                instaladorinfo                Para que o CACIC funcione corretamente � necess�rio - por enquanto - ativar essa diretiva.
pt_BR     kciq_msg fix_requiriment_help                                                                       instaladorinfo                Por favor, corrija pend�ncias para continuar processo de instala��o!
pt_BR     kciq_msg license advise                                                                             instaladorinfo                Por favor, leia os termos da licen�a a seguir. Voc� deve aceitar os termos desta para continuar a instala��o!
pt_BR     kciq_msg database port                                                                              instaladorinfo                Porta
pt_BR     kciq_msg database port help                                                                         instaladorinfo                Porta de conex�o ao banco de dados.
pt_BR     kciq_msg inst database server port not defined                                                      instaladorerro                Porta no servidor de banco de dados deve ser informada!
pt_BR     kciq_msg inst database build process ok                                                             instaladorinfo                Processo de constru��o do banco de dados (%1) finalizado com sucesso!
pt_BR     kciq_msg database type help                                                                         instaladorinfo                Qual o tipo de banco de dados a usar (Somente MySQL por enquanto).
pt_BR     kciq_msg real                                                                                       instaladorinfo                Real
pt_BR     kciq_msg inst end advise title                                                                      instaladorinfo                Recomenda��es
pt_BR     kciq_installerresources                                                                             instaladorinfo                Recursos do Instalador:
pt_BR     kciq_msg features title                                                                             instaladorinfo                Recursos para as pr�ximas vers�es do CACIC
pt_BR     kciq_msg requisitos                                                                                 instaladorinfo                Requisitos
pt_BR     retorne aos passos anteriores e configure adequadamente                                             instaladorinfo                Retorne aos passos anteriores e configure adequadamente
pt_BR     kciq_msg savecfgfile help                                                                           instaladorinfo                Salva o arquivo de configura��es para o CACIC.
pt_BR     kciq_msg save title                                                                                 instaladorinfo                Salvar dados do administrador do CACIC.
pt_BR     kciq_msg inst version to update                                                                     instaladorerro                Selecione a vers�o a ser atualizada!
pt_BR     kciq_msg version help                                                                               instaladorinfo                Selecione a vers�o do CACIC a ser atualizada.
pt_BR     kciq_msg inst type not defined                                                                      instaladorerro                Selecione um dos tipos de instala��o!
pt_BR     kciq_msg admin mgm pass help                                                                        instaladorinfo                Senha do Administrador do CACIC
pt_BR     kciq_msg password help                                                                              instaladorinfo                Senha do administrador do banco de dados.
pt_BR     kciq_msg dbpass help                                                                                instaladorinfo                Senha para o usu�rio do banco de dados.
pt_BR     kciq_msg database host                                                                              instaladorinfo                Servidor
pt_BR     kciq_msg inst database server not defined                                                           instaladorerro                Servidor de banco de dados deve ser informado!
pt_BR     kciq_msg admin mgm abbr help                                                                        instaladorinfo                Sigla do local ao qual a aplica��o gerente est� associada.
pt_BR     kciq_msg test conn help                                                                             instaladorinfo                Testar conex�o com o servidor.
pt_BR     kciq_msg test conn                                                                                  instaladorinfo                Teste de conex�o
pt_BR     kciq_msg database type                                                                              instaladorinfo                Tipo
pt_BR     kciq_msg inst database type not defined                                                             instaladorinfo                Tipo de banco de dados deve ser informado!
pt_BR     kciq_msg install type                                                                               instaladorinfo                Tipo de instala��o
pt_BR     kciq_msg inst url not defined                                                                       instaladorinfo                URL da aplica��o deve ser informada!
pt_BR     kciq_msg inst database user not defined                                                             instaladorerro                Usu�rio de conex�o com o banco de dados deve ser informado!
pt_BR     kciq_msg inst verify admin                                                                          instaladorinfo                Verificando administrador (%1)...
pt_BR     kciq_msg inst verify database existence                                                             instaladorinfo                Verificando exist�ncia do banco de dados (%1)...
pt_BR     kciq_msg inst verify local                                                                          instaladorinfo                Verificando local (%1) ...
pt_BR     kciq_msg inst path not executable                                                                   instaladorinfo                Verifique as permiss�es de leitura e execu��o do caminho f�sico informado!
pt_BR     kciq_msg def_version                                                                                instaladorinfo                Vers�o
pt_BR     kciq_msg version header                                                                             instaladorinfo                Vers�o a ser atualizada.
pt_BR     kciq_msg phpversion                                                                                 instaladorinfo                Vers�o do PHP
pt_BR     kciq_msg database server version invalid                                                            instaladorerro                Vers�o do Servidor de banco de dados inv�lida
pt_BR     kciq_msg phpcfgfile_help                                                                            instaladorinfo                Voc� poder� continuar a instala��o e o arquivo poder� (opcionalmente) ser mostrado na tela. Assim, voc� poder� copi�-lo e col�-lo no devido diret�rio.
pt_BR     e mais...                                                                                           instaladorinfo                e mais...
pt_BR     kciq_msg inst end advise file                                                                       instaladorarquivo             inst_end_advise_file.html
pt_BR     kciq_msg features file                                                                              instaladorarquivo             inst_end_features_file.html
pt_BR     kciq_msg inst end hist file                                                                         instaladorarquivo             inst_end_hist_file.html
pt_BR     kciq_installer_introdution                                                                          instaladorarquivo             introducao.html
pt_BR     kciq_msg mail host help                                                                             instaladorinfo                kciq_msg mail host help
pt_BR     kciq_msg mail password help                                                                         instaladorinfo                kciq_msg mail password help
pt_BR     kciq_msg mail port help                                                                             instaladorinfo                kciq_msg mail port help
pt_BR     kciq_msg mail subdir                                                                                instaladorinfo                kciq_msg mail subdir
pt_BR     kciq_msg mail subdir help                                                                           instaladorinfo                kciq_msg mail subdir help
pt_BR     kciq_msg mail user help                                                                             instaladorinfo                kciq_msg mail user help
pt_BR     kciq_msg mail verify                                                                                instaladorinfo                kciq_msg mail verify
pt_BR     kciq_msg phpemail_help                                                                              instaladorinfo                kciq_msg phpemail_help
pt_BR     kciq_msg license en_read                                                                            instaladorinfo                leia em ingl�s
pt_BR     kciq_msg license pt_read                                                                            instaladorinfo                leia em portugu�s
pt_BR     kciq_mnt_lang traducao                                                                              manutencaoinfo                Idioma a traduzir
pt_BR     kciq_mnt_tradutor                                                                                   manutencaoinfo                Tradu��o de texto do CACIC
pt_BR     acrescentado                                                                                        relatoriosinfo                Acrescentado
pt_BR     agente principal                                                                                    relatoriosinfo                Agente principal
pt_BR     analisar rota de rede                                                                               relatoriosinfo                Analisar rota de rede
pt_BR     analise se ativo na rede                                                                            relatoriosinfo                Analise se ativo na rede
pt_BR     antivirus ativo                                                                                     relatoriosinfo                Antiv�rus ativo
pt_BR     antivirus officescan                                                                                relatoriosinfo                Antiv�rus officeScan
pt_BR     ativo                                                                                               relatoriosinfo                Ativo
pt_BR     bios                                                                                                relatoriosinfo                BIOS
pt_BR     cpu                                                                                                 relatoriosinfo                CPU
pt_BR     campos obrigatorios                                                                                 relatoriosinfo                Campos obrigat�rios
pt_BR     clique sobre o nome da maquina para ver os detalhes                                                 relatoriosinfo                Clique sobre o nome da m�quina para ver os detalhes
pt_BR     comentario                                                                                          relatoriosinfo                Coment�rio
pt_BR     compartilhamento de diretorio                                                                       relatoriosinfo                Compartilhamento de diret�rio
pt_BR     compartilhamento de impressora                                                                      relatoriosinfo                Compartilhamento de impressora
pt_BR     compartilhamentos de diretorios e impressoras                                                       relatoriosinfo                Compartilhamentos de diret�rios e impressoras
pt_BR     computador inexistente                                                                              relatoriosinfo                Computador inexistente
pt_BR     dados da modificacao                                                                                relatoriosinfo                Dados da modifica��o
pt_BR     dados historicos                                                                                    relatoriosinfo                Dados hist�ricos
pt_BR     dados historicos obtidos de versoes anteriores a 2.4                                                relatoriosinfo                Dados hist�ricos obtidos de vers�es anteriores a 2.4
pt_BR     data da alteracao                                                                                   relatoriosinfo                Data da altera��o
pt_BR     data da ultima coleta                                                                               relatoriosinfo                Data da �ltima coleta
pt_BR     data de alteracao                                                                                   relatoriosinfo                Data de altera��o
pt_BR     data de instalacao                                                                                  relatoriosinfo                Data de instala��o
pt_BR     data/hora da ultima coleta                                                                          relatoriosinfo                Data/Hora da �ltima coleta
pt_BR     data/hora do ultimo acesso                                                                          relatoriosinfo                Data/Hora do �ltimo acesso
pt_BR     data/hora inclusao                                                                                  relatoriosinfo                Data/Hora inclus�o
pt_BR     data/hora instalacao                                                                                relatoriosinfo                Data/Hora instala��o
pt_BR     depende de senha                                                                                    relatoriosinfo                Depende de senha
pt_BR     desativado                                                                                          relatoriosinfo                Desativado
pt_BR     detalhes do computador                                                                              relatoriosinfo                Detalhes do Computador
pt_BR     diretorio                                                                                           relatoriosinfo                Diret�rio
pt_BR     dominio dns                                                                                         relatoriosinfo                Dom�nio DNS
pt_BR     endereco tcp/ip                                                                                     relatoriosinfo                Endere�o TCP/IP
pt_BR     endereco de rede                                                                                    relatoriosinfo                Endere�o de rede
pt_BR     endereco do servidor                                                                                relatoriosinfo                Endere�o do servidor
pt_BR     espaco (mb)                                                                                         relatoriosinfo                Espa�o (MB)
pt_BR     estado do officescan                                                                                relatoriosinfo                Estado do OfficeScan
pt_BR     exibe as alteracoes nas configuracoes de hardware dos computadores.                                 relatoriosinfo                Exibe as altera��es nas configura��es de hardware dos computadores.
pt_BR     exibir informacoes de patrimonio                                                                    relatoriosinfo                Exibir informa��es de patrim�nio
pt_BR     fabricante                                                                                          relatoriosinfo                Fabricante
pt_BR     ferramentas                                                                                         relatoriosinfo                Ferramentas
pt_BR     forcar coletas                                                                                      relatoriosinfo                For�ar coletas
pt_BR     gateway                                                                                             relatoriosinfo                Gateway
pt_BR     gerador por                                                                                         relatoriosinfo                Gerador por
pt_BR     gerente de coletas                                                                                  relatoriosinfo                Gerente de coletas
pt_BR     gravacao                                                                                            relatoriosinfo                Grava��o
pt_BR     hardware instalado                                                                                  relatoriosinfo                Hardware instalado
pt_BR     historico de alteracoes das informacoes de patrimonio                                               relatoriosinfo                Hist�rico de altera��es das informa��es de patrim�nio
pt_BR     historico de alteracoes na configuracao de hardware                                                 relatoriosinfo                Hist�rico de altera��es na configura��o de hardware
pt_BR     historico de alteracoes na configuracao de rede                                                     relatoriosinfo                Hist�rico de altera��es na configura��o de rede
pt_BR     identificador/versao                                                                                relatoriosinfo                Identificador/vers�o
pt_BR     informacoes basicas                                                                                 relatoriosinfo                Informa��es b�sicas
pt_BR     informacoes de patrimonio e localizacao fisica                                                      relatoriosinfo                Informa��es de patrim�nio e localiza��o f�sica
pt_BR     instalado                                                                                           relatoriosinfo                Instalado
pt_BR     leitura                                                                                             relatoriosinfo                Leitura
pt_BR     limpar                                                                                              relatoriosinfo                Limpar
pt_BR     livre                                                                                               relatoriosinfo                Livre
pt_BR     memoria ram                                                                                         relatoriosinfo                Mem�ria RAM
pt_BR     modem                                                                                               relatoriosinfo                Modem
pt_BR     mostrar somente dados historicos?                                                                   relatoriosinfo                Mostrar somente dados hist�ricos?
pt_BR     mostrar tambem dados historicos?                                                                    relatoriosinfo                Mostrar tamb�m dados hist�ricos?
pt_BR     mouse                                                                                               relatoriosinfo                Mouse
pt_BR     mascara de rede                                                                                     relatoriosinfo                M�scara de rede
pt_BR     modulo de coleta de compartilhamentos de diretorios e impressoras nao habilitado pelo administrador relatoriosinfo                M�dulo de coleta de compartilhamentos de diret�rios e impressoras n�o habilitado pelo Administrador
pt_BR     nao existem compartilhamentos nesta maquina                                                         relatoriosinfo                N�o existem compartilhamentos nesta m�quina
pt_BR     nao existem unidades de disco nesta maquina                                                         relatoriosinfo                N�o existem unidades de disco nesta m�quina
pt_BR     nao foram coletadas informacoes de aplicativos monitorados referente a esta maquina                 relatoriosinfo                N�o foram coletadas informa��es de aplicativos monitorados referente a esta m�quina
pt_BR     nao foram coletadas informacoes de patrimonio e/ou localizacao fisica                               relatoriosinfo                N�o foram coletadas informa��es de patrim�nio e/ou Localiza��o f�sica
pt_BR     nao foram coletadas informacoes de software inventariado referente a esta maquina                   relatoriosinfo                N�o foram coletadas informa��es de software inventariado referente a esta m�quina
pt_BR     nao foram coletadas informacoes de software referente a esta maquina                                relatoriosinfo                N�o foram coletadas informa��es de software referente a esta m�quina
pt_BR     nao foram coletadas informacoes de variaveis de ambiente referente a esta maquina                   relatoriosinfo                N�o foram coletadas informa��es de vari�veis de ambiente referente a esta m�quina
pt_BR     nao foram coletadas informacoes do officescan referente a esta maquina                              relatoriosinfo                N�o foram coletadas informa��es do OfficeScan referente a esta m�quina
pt_BR     nao foram encontradas alteracoes de hardware!                                                       relatoriosinfo                N�o foram encontradas altera��es de hardware!
pt_BR     numero serial                                                                                       relatoriosinfo                N�mero serial
pt_BR     o modulo de coleta de informacoes de hardware nao foi habilitado pelo administrador                 relatoriosinfo                O modulo de coleta de informa��es de hardware n�o foi habilitado pelo Administrador
pt_BR     o modulo de coleta de informacoes das unidades de disco nao foi habilitado pelo administrador       relatoriosinfo                O m�dulo de coleta de informacoes das Unidades de Disco nao foi habilitado pelo Administrador
pt_BR     o modulo de coleta de informacoes de patrimonio nao foi habilitado pelo administrador               relatoriosinfo                O m�dulo de coleta de informa��es de patrim�nio n�o foi habilitado pelo Administrador
pt_BR     o modulo de coleta de informacoes de sistemas monitorados nao foi habilitado pelo administrador     relatoriosinfo                O m�dulo de coleta de informa��es de sistemas monitorados n�o foi habilitado pelo administrador
pt_BR     o modulo de coleta de informacoes de software nao foi habilitado pelo administrador                 relatoriosinfo                O m�dulo de coleta de informa��es de software n�o foi habilitado pelo Administrador
pt_BR     o modulo de coleta de informacoes do antivirus officescan nao foi habilitado pelo administrador     relatoriosinfo                O m�dulo de coleta de informa��es do Antiv�rus OfficeScan n�o foi habilitado pelo Administrador
pt_BR     opcoes administrativas                                                                              relatoriosinfo                Op��es administrativas
pt_BR     permissao                                                                                           relatoriosinfo                Permiss�o
pt_BR     periodo                                                                                             relatoriosinfo                Per�odo
pt_BR     periodo da data de instalacao do antivirus para pesquisa                                            relatoriosinfo                Per�odo da data de instala��o do antiv�rus para pesquisa
pt_BR     pesquisar                                                                                           relatoriosinfo                Pesquisar
pt_BR     placa de som                                                                                        relatoriosinfo                Placa de som
pt_BR     placa de video                                                                                      relatoriosinfo                Placa de v�deo
pt_BR     placa mae                                                                                           relatoriosinfo                Placa m�e
pt_BR     protocolo tcp/ip (configuracao principal)                                                           relatoriosinfo                Protocolo TCP/IP (Configura��o Principal)
pt_BR     quantidade de cores                                                                                 relatoriosinfo                Quantidade de cores
pt_BR     quantidade de memoria                                                                               relatoriosinfo                Quantidade de mem�ria
pt_BR     registros                                                                                           relatoriosinfo                Registros
pt_BR     registros nao encontrados na tabela %1 ou sua sessao expirou!                                       relatoriosinfo                Registros n�o encontrados na tabela %1 ou sua sess�o expirou!
pt_BR     registros nao encontrados na tabela %1 para os dados fornecidos!                                    relatoriosinfo                Registros n�o encontrados na tabela %1 para os dados fornecidos!
pt_BR     relatorio de alteracao de hardware                                                                  relatoriosinfo                Relat�rio de altera��o de hardware
pt_BR     relatorio de alteracoes de hardware                                                                 relatoriosinfo                Relat�rio de altera��es de hardware
pt_BR     relatorio de alteracoes de software                                                                 relatoriosinfo                Relat�rio de altera��es de software
pt_BR     relatorio de alteracoes de softwares instalados nos computadores da rede selecionada                relatoriosinfo                Relat�rio de altera��es de softwares instalados nos computadores da rede selecionada
pt_BR     relatorio de configuracoes de hardware                                                              relatoriosinfo                Relat�rio de configura��es de hardware
pt_BR     relatorio de configuracoes do antivirus officescan                                                  relatoriosinfo                Relat�rio de configura��es do antiv�rus OfficeScan
pt_BR     relatorio de informacoes de patrimonio e localizacao fisica                                         relatoriosinfo                Relat�rio de informa��es de patrim�nio e localiza��o f�sica
pt_BR     relatorio de maquinas com inventario desatualizado                                                  relatoriosinfo                Relat�rio de m�quinas com invent�rio desatualizado
pt_BR     relatorio de maquinas com inventario em branco                                                      relatoriosinfo                Relat�rio de m�quinas com invent�rio em branco
pt_BR     relatorio de maquinas com nome repetido                                                             relatoriosinfo                Relat�rio de m�quinas com nome repetido
pt_BR     relatorio de pastas compartilhadas                                                                  relatoriosinfo                Relat�rio de pastas compartilhadas
pt_BR     relatorio que exibe os compartilhamentos nos microcomputadores das redes selecionadas               relatoriosinfo                Relat�rio que exibe os compartilhamentos nos microcomputadores das redes selecionadas
pt_BR     remover computador                                                                                  relatoriosinfo                Remover computador
pt_BR     removido                                                                                            relatoriosinfo                Removido
pt_BR     resolucao                                                                                           relatoriosinfo                Resolu��o
pt_BR     risco alto: integridade e privacidade                                                               relatoriosinfo                Risco alto: integridade e privacidade
pt_BR     risco medio: privacidade                                                                            relatoriosinfo                Risco m�dio: privacidade
pt_BR     rotulo                                                                                              relatoriosinfo                R�tulo
pt_BR     selecione as configuracoes de hardware que deseja exibir                                            relatoriosinfo                Selecione as configura��es de hardware que deseja exibir
pt_BR     selecione as configuracoes que deseja exibir                                                        relatoriosinfo                Selecione as configura��es que deseja exibir
pt_BR     selecione as redes                                                                                  relatoriosinfo                Selecione as redes
pt_BR     selecione os servidores de atualizacao para consulta                                                relatoriosinfo                Selecione os servidores de atualiza��o para consulta
pt_BR     selecione os tipos de hardware a serem exibidos no relatorio.                                       relatoriosinfo                Selecione os tipos de hardware a serem exibidos no relat�rio.
pt_BR     servidor dhcp                                                                                       relatoriosinfo                Servidor DHCP
pt_BR     servidor dns primario                                                                               relatoriosinfo                Servidor DNS prim�rio
pt_BR     servidor dns secundario                                                                             relatoriosinfo                Servidor DNS secund�rio
pt_BR     servidor wins primario                                                                              relatoriosinfo                Servidor WINS prim�rio
pt_BR     servidor wins secundario                                                                            relatoriosinfo                Servidor WINS secund�rio
pt_BR     servidor do officescan                                                                              relatoriosinfo                Servidor do OfficeScan
pt_BR     servicos abertos para a rede                                                                        relatoriosinfo                Servi�os abertos para a rede
pt_BR     sistema de arquivos                                                                                 relatoriosinfo                Sistema de arquivos
pt_BR     sistemas monitorados                                                                                relatoriosinfo                Sistemas monitorados
pt_BR     slot                                                                                                relatoriosinfo                Slot
pt_BR     softwares inventariados                                                                             relatoriosinfo                Softwares inventariados
pt_BR     sao necessarios parametros para gerar o relatorios!                                                 relatoriosinfo                S�o necess�rios par�metros para gerar o relat�rios!
pt_BR     tamanho (mb)                                                                                        relatoriosinfo                Tamanho (MB)
pt_BR     teclado                                                                                             relatoriosinfo                Teclado
pt_BR     texto                                                                                               relatoriosinfo                Texto
pt_BR     tipo                                                                                                relatoriosinfo                Tipo
pt_BR     tipo componente                                                                                     relatoriosinfo                Tipo componente
pt_BR     tipo de alteracao                                                                                   relatoriosinfo                Tipo de altera��o
pt_BR     todas                                                                                               relatoriosinfo                Todas
pt_BR     unidades de discos                                                                                  relatoriosinfo                Unidades de discos
pt_BR     utilizado                                                                                           relatoriosinfo                Utilizado
pt_BR     utilizacao (%)                                                                                      relatoriosinfo                Utiliza��o (%)
pt_BR     variaveis de ambiente                                                                               relatoriosinfo                Vari�veis de ambiente
pt_BR     versao do dao                                                                                       relatoriosinfo                Versao do DAO
pt_BR     versao da maquina virtual java (jvm)                                                                relatoriosinfo                Vers�o da maquina virtual java (JVM)
pt_BR     versao do ado                                                                                       relatoriosinfo                Vers�o do ADO
pt_BR     versao do acrobat reader                                                                            relatoriosinfo                Vers�o do Acrobat Reader
pt_BR     versao do bde                                                                                       relatoriosinfo                Vers�o do BDE
pt_BR     versao do directx                                                                                   relatoriosinfo                Vers�o do DirectX
pt_BR     versao do mozilla                                                                                   relatoriosinfo                Vers�o do Mozilla
pt_BR     versao do odbc                                                                                      relatoriosinfo                Vers�o do ODBC
pt_BR     versao agente principal                                                                             relatoriosinfo                Vers�o do agente principal
pt_BR     versao do engine                                                                                    relatoriosinfo                Vers�o do engine
pt_BR     versao gerente de coletas                                                                           relatoriosinfo                Vers�o do gerente de coletas
pt_BR     versao do gerente de coletas                                                                        relatoriosinfo                Vers�o do gerente de coletas
pt_BR     versao do internet explorer                                                                         relatoriosinfo                Vers�o do internet explorer
pt_BR     versao do pattern                                                                                   relatoriosinfo                Vers�o do pattern
pt_BR     versoes de softwares basicos                                                                        relatoriosinfo                Vers�es de softwares b�sicos
pt_BR     ultimo login                                                                                        relatoriosinfo                �ltimo login
pt_BR     apenas os nao classificados?                                                                        softwares info                Apenas os nao classificados?
pt_BR     classificacao de softwares                                                                          softwares info                Classificacao de softwares
pt_BR     classificacao de softwares conforme tipos possiveis                                                 softwares info                Classificacao de softwares conforme tipos possiveis
pt_BR     classificacao de softwares inventariados                                                            admin     info                Classificacao de softwares inventariados
pt_BR     classificacao de softwares inventariados conforme tipos possiveis                                   admin     info                Classificacao de softwares inventariados conforme tipos possiveis
pt_BR     nome do software inventariado                                                                       admin     info                Nome do software inventariado
pt_BR     classificacao de softwares inventariados conforme softwares adiquiridos                             admin     info                Classificacao de softwares inventariados conforme softwares adiquiridos
pt_BR     o nome da rede e obrigatorio                                                                        rede      info                O nome da rede e obrigatorio
pt_BR     identificador do servidor de aplicacao e obrigatorio                                                rede      info                Identificador do servidor de aplicacao e obrigatorio
pt_BR     identificador do servidor de atualizacoes e obrigatorio                                             rede      info                Identificador do servidor de atualizacoes e obrigatorio
pt_BR     informe porta ftp do servidor de atualizacoes                                                       rede      info                Informe porta FTP do servidor de atualizacoes
pt_BR     informe o caminho ftp no servidor de atualizacoes                                                   rede      info                Informe o caminho FTP no servidor de atualizacoes
pt_BR     informe o usuario de acesso ftp ao servidor de atualizacoes pelo agente de coletas                  rede      info                Informe o usuario de acesso FTP ao servidor de atualizacoes pelo agente de coletas
pt_BR     informe a senha do usuario de acesso ftp ao servidor de atualizacoes pelo agente de coletas         rede      info                Informe a senha do usuario de acesso FTP ao servidor de atualizacoes pelo agente de coletas
pt_BR     informe o usuario de acesso ftp ao servidor de atualizacoes pelo gerente                            rede      info                Informe o usuario de acesso FTP ao servidor de atualizacoes pelo gerente
pt_BR     informe a senha do usuario de acesso ftp ao servidor de atualizacoes pelo gerente                   rede      info                Informe a senha do usuario de acesso FTP ao servidor de atualizacoes pelo gerente
pt_BR     inclusao de nova subrede                                                                            rede      info                Inclusao de nova subrede
pt_BR     inclusao de nova subrede - texto de ajuda                                                           rede      info                As informa��es que dever�o ser cadastradas abaixo referem-se a uma subrede onde ser�o instalados os agentes do CACIC.
pt_BR     servidor de aplicacoes                                                                              rede      info                Servidor de aplicacoes
pt_BR     limite ftp                                                                                          rede      info                Limite FTP
pt_BR     usuario de acesso ftp ao servidor de atualizacoes pelo agente de coletas                            rede      info                Usuario de acesso FTP ao servidor de atualizacoes pelo agente de coletas
pt_BR     senha de acesso                                                                                     rede      info                Senha de acesso
pt_BR     usuario de acesso ftp ao servidor de atualizacoes pelo gerente                                      rede      info                Usuario de acesso FTP ao servidor de atualizacoes pelo gerente
pt_BR     caminho (path) ftp no servidor de atualizacoes                                                      rede      info                Caminho (path) FTP no servidor de atualizacoes
pt_BR     contato um                                                                                          geral     info                Contato um
pt_BR     contato dois                                                                                        geral     info                Contato dois
pt_BR     marcar todas as acoes para essa rede                                                                rede      info                Marcar todas as acoes para essa rede
pt_BR     marcar todas as acoes para essa rede - texto de ajuda                                               rede      info                 Essa op��o habilitar� as a��es de auto-update e coletas nas esta��es situadas nesta rede. Caso seja necess�rio algum ajuste, este poder� ser feito em Administra��o/M�dulos.
pt_BR     confirma inclusao de rede?                                                                          rede      info                Confirma inclusao de rede?
pt_BR     estatisticas por                                                                                    geral      info                Estatisticas por
pt_BR     endereco de subrede invalido!                                                                       rede      info                Endereco de subrede invalido!
pt_BR     mascara de subrede invalida!                                                                        rede      info                Mascara de subrede invalida!
pt_BR     atencao:                                                                                            geral     info                Atencao:
pt_BR     com esta mascara, esta subrede atendera a faixa                                                     rede      info                Com esta mascara, esta subrede atendera a faixa
pt_BR     confirma?                                                                                           geral     info                Confirma?
pt_BR     atualizacoes de subredes                                                                            rede      info                Atualizacoes de subredes
pt_BR     atualizacoes de subredes - texto de ajuda                                                           rede      info                As informa��es referem-se aos objetos constantes do reposit�rio, os quais poder�o ser assinalados para verifica��o de exist�ncia e/ou vers�es nas SubRedes cadastradas
pt_BR     cadastro de processos de aquisicoes                                                                 admin     info                Cadastro de Processos de Aquisicoes
pt_BR     controle de processos de aquisicoes                                                                 admin     info                Controle de processos de aquisicoes
pt_BR     nome da empresa                                                                                     admin     info                Nome da empresa
pt_BR     nome do proprietario                                                                                admin     info                Nome do proprietario
pt_BR     nota fiscal                                                                                         admin     info                Nota Fiscal
pt_BR     data de aquisicao                                                                                   admin     info                Data de aquisicao
pt_BR     informe numero da nota fiscal                                                                       admin     info                Informe numero da nota fiscal
pt_BR     informe nome do proprietario                                                                        admin     info                Informe nome do proprietario
pt_BR     informe nome da empresa                                                                             admin     info                Informe nome da empresa
pt_BR     marca/desmarca todos os objetos                                                                     admin     info                Marca/desmarca todos os objetos
pt_BR     agentes para ms-windows                                                                             admin     info                Agentes para MS-Windows
pt_BR     hash                                                                                                admin     info                Hash
pt_BR     forcar                                                                                              admin     info                Forcar
pt_BR     agentes para gnu/linux                                                                              admin     info                Agentes para GNU/Linux
pt_BR     subredes cadastradas                                                                                admin     info                SubRedes Cadastradas
pt_BR     marcar/desmarcar todas as subredes                                                                  admin     info                Marcar/desmarcar todas as subRedes
pt_BR     legenda para as subredes                                                                            admin     info                Legenda para as SubRedes
pt_BR     amarelo                                                                                             admin     info                Amarelo
pt_BR     existencia de modulo com versao diferente                                                           admin     info                Existencia de modulo com versao diferente
pt_BR     laranja                                                                                             admin     info                Laranja
pt_BR     inexistencia parcial de modulos                                                                     admin     info                Inexistencia parcial de modulos
pt_BR     vermelho                                                                                            admin     info                Vermelho
pt_BR     inexistencia total de modulos                                                                       admin     info                Inexistencia total de modulos
pt_BR     dica: clique nas cores da legenda para marcar/desmarcar subredes em bloco                           admin     info                Dica: Clique nas Cores da legenda para marcar/desmarcar subredes em bloco
pt_BR     sequencia                                                                                           admin     info                Sequencia
pt_BR     nome da subrede                                                                                     admin     info                Nome da Subrede
pt_BR     servidor de atualizacoes                                                                            admin     info                Servidor de atualizacoes
pt_BR     caminho (path) ftp                                                                                  admin     info                Caminho (path) FTP
pt_BR     localizacao                                                                                         admin     info                Localizacao
pt_BR     executar atualizacoes                                                                               admin     info                Executar atualizacoes
pt_BR     confirma verificacao/atualizacao de subredes?                                                       admin     info                Confirma verificacao/atualizacao de subredes?
pt_BR     cadastro de software por estacao                                                                    admin     info                Cadastro de Software por Estacao
pt_BR     controle de software por estacao                                                                    admin     info                Controle de software por estacao
pt_BR     data de autorizacao                                                                                 admin     info                Data de autorizacao
pt_BR     patrimonio de destino                                                                               admin     info                Patrimonio de destino
pt_BR     data de expiracao                                                                                   admin     info                Data de expiracao
pt_BR     data de desinstalacao                                                                               admin     info                Data de desinstalacao
pt_BR     data de autorizacao da instalacao                                                                   admin     info                Data de autorizacao da instalacao
pt_BR     data de expiracao da instalacao                                                                     admin     info                Data de expiracao da instalacao
pt_BR     data de desinstalacao do software do computador                                                     admin     info                Data de desinstalacao do software do computador
pt_BR     informe computador                                                                                  admin     info                Informe computador
pt_BR     informe patrimonio                                                                                  admin     info                Informe patrimonio
pt_BR     software por estacao                                                                                admin     info                software por estacao
pt_BR     relatorio de configuracoes de software                                                              relatoriosinfo                Relatorio de configuracoes de software
pt_BR     distribuicao de sistemas operacionais dos computadores gerenciados                                  relatoriosinfo                Distribuicao de sistemas operacionais dos computadores gerenciados
pt_BR     distribuicao do ultimo acesso dos agentes                                                           relatoriosinfo                Distribuicao do ultimo acesso dos agentes
pt_BR     distribuicao por versoes de agentes do cacic                                                        relatoriosinfo                Distribuicao por versoes de agentes do CACIC
pt_BR     historico de hardware                                                                               relatoriosinfo                Historico de Hardware
pt_BR     historico de patrimonio                                                                             relatoriosinfo                Historico de Patrimonio
pt_BR     historico de tcp/ip                                                                                 relatoriosinfo                Historico de TCP/IP
pt_BR     nao foi encontrado nenhum registro                                                                  relatoriosinfo                Nao foi encontrado nenhum registro
