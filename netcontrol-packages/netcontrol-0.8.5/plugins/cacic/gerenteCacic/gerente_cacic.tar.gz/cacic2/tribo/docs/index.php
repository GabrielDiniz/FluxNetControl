<?
 /* 
 Copyright 2000, 2001, 2002, 2003, 2004, 2005 Dataprev - Empresa de Tecnologia e Informa��es da Previd�ncia Social, Brasil

 Este arquivo � parte do programa CACIC - Configurador Autom�tico e Coletor de Informa��es Computacionais

 O CACIC � um software livre; voc� pode redistribui-lo e/ou modifica-lo dentro dos termos da Licen�a P�blica Geral GNU como 
 publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a, ou (na sua opni�o) qualquer vers�o.

 Este programa � distribuido na esperan�a que possa ser  util, mas SEM NENHUMA GARANTIA; sem uma garantia implicita de ADEQUA��O a qualquer
 MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU para maiores detalhes.

 Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "LICENCA.txt", junto com este programa, se n�o, escreva para a Funda��o do Software
 Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
?>

<html>
<head>
<title>Ararib&oacute;ia</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p>&nbsp;<br>
</p>
<table width="90%" align="center">
  <tr> 
    <td><p><strong><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Documenta&ccedil;&atilde;o 
        do CACIC</font></strong> </p>
      <ul>
        <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="?pg=docs/como_funciona.html">Como 
          o CACIC funciona</a></font></li>
        <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="docs/Cacic-Manual-Instalacao-Utilizacao-v2601.pdf" target="_blank">Manual 
          de Instala&ccedil;&atilde;o e Utiliza��o - Vers�o 2.6.0.1 (Beta 1)</a></font></li>        
        <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="docs/Cacic-Implantacao-Ambiente-Centralizado.pdf" target="_blank">Roteiro para Implanta��o em Ambiente Centralizado</a></font></li>                  
        <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="?pg=docs/mase/index.php">Metodologia</a> 
          (Diagramas, casos de uso, etc.)</font></li>
        <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Gloss&aacute;rio 
          de termos utilizados no projeto</font></li>
        <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="docs/artigo_cacic_conip.pdf" target="_blank">Artigo</a> 
          apresentado no <a href="http://www.conip.com.br" target="_blank">IX 
          CONIP</a></font></li>
        <li><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="/tribo/docs/slides_cacic_conip.pdf" target="_blank">Slides</a> 
          apresentados no IX CONIP</font><br>
        </li>
      </ul></td>
  </tr>
</table>
<p><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> </font></p>
<p>&nbsp;</p>
</body>
</html>
