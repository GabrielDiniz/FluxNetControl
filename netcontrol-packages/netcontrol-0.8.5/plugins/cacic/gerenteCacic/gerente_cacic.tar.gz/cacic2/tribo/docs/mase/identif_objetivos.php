<html>
<head>
<title>Identifica&ccedil;&atilde;o de Objetivos</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table width="85%" border="0" align="center">
  <tr>
    <td><p><font size="3" face="Verdana, Arial, Helvetica, sans-serif"><strong>&nbsp;<br>
        Identifica&ccedil;&atilde;o de Objetivos</strong></font></p>
      <table border="0" cellpadding="2" cellspacing="4">
        <tr> 
          <td width="16" valign="top" align="right"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">1.</font></strong></div></td>
          <td width="636"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Coletar 
            informa&ccedil;&otilde;es sobre os componentes de hardware instalados 
            em cada computador e disponibiliz&aacute;-las aos administradores 
            de sistemas;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">2.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Alertar 
            os administradores de sistemas quando forem identificadas altera&ccedil;&otilde;es 
            na configura&ccedil;&atilde;o dos componentes de hardware de cada 
            computador;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">3.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Coletar 
            diversas informa&ccedil;&otilde;es sobre os softwares instalados em 
            cada computador e disponibiliz&aacute;-las aos administradores de 
            sistemas;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">4.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Configurar 
            programas em cada computador, de acordo com regras pr&eacute;-estabelecidas 
            pelos administradores de sistemas;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">5.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Transferir 
            arquivos para os computadores da rede, ocupando o m&iacute;nimo poss&iacute;vel 
            da largura de banda;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">6.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Instalar 
            novos softwares nos computadores gerenciados, tais como atualiza&ccedil;&otilde;es 
            de programas ou patches de seguran&ccedil;a;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">7.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Identificar 
            diret&oacute;rios compartilhados considerados inseguros e aplicar 
            as restri&ccedil;&otilde;es de seguran&ccedil;a necess&aacute;rias;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">8.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Coletar 
            informa&ccedil;&otilde;es de Patrim&ocirc;nio (PIB, localiza&ccedil;&atilde;o, 
            etc.) de cada computador e disponibiliz&aacute;-las aos administradores 
            de sistemas;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">9.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Alertar 
            os administradores de sistemas quando forem identificadas altera&ccedil;&otilde;es 
            na localiza&ccedil;&atilde;o f&iacute;sica do computador;</font></td>
        </tr>
        <tr> 
          <td valign="top"><div align="right"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">10.</font></strong></div></td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Permitir 
            aos administradores de sistemas o envio de pequenas mensagens administrativas 
            aos usu&aacute;rios de um computador espec&iacute;fico ou usu&aacute;rios 
            de um grupo de computadores.</font></td>
        </tr>
      </table>
	  <p>&nbsp;</p></td>
  </tr>
</table>
</body>
</html>
