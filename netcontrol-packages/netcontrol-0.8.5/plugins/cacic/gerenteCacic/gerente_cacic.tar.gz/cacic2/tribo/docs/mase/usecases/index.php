<html>
<head>
<title>Ararib&oacute;ia</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p>&nbsp;<br>
</p>
<table width="90%" align="center">
  <tr> 
    <td><p><strong><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Casos 
        de Uso</font></strong></p>
      <font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="?pg=docs/mase/usecases/coleta_hardware.php">Coleta 
      de Informa&ccedil;&otilde;es de Hardware</a></font> 
      <p>&nbsp;</p></td>
  </tr>
</table>
</body>
</html>
