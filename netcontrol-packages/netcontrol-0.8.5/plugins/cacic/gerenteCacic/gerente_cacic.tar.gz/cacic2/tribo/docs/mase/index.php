<html>
<head>
<title>Ararib&oacute;ia</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p>&nbsp;<br>
</p>
<table width="90%" align="center">
  <tr> 
    <td><p><strong><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">MASE</font></strong></p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">O CACIC foi 
        projetado utilizando-se a metodologia <a href="http://www.cis.ksu.edu/%7Esdeloach/ai/mase.htm" target="_blank">MASE</a><font size="1">(MultiAgent 
        Systems Engineering)</font></font></p>
      <table border="0">
        <tr> 
          <td colspan="3"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>1 
            - Fase de An&aacute;lise</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;&nbsp;&nbsp;</td>
          <td colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>1.1 
            - Captura de Objetivos</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;&nbsp;&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">1.1.1 
            - <a href="?pg=docs/mase/identif_objetivos.php">Identifica&ccedil;&atilde;o 
            de Objetivos</a></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">1.1.2 
            - Hierarquia de Objetivos</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>1.2 
            - Aplicando Casos de Uso</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">1.2.1 
            - <a href="?pg=docs/mase/usecases/index.php">Casos de Uso</a></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">1.2.2 
            - Diagramas de Seq&uuml;&ecirc;ncia</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>1.3 
            - Refinando Pap&eacute;is</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">1.3.1 
            - Diagrama de Tarefas Concorrentes</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">1.3.2 
            - Pap&eacute;is</font></td>
        </tr>
        <tr> 
          <td colspan="3"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>2 
            - Fase de Projeto</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>2.1 
            - Criando Classes de Agentes</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">2.1.1 
            - Classes de Agentes</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>2.2 
            - Construindo Conversa&ccedil;&otilde;es</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">2.2.1 
            - Conversa&ccedil;&otilde;es</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>2.3 
            - Montando Classes de Agentes</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">2.3.1 
            - Arquitetura dos Agentes</font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>2.4 
            - Projeto do Sistema</strong></font></td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">2.4.1 
            - Diagrama de implanta&ccedil;&atilde;o</font></td>
        </tr>
      </table>
      <p>&nbsp;</p></td>
  </tr>
</table>
</body>
</html>
