<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>CACIC - Configurador Autom&aacute;tico e Coletor de Informa&ccedil;&otilde;es Computacionais</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#F0F0F0" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#999999">
  <tr> 
    <td><font color="#FFFFFF" size="4" face="Verdana, Arial, Helvetica, sans-serif"><strong> 
      &nbsp;CACIC 2.0 </strong><font size="1">&nbsp;(codinome <a href="docs/arariboia.html" target="mainFrame">Ararib&oacute;ia</a>)</font><font size="2"><br>
      <strong>&nbsp;&nbsp;C</strong>onfigurador <strong>A</strong>utom&aacute;tico 
      e <strong>C</strong><font size="2">oletor de <strong>I</strong>nforma&ccedil;&otilde;es 
      <strong>C</strong>omputacionais</font></font></font></td>
    <td width="36%" valign="bottom"><div align="right"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif">Desenvolvido 
        pelo ESES.R&nbsp;</font> </div></td>
  </tr>
  <tr bgcolor="#CCCCCC"> 
    <td colspan="2"><table width="100%" border="0" cellpadding="4" cellspacing="0" bordercolor="#E0E0E0" bgcolor="#CCCCCC">
        <tr> 
          <td><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><font color="#666666"><font color="#333333" size="1"><strong>Esta&ccedil;&otilde;es 
            Windows | Administra&ccedil;&atilde;o do CACIC | Documenta&ccedil;&atilde;o 
            | Novidades | Downloads</strong></font></font></font></td>
        </tr>
      </table></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
