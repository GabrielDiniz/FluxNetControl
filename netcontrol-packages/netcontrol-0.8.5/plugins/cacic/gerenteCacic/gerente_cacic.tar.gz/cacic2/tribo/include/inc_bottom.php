<?
 /* 
 Copyright 2000, 2001, 2002, 2003, 2004, 2005 Dataprev - Empresa de Tecnologia e Informa��es da Previd�ncia Social, Brasil

 Este arquivo � parte do programa CACIC - Configurador Autom�tico e Coletor de Informa��es Computacionais

 O CACIC � um software livre; voc� pode redistribui-lo e/ou modifica-lo dentro dos termos da Licen�a P�blica Geral GNU como 
 publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a, ou (na sua opni�o) qualquer vers�o.

 Este programa � distribuido na esperan�a que possa ser  util, mas SEM NENHUMA GARANTIA; sem uma garantia implicita de ADEQUA��O a qualquer
 MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU para maiores detalhes.

 Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "LICENCA.txt", junto com este programa, se n�o, escreva para a Funda��o do Software
 Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
?>

<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#999999">
  <tr><td height="1" bgcolor="#000000"><img src="imgs/spacer.gif"></td></tr>
  <tr> 
    <td colspan="2" bgcolor="#CCCCCC"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong> 
      </strong></font> <div align="right"><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Dataprev 
        - Previd&ecirc;ncia Social</strong></font>&nbsp;&nbsp;</div></td>
  </tr>
  <tr bgcolor="#CCCCCC"> 
    <td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#E0E0E0" bgcolor="#CCCCCC">
		<tr><td height="1" bgcolor="#000000"><img src="imgs/spacer.gif"></td></tr>
        <tr> 
          <td bgcolor="#999999"><div align="right"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><font color="#666666"><font color="#FFFFFF" size="1">N&oacute;s 
              apoiamos e usamos Softwares Livres&nbsp;</font></font></font></div></td>
        </tr>
      </table></td>
  </tr>
</table>
