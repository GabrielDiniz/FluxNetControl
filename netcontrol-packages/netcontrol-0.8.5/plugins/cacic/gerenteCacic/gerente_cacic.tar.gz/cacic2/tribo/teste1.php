<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META http-equiv="Page-Enter" CONTENT="RevealTrans(Duration=1,Transition=1)">
</head>

<body background="0027.jpg">
<p><a href="teste.php">Voltar para p&aacute;gina principal...</a></p>
</body>
</html>
