<?
 /* 
 Copyright 2000, 2001, 2002, 2003, 2004, 2005 Dataprev - Empresa de Tecnologia e Informa��es da Previd�ncia Social, Brasil

 Este arquivo � parte do programa CACIC - Configurador Autom�tico e Coletor de Informa��es Computacionais

 O CACIC � um software livre; voc� pode redistribui-lo e/ou modifica-lo dentro dos termos da Licen�a P�blica Geral GNU como 
 publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a, ou (na sua opni�o) qualquer vers�o.

 Este programa � distribuido na esperan�a que possa ser  util, mas SEM NENHUMA GARANTIA; sem uma garantia implicita de ADEQUA��O a qualquer
 MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU para maiores detalhes.

 Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "LICENCA.txt", junto com este programa, se n�o, escreva para a Funda��o do Software
 Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
?>

<html>
<head>
<title>Ararib&oacute;ia</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p>&nbsp;<br>
</p>
<table width="90%" align="center">
  <tr>
    <td><p><strong><font color="#333333" size="2" face="Verdana, Arial, Helvetica, sans-serif">Como 
        obter suporte t&eacute;cnico</font></strong> </p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Todo o suporte 
        t&eacute;cnico dever&aacute; ser solicitado atrav&eacute;s do Centro Nacional 
        de Atendimento. Dessa forma poderemos criar uma enorme base de conhecimento 
        que poder&aacute; ser utilizada por outras pessoas. Por favor, apenas 
        em situa&ccedil;&otilde;es extremas solicite o suporte atrav&eacute;s 
        de telefone ou e-mail. Contamos com a sua compreens&atilde;o.</font></p>
      <p>&nbsp;</p>
      <table border="1" align="center" cellpadding="6" cellspacing="0" bordercolor="#333333" bgcolor="#CCCCCC">
        <tr> 
          <td colspan="3"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Lembre-se: 
            antes de solicitar suporte t&eacute;cnico,<br>
            por favor, leia a <a href="?pg=docs/index.php">documenta&ccedil;&atilde;o</a>.</strong></font></td>
        </tr>
      </table>
      <p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></p>
</td>
  </tr>
</table>
<p><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> </font></p>
<p>&nbsp;</p>
</body>
</html>
