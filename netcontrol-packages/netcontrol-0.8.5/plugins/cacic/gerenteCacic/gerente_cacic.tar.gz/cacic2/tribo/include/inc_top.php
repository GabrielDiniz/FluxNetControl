<?
 /* 
 Copyright 2000, 2001, 2002, 2003, 2004, 2005 Dataprev - Empresa de Tecnologia e Informa��es da Previd�ncia Social, Brasil

 Este arquivo � parte do programa CACIC - Configurador Autom�tico e Coletor de Informa��es Computacionais

 O CACIC � um software livre; voc� pode redistribui-lo e/ou modifica-lo dentro dos termos da Licen�a P�blica Geral GNU como 
 publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a, ou (na sua opni�o) qualquer vers�o.

 Este programa � distribuido na esperan�a que possa ser  util, mas SEM NENHUMA GARANTIA; sem uma garantia implicita de ADEQUA��O a qualquer
 MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU para maiores detalhes.

 Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "LICENCA.txt", junto com este programa, se n�o, escreva para a Funda��o do Software
 Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
define('CACIC',1);
include('../include/define.php');
?>

<body bgcolor="#F0F0F0" text="#333333" leftmargin="0" topmargin="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#999999">
  <tr> 
    <td>&nbsp;<img src="imgs/cacic.gif"></td>
    <td width="36%" valign="bottom">
<div align="right"><font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><br>
        </font> <font color="#FFFFFF" size="1" face="Verdana, Arial, Helvetica, sans-serif"><a onClick="javascript:window.open('versoes.htm','','width=460,height=470,top=0,scrollbars=YES')" href="#">Vers&atilde;o 
        <?=CACIC_VERSION;?><br>
        </a></font></p>Desenvolvido pela Dataprev/URES&nbsp;</font> </div></td>
  </tr>
  <tr bgcolor="#CCCCCC"> 
    <td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#E0E0E0" bgcolor="#CCCCCC">
        <tr>
          <td height="1" bgcolor="#000000"><img src="imgs/spacer.gif"></td>
        </tr>
      </table></td>
  </tr>
</table>