<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>CACIC - Configurador Autom�tico e Coletor de Informa��es Computacionais</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<frameset rows="65,*" cols="*" framespacing="0" frameborder="no" border="0" bordercolor="#333333">
  <frame src="adm_top.php" name="topFrame" scrolling="NO" noresize >
  <frame src="adm_content.php" name="mainFrame">
</frameset>
<noframes><body>

</body></noframes>
</html>
