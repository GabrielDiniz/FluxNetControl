This SOAP library is part of PEAR, pear.php.net.  Updated versions
may be obtained via CVS at pear.php.net.
