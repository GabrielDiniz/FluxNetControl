<? 
require_once('../include/library.php');
LimpaTESTES();	
$time = time();
GravaTESTES('TESTES: INICIO=' . $time);
sleep(5);
GravaTESTES('TESTES: FIM=' . time());
?>